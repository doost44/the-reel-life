# The Reel Life

An interactive exhibit that treats scrolling short-form video as a casino game.
A camcorder watches the visitor's phone. The game rewards them for scrolling
"correctly", not too fast and not too slow, and punishes them for actually
watching.

**Built so far:** the camcorder feed with a VHS overlay, an OBS-style editor for
laying out every screen (Phase 1), and reel detection from the camera feeding a
playable game (Phase 2, with the detection planned for Phases 3–4).

## How it fits together

```
camcorder ─AV─▶ AV-to-HDMI converter ─▶ USB3 Video capture card
                                           │
  eye/   Python + OpenCV
         cameras.py   opens the cameras (or recorded clips) the setup uses
         detector.py  finds the phone screen, turns its movement into swipes
         watcher.py   runs the detector on the detection camera
         game.py      idle → excitement → plateau → climax → resolution, scoring
         server.py    sends all of it to the pages; saves the setup
                                           │  one WebSocket per page
  web/   /editor        lay out screens and sources, run the game by hand
         /screen/<id>   one fullscreen screen (CRT, game, operator...)
```

The game runs once, inside the eye, so every screen shows the same game.

- `config.yaml`: values you edit by hand: detection thresholds, the scoring bands, timings, and every
  piece of wording on screen.
- `setup.json`: written by the editor: screens, their sources and positions, cameras, the detection
  camera, the locked phone position, and which monitor each screen opens on.
- `logs/sessions.jsonl`: one anonymous line per visit (time, reels, score, seconds per reel).

## First-time setup

The Python environment lives outside OneDrive, so OneDrive doesn't sync thousands of files. In PowerShell:

```powershell
uv venv --python 3.14 $env:USERPROFILE\.venvs\reel-life
uv pip install --python $env:USERPROFILE\.venvs\reel-life\Scripts\python.exe -r requirements.txt
```

ffmpeg must be on PATH: the eye uses it to read the cameras' names. It's already installed on this laptop.

## Run it

```powershell
.\run.ps1
```

This starts the eye and opens the editor at http://localhost:8765/editor. Press Ctrl+C to stop.
`.\run.ps1 -OpenScreens` also opens every screen that has a monitor, fullscreen.

## How a visit goes: the visitor wants, the machine likes

A machine that enjoys the scrolling in the visitor's place (interpassivity). Every swipe is a hit of
"dopamine" for the machine; that's a metaphor, never a measurement. Its **arousal** rises while **YOUR
PLEASURE** drains (depressive hedonia), and the gap widens the longer the visitor stays. The session
follows Masters and Johnson's sexual response cycle:

1. **Idle:** the attract loop. "PLACE YOUR PHONE TO PLAY", and the machine flirts with passers-by.
2. **Excitement:** starts as soon as a phone is put down (or with the first swipe). The onboarding
   steps, then the first minute of scrolling. The machine notices you and its heartbeat starts.
3. **Plateau:** it wants the sweet spot. Each swipe is judged by how long the visitor stayed on the reel:
   - **Sweet spot:** a big, fast dopamine hit, bigger on a streak. The visitor gets points, but with
     tolerance, each worth less than the last.
   - **Too fast:** a weak hit, and "you're losing me". The multiplier drops a level.
   - **Too slow:** lingering, the one moment the visitor might enjoy something. The machine whines and
     cools, and the streak is punished.
   - **The visitor's jackpot almost lands and never does.**
   - **The stillness challenge:** once a session, YOU dares them to hold still for 8 s while IT begs
     them not to.
4. **Climax:** the reservoir overflows. One slow white-out with no flashing, a held tone, the picture
   collapses to a line, a fake shutdown.
5. **Resolution:** cold indifference. Two columns of stats, YOU and IT, then "You can go now.", "Next."
   and back to idle.
   - **Left wanting:** leaving before the climax goes straight here, with "Leaving already?".

A committed scroller (a swipe every 2–5 s) climaxes the machine in about 3.6 minutes; a skimmer takes
about 4.7. That comes from simulation, tuned with `reservoir` in `config.yaml`. All wording is in
`config.yaml`: the attract line, callouts, the machine's lines and the stats. The machine's voice is
suggestive, never explicit, and wants your attention, never you. No stat reads as a diagnosis of the
visitor.

The Game screen is laid out **YOU | camcorder | IT**:
- **YOU:** the sources tick **Fades with YOUR PLEASURE**, so they drift to grey. Behind them is the
  **YOU mirror**: the visitor's own face, live and mirrored, with the score sitting over it, draining
  to grey with the rest of their side while IT's face flushes.
- **IT:** its body. A colour flush from cold blue to hot pink, a heartbeat, the dopamine reservoir and
  an arousal gauge.
- **The middle:** dopamine hits fly from the camcorder feed to the reservoir.
- **The CRT:** carries IT's glow too.

**IT's face** is the artist's own face, in pieces on six little screens wired to a head rig: forehead,
eyes, nose, mouth and chin.
- **Recording:** in the editor's **Face studio**, choose a camera, line your face up with the guide, and
  record an 8-second clip per mood: bored, curious, warm, flushed, peak, indifferent. Each comes with an
  acting prompt.
- **On screen:** the face crossfades between moods with the phase and arousal, tinted by IT's flush.
- **Storage:** the clips stay in `faces/` on this computer, kept out of git.
- **Never a visitor's face.**

**The YOU mirror** needs a second camera facing the visitor. Since visitors look down at the phone while
they scroll, put it beside the phone, looking up at the face. Choose it under **You mirror** in the editor.
- **When it's on:** the eye opens that camera when a visit starts and closes it at the climax or when
  the visitor leaves, so its light is on only while someone is playing.
- **Nothing is recorded.** Its picture only goes to the screens, live, while someone is playing. Neither
  Record footage nor the Face studio records it while a visitor could be in front of it.
- The mirror carries a small "LIVE · NOT RECORDED" caption. Change or remove it in the source's settings.

## The reel face (in progress)

The visitor's own head, rebuilt out of the reels they watch, on its own **Reel face** screen: full screen,
on a plain background. The idea: the self that compulsive scrolling leaves you with is built out of what
you consumed. **Built so far:** capturing the head (phase 1), the reels covering it (phase 2), and the
broken, JPEG-smeared look (phase 3). Still to come: the face moving and speaking a word (phase 4).

- **Capture:** when a visit starts, the screen shows the You mirror's camera and asks "LOOK UP AT THE
  CAMERA", then to turn left and right. It takes each photo by itself once the head is at the right angle.
  The head appears after the front photo and improves with each profile. With no profiles after 10 s, it
  carries on without them. Without a front photo there's no head, never a stock face.
- **The head:** MediaPipe's Face Landmarker (in `web/vendor/mediapipe`, so it works offline) finds 478
  points on the face. The eye builds a 3D head from them (`eye/face_capture.py`): the face, plus a skull
  and neck fitted to it. Each triangle's skin comes from whichever photo faces it best, and the back of the
  head, which no photo sees, is smeared from the nearest skin.
- **The copy:** every reel watched for at least `min_watch_seconds` (1.2 s, not just scrolled past)
  becomes shards of the head's skin. While a reel plays, `eye/reel_sampler.py` takes a still of the phone
  screen every 0.3 s from the detection camera, straightened and on a thread of its own, so tracking
  never waits. Blurry is fine. `eye/atlas.py` drapes the stills over patches of the head's own triangles.
  Early reels take big patches; later ones are smaller, break into up to four pieces, and land over the
  old ones. Longer-watched reels get bigger pieces. The eyes, brows, nose and mouth stay readable: the
  face's own light and dark is laid over the reels there. A reel with no usable still becomes a smeared
  block of its main colour. The base head is never changed: new photos rebuild the copy on the new head,
  with every reel so far. Reels watched before the face is captured wait, and go on once it is.
- **The broken look:** six controls, all rising with the session's progress: mostly reels watched (full
  at 30), partly seconds watched (full at 180). One reel looks almost clean; 20 reels is about half way;
  a long scroll is fully broken. Each control comes in at its own point, set in `config.yaml`
  (`reel_face.distortion`, explained in `eye/distortion.py`).

  | Control | What it does |
  | --- | --- |
  | `fracture_amount` | Pieces of the head pulled apart and sliding, some missing, some doubled; the head pinched and stretched; facets showing |
  | `shard_size` | Whole patches come away early; single triangles later |
  | `pixel_stretch` | Short bands of pixels smeared sideways (and down), out past the head's edge |
  | `jpeg_blockiness` | JPEG's squares, colour smeared across each square, colour banding |
  | `smear` | Datamosh: blocks of the last frames stick and drift; the head trails as it turns |
  | `colour_shift` | Neighbouring pieces in mismatched tones and exposures; colours split |

  The screen draws all six live, on the graphics card. Each reel is also damaged for real as it's painted
  on, more the later it comes: its colour knocked off, pixelated, and saved as a worse and worse JPEG. The
  face's own features fade a little, never away, so it stays a head. At full strength, at 1920×1080, it
  ran at about 60 frames a second on this laptop.
- **The editor's Reel face panel:**
  - What it's asking for, the photos taken so far, the reels, the seconds watched and the fragments
    showing. Underneath, the six controls as they are now.
  - **Intensity** sets how broken it looks by hand, for testing; **Auto** follows the session again. It
    drives the live effects; the damage already painted into each reel stays as the session made it. "last face" shows how the last face was posed, for tuning the angles in `config.yaml`
    (`reel_face`; 0.5 is square on).
  - **Recapture** takes new photos and keeps the reels. **Take front / left / right** takes the next face
    found, whatever its angle.
  - **History** scrubs back through the copy, one step per reel; **Live** returns. **Reset copy** goes back
    to the clean head and drops the reels.
  - **Test reels:** **+1 test reel** and **+10 test reels** feed in reels as if they'd been watched (a
    visit must be on: press Start). They're stills from any pictures or videos you put in `tests/reels/`,
    or made-up "TEST REEL" cards when that folder is empty.
- **Privacy:** the photos, the head, the reel stills and the history are held in the eye's memory for one
  visit and wiped when it goes back to idle, or when a new visit starts (every visit is counted, so even a
  visit that starts the instant the last one ends gets a clean slate). Nothing is saved, and nothing goes online: MediaPipe runs
  inside the page.
- **Tracking is unchanged.** The detector's code isn't touched, and it scores the same on the synthetic
  clips (17/17 and 21/25). Painting a reel every couple of seconds made no measurable difference to how
  long each frame takes to track.

The old casino layout is kept as **Game screen (casino v1)**. Optional physical extras (LED strip, fan,
sub-bass, lights, vibration) aren't built: they wait for a yes.

The scoring bands (1.2 s and 6 s) are placeholders until calibration sets them from real scrolling.

## Swipe detection

**Finding the screen** works at any angle. The finder looks for a lit area with four straight edges and
a dark bezel just outside them. Lines are fitted to the edges, so tilt, rotation, rounded screen corners
and a thumb across an edge don't throw it.

**Tracking** follows the screen from frame to frame. It checks for the screen-to-bezel step just around
each edge, which takes a couple of milliseconds, so the outline moves with the phone when it's held in a
hand.
- **Full search:** about 50 ms, so it only runs when tracking is lost.
- **A side moving on its own is ignored.** A phone moves as one piece; a thumb drags only one side.
- **Shape memory:** if the outline's proportions drift too far from what the last search found, it
  searches again.

**Swipes:** the screen is straightened into a small upright picture, and the detector measures how far
the whole picture moved between frames (phase correlation). A swipe moves the whole screen; a video
playing on it doesn't. A swipe is reported once the screen has travelled 35% of its height, typically
about 70 ms into the swipe.

**Exposure matters.** Set each camera's exposure in the editor's Cameras panel. On the Logi webcam, a
manual 1/64 s doubled the frame rate (15 to 30 fps) and stopped the screen washing out to white. The
room goes dark and the phone stays readable, which is what the detector wants.

**Frame the whole phone, with a margin.** The screen can't be tracked when its edges are off the
picture.

What it's built to handle:
- **Scene cuts** inside a video: one jump, not a swipe.
- **Half-swipes that spring back:** these don't count.
- **Fast swipes:** frames moving too fast to measure are read correctly.
- **Dark reels:** these can hide the outline, so the last one is kept.
- **A thumb joining the outline:** ignored, because a phone screen is a 16:9 to 20:9 rectangle.

**Lock the phone position** in the editor (Detection panel) once the phone sits in its cradle. That
makes detection steadier, and dark reels can't lose the phone. Without a dark background, use **Click
the phone's corners**: on a screen with a Detection view (such as Operator), click the phone screen's
top-left, top-right, bottom-right and bottom-left corners as the phone sees them. That also tells the
detector which way is "next".

**Tested on synthetic clips only.** Across five synthetic clips with known swipe times, it catches
nearly every swipe and invents none (`tools/detect_clip.py` prints the scores). Real recordings come
next and are the real test.

## The editor

- **Screens:** one per output (CRT, game, operator). Each has a size, background, sound on/off, a
  monitor, and **Open fullscreen**.
- **Sources:**

  | Source | What it shows |
  | --- | --- |
  | Camera | A camera, with an optional VHS overlay |
  | Text, Colour | Plain text or a block of colour |
  | Stat | Score, multiplier, streak, success rate, reels, session time or jackpot |
  | Rhythm meter | Too fast, perfect or too slow, with a live needle |
  | Callout | "PERFECT SCROLL", "TOO SLOW!"... |
  | Banner | The idle, onboarding and resolution text |
  | Detection view | What the detector sees |
  | Gauge | YOUR PLEASURE, AROUSAL, or the jackpot that never lands |
  | Reservoir | The machine's dopamine filling up |
  | Heartbeat | Its ECG trace and BPM |
  | Flush | A cold-blue to hot-pink glow that breathes |
  | Dopamine hits | Drops flying from one source to another |
  | Machine voice | Its lines, typed out; optionally spoken in a flat voice |
  | Payout | The YOU and IT stat columns |
  | IT face | IT's face from the Face studio clips, on little screens |
  | You mirror | The visitor's face, live, while they play |
  | Reel face | The visitor's head in 3D, captured when a visit starts |

  Each source has **Show during** (the five phases, like OBS scenes), **Opacity**, and **Fades with YOUR
  PLEASURE**. Each screen has **Sound** (casino blips, plus the machine's heartbeat, breathing and
  purr) and **Climax effect**.
- **Preview:** shows the screen live, or as it looks in any state.
- **Game:** fake a swipe, pretend the phone is in or out, start, jump to the climax, or reset. You can
  test without a phone.
- **Detection:** choose the camera, see what it sees, and lock or unlock the phone position. **Recorded
  clips are in the camera list too**, so you can run the whole game from a recording.
- **Cameras:** capture size and frame rate. The detection camera defaults to 60 fps, which halves the
  movement between frames.

Moving and resizing: drag a source to move it, or drag its handles to resize it. Edges snap; hold Alt to
stop snapping and Shift to keep the shape. Arrows nudge, Delete removes, Ctrl+Z undoes.

**Keys on a screen:**

| Key | What it does |
| --- | --- |
| D | Debug readout |
| Space | Fake swipe |
| P | Phone in / out / auto |
| 1–5 | Idle, excitement, plateau, climax, resolution |

## Tools

```powershell
$python = "$env:USERPROFILE\.venvs\reel-life\Scripts\python.exe"
& $python tools\record.py                    # record clips: R starts and stops a clip, Q quits (stop the eye first)
& $python tools\detect_clip.py <clip.avi>    # run the detector on a clip and list every swipe
& $python tools\make_test_clip.py --seed 6   # a synthetic phone-scrolling clip with known swipe times (--handheld: the phone moves)
& $python tools\test_screen_finder.py        # score the screen finder on 400 synthetic phones at random angles
& $python tools\make_footage_demos.py        # demo videos and an angle sheet for presenting, into footage/demos
& $python tools\list_cameras.py              # every camera and monitor the eye can see
```

When recording, flash your phone screen white at the start of each clip so it can be lined up with your
phone's own screen recording.

## Footage for presenting

`footage/` holds recordings for the A2 submission and the exhibition station (see `footage/README.md`):
- **`demos/`:** demonstration videos made from the synthetic clips.
- **`live-tests/`:** your own test sessions, recorded with **● Record footage** in the editor's Detection
  panel. You get the camera, the detection view and a list of swipes, as MP4s. Recording stops itself
  after 10 minutes.

## Privacy

Video is only saved when you ask for it: by `tools/record.py`, or by **Record footage** in the editor,
for your own test sessions. During the exhibition, nothing records visitors: the YOU mirror shows their
face live while they play and keeps nothing. The eye keeps only the newest frame of each camera in
memory and only serves pages on this computer (127.0.0.1). The session log holds numbers only.

## Hardware notes

- The capture card is a MacroSilicon MS2130 ("USB3 Video", HDMI in): 720×480 at up to 60 fps.
- Set the converter in front of it to **AV**. It shows a blue screen with "SV" or "AV" when it has no
  input.
- **Turn off the camcorder's power save.** It goes quiet after a few minutes in camera mode, and the
  exhibit needs it on all day.
- Turn off the camcorder's date and time display: it's burned into the picture.
- The camcorder's menus do show on the AV output, so focus and exposure can be set with the LCD broken.
