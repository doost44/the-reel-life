// Finds the visitor's face for the reel face, with MediaPipe's Face Landmarker
// (saved in web/vendor, so it works offline). While the eye is asking for a
// view, a few times a second it looks at the newest face-camera picture and
// sends any face it finds: its landmarks and the photo. The eye decides which
// view that is, and keeps it or not (reel_face.py). Nothing is kept here.

const MEDIAPIPE = '/vendor/mediapipe';
const LOOKS_PER_SECOND = 4;

let landmarker = null;
let loading = null;

function load() {
  loading ??= (async () => {
    const { FaceLandmarker, FilesetResolver } = await import(`${MEDIAPIPE}/vision_bundle.mjs`);
    const files = await FilesetResolver.forVisionTasks(`${MEDIAPIPE}/wasm`);
    landmarker = await FaceLandmarker.createFromOptions(files, {
      baseOptions: { modelAssetPath: `${MEDIAPIPE}/face_landmarker.task`, delegate: 'CPU' },
      runningMode: 'IMAGE',
      numFaces: 1,
    });
  })().catch((error) => {
    console.error('MediaPipe could not start:', error);
    loading = null; // try again on the next look
  });
  return loading;
}

export class FaceFinder {
  constructor(send) {
    this.send = send;
    this.canvas = document.createElement('canvas');
    this.lastLook = 0;
    this.lastPicture = null;
    this.busy = false;
    this.found = null; // the last face found (landmarks, 0-1), for showing that it's looking
  }

  get ready() {
    return landmarker !== null;
  }

  // Call every frame while the eye is asking for a view.
  look(picture, now) {
    if (!landmarker) {
      load();
      return;
    }
    if (this.busy || !picture || picture === this.lastPicture || now - this.lastLook < 1000 / LOOKS_PER_SECOND) return;
    this.lastLook = now;
    this.lastPicture = picture;
    const { canvas } = this;
    canvas.width = picture.width;
    canvas.height = picture.height;
    canvas.getContext('2d').drawImage(picture, 0, 0);
    const face = landmarker.detect(canvas).faceLandmarks?.[0] ?? null;
    this.found = face;
    if (!face) return;
    this.busy = true;
    canvas.toBlob(async (blob) => {
      try {
        if (blob) {
          this.send({ type: 'reelface_view', landmarks: face.map(({ x, y, z }) => [round(x), round(y), round(z)]), image: await base64(blob) });
        }
      } finally {
        this.busy = false;
      }
    }, 'image/jpeg', 0.92);
  }
}

const round = (value) => Math.round(value * 1e5) / 1e5;

function base64(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result).split(',')[1]);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}
