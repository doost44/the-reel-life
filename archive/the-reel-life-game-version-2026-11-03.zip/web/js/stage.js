// Draws one screen. Every item is an element positioned in screen pixels on
// a stage the size of the screen, and the stage is scaled to fit its
// container. The editor and the fullscreen screens both draw with this, so
// the editor's preview is exactly what the screen shows.
//
// To add a new kind of source, add an entry to SOURCE_TYPES: its defaults,
// the fields the editor shows, and a view. A view has an element (el) and
// update(item); it can also have draw(now) for animation, game(snapshot)
// for the game's numbers and event(gameEvent) for callouts.

import { COLD, HOT, FlushView, GaugeView, HeartbeatView, HitsView, PayoutView, ReservoirView, VoiceView } from './body.js';
import { FACE_DEFAULTS, FaceView } from './face.js';
import { MIRROR_DEFAULTS, MIRROR_VIEW, MirrorView } from './mirror.js';
import { REEL_FACE_DEFAULTS, REEL_FACE_VIEW, ReelFaceView } from './reelface.js';
import { drawVHS, drawNoSignal } from './vhs.js';

const FONTS = ['Arial Black', 'Impact', 'Consolas', 'Georgia', 'Segoe UI', 'Courier New'];
export const GAME_STATES = ['idle', 'excitement', 'plateau', 'climax', 'resolution'];
export const DETECTION_VIEW = '@detection';

const STATS = {
  score: { label: 'SCORE', show: (game) => game.score.toLocaleString('en-US'), rolls: true },
  multiplier: { label: 'MULTIPLIER', show: (game) => `x${game.multiplier}` },
  streak: { label: 'STREAK', show: (game) => `${game.streak}` },
  success: { label: 'SUCCESS RATE', show: (game) => (game.success === null ? '—' : `${game.success}%`) },
  reels: { label: 'REELS CONSUMED', show: (game) => `${game.reels}` },
  time: { label: 'SESSION TIME', show: (game) => clock(game.session_time) },
  jackpot: { label: 'JACKPOT', show: () => fakeJackpot() },
};

const fontField = { key: 'font', label: 'Font', kind: 'select', options: FONTS };

export const SOURCE_TYPES = {
  camera: {
    label: 'Camera',
    defaults: { camera: '', fit: 'cover', vhs: true, crop: { top: 0, right: 0, bottom: 0, left: 0 } },
    fields: [
      { key: 'camera', label: 'Device', kind: 'camera' },
      { key: 'fit', label: 'Fit', kind: 'select', options: ['cover', 'contain', 'stretch'] },
      { key: 'vhs', label: 'VHS overlay', kind: 'checkbox' },
      { key: 'crop.top', label: 'Crop top %', kind: 'number', min: 0, max: 95 },
      { key: 'crop.bottom', label: 'Crop bottom %', kind: 'number', min: 0, max: 95 },
      { key: 'crop.left', label: 'Crop left %', kind: 'number', min: 0, max: 95 },
      { key: 'crop.right', label: 'Crop right %', kind: 'number', min: 0, max: 95 },
    ],
    create: (stage) => new CameraView(stage),
  },
  text: {
    label: 'Text',
    defaults: { text: 'TEXT', size: 96, color: '#ffffff', font: 'Arial Black', align: 'center' },
    fields: [
      { key: 'text', label: 'Text', kind: 'textarea' },
      { key: 'size', label: 'Size', kind: 'number', min: 4, max: 1000 },
      { key: 'color', label: 'Colour', kind: 'color' },
      fontField,
      { key: 'align', label: 'Align', kind: 'select', options: ['left', 'center', 'right'] },
    ],
    create: () => new TextView(),
  },
  color: {
    label: 'Colour',
    defaults: { color: '#ff2a6d' },
    fields: [{ key: 'color', label: 'Colour', kind: 'color' }],
    create: () => new ColorView(),
  },
  stat: {
    label: 'Stat',
    box: [0.25, 0.18], // a new one's size, as shares of the screen
    defaults: { stat: 'score', label: 'SCORE', size: 120, color: '#ffd23f', labelColor: '#ff2a6d', font: 'Arial Black', align: 'center', glow: true },
    fields: [
      { key: 'stat', label: 'Shows', kind: 'select', options: Object.keys(STATS) },
      { key: 'label', label: 'Label', kind: 'text' },
      { key: 'size', label: 'Size', kind: 'number', min: 4, max: 1000 },
      { key: 'color', label: 'Colour', kind: 'color' },
      { key: 'labelColor', label: 'Label colour', kind: 'color' },
      fontField,
      { key: 'align', label: 'Align', kind: 'select', options: ['left', 'center', 'right'] },
      { key: 'glow', label: 'Neon glow', kind: 'checkbox' },
    ],
    create: (stage) => new StatView(stage),
  },
  meter: {
    label: 'Rhythm meter',
    box: [0.6, 0.08],
    defaults: { size: 40, font: 'Arial Black', fast: '#2de2e6', sweet: '#ffd23f', slow: '#ff2a6d',
      fastLabel: 'TOO FAST', sweetLabel: 'PERFECT', slowLabel: 'TOO SLOW' },
    fields: [
      { key: 'size', label: 'Label size', kind: 'number', min: 4, max: 400 },
      fontField,
      { key: 'fastLabel', label: 'Too fast says', kind: 'text' },
      { key: 'sweetLabel', label: 'Sweet spot says', kind: 'text' },
      { key: 'slowLabel', label: 'Too slow says', kind: 'text' },
      { key: 'fast', label: 'Too fast', kind: 'color' },
      { key: 'sweet', label: 'Perfect', kind: 'color' },
      { key: 'slow', label: 'Too slow', kind: 'color' },
    ],
    create: (stage) => new MeterView(stage),
  },
  callout: {
    label: 'Callout',
    box: [0.6, 0.25],
    defaults: { size: 120, font: 'Impact', seconds: 1.4, states: ['excitement', 'plateau'] },
    fields: [
      { key: 'size', label: 'Size', kind: 'number', min: 4, max: 1000 },
      fontField,
      { key: 'seconds', label: 'Seconds shown', kind: 'number', min: 0.3, max: 10 },
    ],
    create: () => new CalloutView(),
  },
  banner: {
    label: 'Banner',
    box: [0.8, 0.5],
    defaults: { size: 110, lineSize: 0, color: '#ffffff', accent: '#ffd23f', font: 'Arial Black', backdrop: '#000000',
      backdropOpacity: 0, states: ['idle', 'excitement', 'resolution'] },
    fields: [
      { key: 'size', label: 'Title size', kind: 'number', min: 4, max: 1000 },
      { key: 'lineSize', label: 'Line size (0: auto)', kind: 'number', min: 0, max: 400 },
      { key: 'color', label: 'Colour', kind: 'color' },
      { key: 'accent', label: 'Title colour', kind: 'color' },
      fontField,
      { key: 'backdrop', label: 'Backdrop', kind: 'color' },
      { key: 'backdropOpacity', label: 'Backdrop %', kind: 'number', min: 0, max: 100 },
    ],
    create: (stage) => new BannerView(stage),
  },
  detection: {
    label: 'Detection view',
    box: [0.4, 0.4],
    defaults: {},
    fields: [],
    create: (stage) => new CameraView(stage, DETECTION_VIEW),
  },
  gauge: {
    label: 'Gauge',
    box: [0.28, 0.07],
    defaults: { value: 'pleasure', label: 'YOUR PLEASURE', orientation: 'horizontal', size: 36, font: 'Arial Black', low: '#555555', high: '#ffd23f' },
    fields: [
      { key: 'value', label: 'Shows', kind: 'select', options: ['pleasure', 'arousal', 'jackpot'] },
      { key: 'label', label: 'Label', kind: 'text' },
      { key: 'orientation', label: 'Direction', kind: 'select', options: ['horizontal', 'vertical'] },
      { key: 'size', label: 'Label size', kind: 'number', min: 4, max: 400 },
      fontField,
      { key: 'low', label: 'Colour at 0%', kind: 'color' },
      { key: 'high', label: 'Colour at 100%', kind: 'color' },
    ],
    create: (stage) => new GaugeView(stage),
  },
  reservoir: {
    label: 'Reservoir',
    box: [0.16, 0.5],
    defaults: { label: 'DOPAMINE', size: 32, font: 'Arial Black', labelColor: '#ffffff', low: COLD, high: HOT },
    fields: [
      { key: 'label', label: 'Label', kind: 'text' },
      { key: 'size', label: 'Label size', kind: 'number', min: 4, max: 400 },
      fontField,
      { key: 'labelColor', label: 'Label colour', kind: 'color' },
      { key: 'low', label: 'Cold colour', kind: 'color' },
      { key: 'high', label: 'Hot colour', kind: 'color' },
    ],
    create: (stage) => new ReservoirView(stage),
  },
  heartbeat: {
    label: 'Heartbeat',
    box: [0.28, 0.16],
    defaults: { size: 32, font: 'Consolas', low: COLD, high: HOT },
    fields: [
      { key: 'size', label: 'Text size', kind: 'number', min: 4, max: 400 },
      fontField,
      { key: 'low', label: 'Cold colour', kind: 'color' },
      { key: 'high', label: 'Hot colour', kind: 'color' },
    ],
    create: (stage) => new HeartbeatView(stage),
  },
  flush: {
    label: 'Flush',
    box: [0.33, 1],
    defaults: { low: COLD, high: HOT, breathe: true },
    fields: [
      { key: 'low', label: 'Cold colour', kind: 'color' },
      { key: 'high', label: 'Hot colour', kind: 'color' },
      { key: 'breathe', label: 'Breathes', kind: 'checkbox' },
    ],
    create: (stage) => new FlushView(stage),
  },
  hits: {
    label: 'Dopamine hits',
    box: [1, 1],
    defaults: { from: '', to: '', color: '#ffd6ef' },
    fields: [
      { key: 'from', label: 'From', kind: 'item' },
      { key: 'to', label: 'To', kind: 'item' },
      { key: 'color', label: 'Colour', kind: 'color' },
    ],
    create: (stage) => new HitsView(stage),
  },
  voice: {
    label: 'Machine voice',
    box: [0.5, 0.12],
    defaults: { size: 48, font: 'Georgia', color: '#ffd6ef', align: 'center', seconds: 3, speak: false },
    fields: [
      { key: 'size', label: 'Size', kind: 'number', min: 4, max: 400 },
      fontField,
      { key: 'color', label: 'Colour', kind: 'color' },
      { key: 'align', label: 'Align', kind: 'select', options: ['left', 'center', 'right'] },
      { key: 'seconds', label: 'Held for (s)', kind: 'number', min: 0.5, max: 20 },
      { key: 'speak', label: 'Speak it (flat voice)', kind: 'checkbox' },
    ],
    create: (stage) => new VoiceView(stage),
  },
  face: {
    label: 'IT face',
    box: [0.3, 0.55],
    defaults: FACE_DEFAULTS,
    fields: [
      { key: 'board', label: 'Board colour', kind: 'color' },
      { key: 'rig', label: 'Head rig', kind: 'checkbox' },
      { key: 'wires', label: 'Wires', kind: 'checkbox' },
      { key: 'tint', label: 'Flushes with arousal', kind: 'checkbox' },
      { key: 'low', label: 'Cold colour', kind: 'color' },
      { key: 'high', label: 'Hot colour', kind: 'color' },
    ],
    create: (stage) => new FaceView(stage),
  },
  mirror: {
    label: 'You mirror',
    box: [0.32, 1],
    defaults: MIRROR_DEFAULTS,
    fields: [
      { key: 'dim', label: 'Darken %', kind: 'number', min: 0, max: 95 },
      { key: 'caption', label: 'Caption', kind: 'text' },
      { key: 'captionSize', label: 'Caption size (0: none)', kind: 'number', min: 0, max: 200 },
    ],
    create: (stage) => new MirrorView(stage),
  },
  reelface: {
    label: 'Reel face',
    box: [1, 1],
    defaults: REEL_FACE_DEFAULTS,
    fields: [
      { key: 'background', label: 'Background', kind: 'color' },
      { key: 'shade', label: 'Facet shading %', kind: 'number', min: 0, max: 100 },
      { key: 'turn', label: 'Turns (degrees)', kind: 'number', min: 0, max: 90 },
      { key: 'size', label: 'Prompt size', kind: 'number', min: 4, max: 400 },
      fontField,
      { key: 'color', label: 'Prompt colour', kind: 'color' },
    ],
    create: (stage) => new ReelFaceView(stage),
  },
  payout: {
    label: 'Payout (YOU / IT)',
    box: [0.7, 0.6],
    defaults: { size: 34, font: 'Consolas', youColor: '#cccccc', itColor: HOT, states: ['resolution'] },
    fields: [
      { key: 'size', label: 'Size', kind: 'number', min: 4, max: 400 },
      fontField,
      { key: 'youColor', label: 'YOU colour', kind: 'color' },
      { key: 'itColor', label: 'IT colour', kind: 'color' },
    ],
    create: (stage) => new PayoutView(stage),
  },
};

// Statuses where the camera isn't giving a picture worth showing.
const NO_PICTURE = {
  no_signal: 'NO SIGNAL',
  missing: 'CAMERA NOT FOUND',
  busy: 'CAMERA BUSY',
  lost: 'CAMERA LOST',
  stopped: 'CAMERA OFF',
};

// The cameras a screen needs frames from.
export function camerasIn(screen) {
  if (!screen) return [];
  // The reel face needs the face camera too, for capturing the face.
  const fixed = { detection: [DETECTION_VIEW], mirror: [MIRROR_VIEW], reelface: [REEL_FACE_VIEW, MIRROR_VIEW] };
  return screen.items.flatMap((item) => (item.type === 'camera' ? [item.camera] : fixed[item.type] ?? []));
}

export class Stage {
  constructor(container) {
    this.container = container;
    this.el = document.createElement('div');
    this.el.className = 'stage';
    // For the climax: everything (and a white layer over it) in one body that
    // can collapse to a line, in front of black for the fake shutdown.
    this.blackEl = layer('stage-black');
    this.bodyEl = layer('stage-body');
    this.itemsEl = layer('stage-items');
    this.whiteEl = layer('stage-white');
    this.bodyEl.append(this.itemsEl, this.whiteEl);
    this.el.append(this.blackEl, this.bodyEl);
    container.append(this.el);
    this.speechAllowed = false; // screens may speak; the editor doesn't
    this.editing = false; // the editor's preview, which shows stand-ins for what isn't there
    this.send = null; // to the eye, for views that report back (the reel face's capture)
    this.reelFaceInfo = null; // the reel face's latest state from the eye

    this.screen = null;
    this.views = new Map();
    this.feeds = new Map();
    this.cameraStatus = {};
    this.game = null;
    this.gameReceivedAt = 0;
    this.gameText = null; // the banner wording, for previews
    this.previewState = null; // the editor can show a state other than the live one...
    this.previewSession = null; // ...and a point part-way through a session
    this.scale = 1;
    this.onLayout = () => {};

    new ResizeObserver(() => this.fit()).observe(container);
    const tick = (now) => {
      for (const view of this.views.values()) view.draw?.(now);
      this.drawClimax();
      requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }

  get state() {
    return this.previewState ?? this.game?.state ?? 'idle';
  }

  // The game's numbers as of now: the snapshot, with the clocks moved on since it arrived.
  liveGame() {
    if (!this.game) return null;
    if (this.previewSession !== null) return { ...this.game, ...sessionAt(this.previewSession) };
    const elapsed = isScrolling(this.game) ? (performance.now() - this.gameReceivedAt) / 1000 : 0;
    return { ...this.game, dwell: this.game.dwell + elapsed, session_time: this.game.session_time + elapsed };
  }

  // The editor's session slider: show the curves as they'd be part-way
  // through a session (0 = the first swipe, 1 = just before the climax).
  setPreviewSession(share) {
    this.previewSession = share;
    if (this.game) this.setGame(this.game);
  }

  isShown(item) {
    return item.visible !== false && (!item.states || item.states.includes(this.state));
  }

  show(screen) {
    this.screen = screen;
    this.el.hidden = !screen;
    if (!screen) return;
    Object.assign(this.el.style, {
      width: `${screen.width}px`,
      height: `${screen.height}px`,
      background: screen.background || '#000',
    });

    const shown = new Set();
    screen.items.forEach((item, index) => {
      const type = SOURCE_TYPES[item.type];
      if (!type) return;
      let view = this.views.get(item.id);
      if (view && view.type !== item.type) {
        view.el.remove();
        view = null;
      }
      if (!view) {
        view = type.create(this);
        view.type = item.type;
        view.el.classList.add('stage-item');
        this.views.set(item.id, view);
        if (this.game) view.game?.(this.game);
      }
      view.item = item;
      Object.assign(view.el.style, {
        left: `${item.x}px`,
        top: `${item.y}px`,
        width: `${item.w}px`,
        height: `${item.h}px`,
        display: this.isShown(item) ? '' : 'none',
        opacity: String((item.opacity ?? 100) / 100),
      });
      view.update(item);
      // Later items sit on top, like layers.
      if (this.itemsEl.children[index] !== view.el) this.itemsEl.insertBefore(view.el, this.itemsEl.children[index] ?? null);
      shown.add(item.id);
    });
    for (const [id, view] of this.views) {
      if (!shown.has(id)) {
        view.el.remove();
        this.views.delete(id);
      }
    }
    this.fit();
  }

  fit() {
    if (!this.screen) return;
    const { clientWidth, clientHeight } = this.container;
    const scale = Math.min(clientWidth / this.screen.width, clientHeight / this.screen.height) || 1;
    const left = (clientWidth - this.screen.width * scale) / 2;
    const top = (clientHeight - this.screen.height * scale) / 2;
    this.el.style.transform = `translate(${left}px, ${top}px) scale(${scale})`;
    this.scale = scale;
    this.onLayout();
  }

  frame(camera, bitmap) {
    this.feeds.get(camera)?.close();
    this.feeds.set(camera, bitmap);
  }

  dropFeed(camera) {
    this.feeds.get(camera)?.close();
    this.feeds.delete(camera);
  }

  setStatus(cameras) {
    this.cameraStatus = cameras ?? {};
  }

  setGame(snapshot) {
    const stateChanged = snapshot.state !== this.game?.state;
    this.game = snapshot;
    this.gameReceivedAt = performance.now();
    // The visitor's side drifts from saturated casino to grey as YOUR PLEASURE drains.
    const pleasure = this.previewSession !== null ? sessionAt(this.previewSession).pleasure
      : this.previewState ? 1 : snapshot.pleasure ?? 1;
    for (const view of this.views.values()) {
      view.game?.(snapshot);
      view.el.style.filter = view.item?.fades ? `saturate(${pleasure}) brightness(${0.55 + 0.45 * pleasure})` : '';
    }
    if (stateChanged) this.refreshVisibility();
  }

  gameEvent(event) {
    for (const view of this.views.values()) {
      if (this.isShown(view.item)) view.event?.(event);
    }
  }

  say(event) {
    // Even to a voice that's hidden right now: a line can arrive a moment
    // before the phase change that shows it.
    for (const view of this.views.values()) view.say?.(event);
  }

  hit(event) {
    for (const view of this.views.values()) {
      if (this.isShown(view.item)) view.hit?.(event);
    }
  }

  reelFace(info) {
    if (!info) return;
    this.reelFaceInfo = info.mesh || !this.reelFaceInfo?.mesh || !info.version ? info : { ...info, mesh: this.reelFaceInfo.mesh };
    for (const view of this.views.values()) view.reelFace?.(info);
  }

  // Petite mort: one slow white-out (no flashing), held, then the picture
  // collapses to a line and goes black, a fake shutdown. Timed from when the
  // climax began, so every screen does it together.
  drawClimax() {
    const game = this.game;
    const on = this.screen && this.screen.climax !== false && this.state === 'climax';
    if (!on) {
      if (this.climaxShown) {
        this.climaxShown = false;
        this.whiteEl.style.opacity = '0';
        this.blackEl.style.opacity = '0';
        this.bodyEl.style.transform = '';
      }
      return;
    }
    this.climaxShown = true;
    const seconds = this.previewState ? 6 : (game?.state_time ?? 0) + (performance.now() - this.gameReceivedAt) / 1000;
    const p = Math.min(1, seconds / (game?.climax_seconds || 14));
    const between = (from, to) => Math.min(1, Math.max(0, (p - from) / (to - from)));
    const white = between(0, 0.35);
    this.whiteEl.style.opacity = String(white * white * (3 - 2 * white));
    const squash = between(0.55, 0.61);
    const narrow = between(0.61, 0.68);
    this.bodyEl.style.transform = `scale(${1 - 0.995 * narrow}, ${1 - 0.996 * squash})`;
    this.blackEl.style.opacity = p >= 0.55 ? '1' : '0';
  }

  setPreviewState(state) {
    this.previewState = state || null;
    if (this.game) for (const view of this.views.values()) view.game?.(this.game);
    this.refreshVisibility();
  }

  // What the banner says: the live game's, or sample wording when the editor previews another state.
  banner() {
    const state = this.state;
    if (!this.game || state === this.game.state || !this.gameText) return this.game?.banner ?? null;
    const text = this.gameText;
    if (state === 'idle') return { title: text.idle, lines: [] };
    if (state === 'excitement') return { title: text.onboarding[0], lines: [`1 / ${text.onboarding.length}`] };
    if (state === 'resolution') return { title: text.resolution, lines: [] };
    return null;
  }

  refreshVisibility() {
    for (const view of this.views.values()) view.el.style.display = this.isShown(view.item) ? '' : 'none';
    this.onLayout();
  }
}

class CameraView {
  constructor(stage, fixedCamera = null) {
    this.stage = stage;
    this.fixedCamera = fixedCamera;
    this.el = document.createElement('canvas');
    this.ctx = this.el.getContext('2d');
    this.startedAt = performance.now();
  }

  update(item) {
    const w = Math.max(2, Math.round(item.w));
    const h = Math.max(2, Math.round(item.h));
    if (this.el.width !== w || this.el.height !== h) {
      this.el.width = w;
      this.el.height = h;
    }
  }

  draw(now) {
    const { ctx, item } = this;
    if (!item || this.el.style.display === 'none') return;
    const { width: w, height: h } = this.el;
    const camera = this.fixedCamera ?? item.camera;
    const bitmap = this.stage.feeds.get(camera);
    if (this.fixedCamera) {
      if (bitmap) drawFeed(ctx, bitmap, { fit: 'contain' }, w, h);
      else drawNoSignal(ctx, w, h, 'NO DETECTION CAMERA');
      return;
    }
    const status = this.stage.cameraStatus[camera]?.status;
    const problem = !camera ? 'NO CAMERA CHOSEN' : NO_PICTURE[status] ?? (bitmap ? null : 'STARTING');
    if (problem) drawNoSignal(ctx, w, h, problem);
    else drawFeed(ctx, bitmap, item, w, h);
    if (item.vhs) drawVHS(ctx, w, h, now, this.startedAt, !problem);
  }
}

function drawFeed(ctx, bitmap, item, w, h) {
  const crop = item.crop ?? {};
  const sx = (bitmap.width * (crop.left || 0)) / 100;
  const sy = (bitmap.height * (crop.top || 0)) / 100;
  const sw = Math.max(1, bitmap.width * (1 - ((crop.left || 0) + (crop.right || 0)) / 100));
  const sh = Math.max(1, bitmap.height * (1 - ((crop.top || 0) + (crop.bottom || 0)) / 100));
  let dx = 0;
  let dy = 0;
  let dw = w;
  let dh = h;
  if (item.fit !== 'stretch') {
    const scale = (item.fit === 'contain' ? Math.min : Math.max)(w / sw, h / sh);
    dw = sw * scale;
    dh = sh * scale;
    dx = (w - dw) / 2;
    dy = (h - dh) / 2;
  }
  ctx.fillStyle = '#000';
  ctx.fillRect(0, 0, w, h);
  ctx.filter = item.vhs ? 'saturate(1.3) contrast(1.08) blur(0.6px)' : 'none';
  ctx.drawImage(bitmap, sx, sy, sw, sh, dx, dy, dw, dh);
  ctx.filter = 'none';
}

class TextView {
  constructor() {
    this.el = document.createElement('div');
    this.el.className = 'text-source';
  }

  update(item) {
    this.el.textContent = item.text;
    Object.assign(this.el.style, {
      fontSize: `${item.size}px`,
      color: item.color,
      fontFamily: `"${item.font}", sans-serif`,
      textAlign: item.align,
      justifyContent: justify(item.align),
    });
  }
}

class ColorView {
  constructor() {
    this.el = document.createElement('div');
  }

  update(item) {
    this.el.style.background = item.color;
  }
}

class StatView {
  constructor(stage) {
    this.stage = stage;
    this.el = document.createElement('div');
    this.el.className = 'stat-source';
    this.labelEl = document.createElement('div');
    this.labelEl.className = 'stat-label';
    this.valueEl = document.createElement('div');
    this.valueEl.className = 'stat-value';
    this.el.append(this.labelEl, this.valueEl);
    this.shownScore = 0;
    this.lastText = '';
  }

  update(item) {
    this.stat = STATS[item.stat] ?? STATS.score;
    this.labelEl.textContent = item.label;
    this.labelEl.hidden = !item.label;
    Object.assign(this.el.style, { fontFamily: `"${item.font}", sans-serif`, alignItems: justify(item.align), textAlign: item.align });
    Object.assign(this.labelEl.style, { fontSize: `${Math.round(item.size * 0.32)}px`, color: item.labelColor });
    Object.assign(this.valueEl.style, {
      fontSize: `${item.size}px`,
      color: item.color,
      textShadow: item.glow ? `0 0 ${item.size * 0.12}px ${item.color}, 0 0 ${item.size * 0.3}px ${item.color}` : 'none',
    });
  }

  draw() {
    const game = this.stage.liveGame();
    if (!game) return;
    let text;
    if (this.stat.rolls) {
      // The score counts up to its new value rather than jumping.
      this.shownScore += (game.score - this.shownScore) * 0.15;
      if (Math.abs(game.score - this.shownScore) < 1) this.shownScore = game.score;
      text = Math.round(this.shownScore).toLocaleString('en-US');
    } else {
      text = this.stat.show(game);
    }
    if (text === this.lastText) return;
    const grew = parseFloat(text.replace(/[^\d.]/g, '')) > parseFloat(this.lastText.replace(/[^\d.]/g, ''));
    this.valueEl.textContent = text;
    if (grew && !this.stat.rolls && this.item.stat !== 'time' && this.item.stat !== 'jackpot') bump(this.valueEl);
    this.lastText = text;
  }
}

class MeterView {
  constructor(stage) {
    this.stage = stage;
    this.el = document.createElement('div');
    this.el.className = 'meter-source';
    this.zones = ['fast', 'sweet', 'slow'].map((band) => {
      const zone = document.createElement('div');
      zone.className = `meter-zone meter-${band}`;
      zone.textContent = { fast: 'TOO FAST', sweet: 'PERFECT', slow: 'TOO SLOW' }[band];
      this.el.append(zone);
      return zone;
    });
    this.last = document.createElement('div');
    this.last.className = 'meter-last';
    this.needle = document.createElement('div');
    this.needle.className = 'meter-needle';
    this.el.append(this.last, this.needle);
  }

  update(item) {
    this.el.style.fontFamily = `"${item.font}", sans-serif`;
    this.el.style.fontSize = `${item.size}px`;
    this.zones.forEach((zone, index) => {
      zone.style.setProperty('--zone', [item.fast, item.sweet, item.slow][index]);
      zone.textContent = [item.fastLabel ?? 'TOO FAST', item.sweetLabel ?? 'PERFECT', item.slowLabel ?? 'TOO SLOW'][index];
    });
  }

  draw() {
    const game = this.stage.liveGame();
    if (!game) return;
    const playing = isScrolling(game);
    const position = meterPosition(playing ? game.dwell : 0, game.bands);
    this.needle.style.left = `${position * 100}%`;
    this.needle.hidden = !playing;
    const band = position < 0.2 ? 0 : position <= 0.75 ? 1 : 2;
    this.zones.forEach((zone, index) => zone.classList.toggle('active', playing && index === band));
    if (game.last) this.last.style.left = `${meterPosition(game.last.dwell, game.bands) * 100}%`;
    this.last.hidden = !game.last || !playing;
  }
}

// Where a dwell time sits on the meter: each band gets a fixed share of the width.
function meterPosition(dwell, bands) {
  const { too_fast: fast, too_slow: slow, penalty_after: penalty } = bands;
  if (dwell < fast) return 0.2 * (dwell / fast);
  if (dwell <= slow) return 0.2 + 0.55 * ((dwell - fast) / (slow - fast));
  return 0.75 + 0.25 * Math.min(1, (dwell - slow) / (penalty - slow));
}

class CalloutView {
  constructor() {
    this.el = document.createElement('div');
    this.el.className = 'callout-source';
    this.textEl = document.createElement('div');
    this.textEl.className = 'callout-text';
    this.detailEl = document.createElement('div');
    this.detailEl.className = 'callout-detail';
    this.el.append(this.textEl, this.detailEl);
  }

  update(item) {
    this.seconds = item.seconds;
    this.el.style.fontFamily = `"${item.font}", sans-serif`;
    this.textEl.style.fontSize = `${item.size}px`;
    this.detailEl.style.fontSize = `${Math.round(item.size * 0.45)}px`;
  }

  event(gameEvent) {
    this.textEl.textContent = gameEvent.text;
    this.detailEl.textContent = gameEvent.detail;
    this.el.dataset.tone = gameEvent.tone;
    this.el.style.animation = 'none';
    void this.el.offsetWidth; // restart the animation
    this.el.style.animation = `callout ${this.seconds}s ease-out forwards`;
  }
}

class BannerView {
  constructor(stage) {
    this.stage = stage;
    this.el = document.createElement('div');
    this.el.className = 'banner-source';
    this.titleEl = document.createElement('div');
    this.titleEl.className = 'banner-title';
    this.linesEl = document.createElement('div');
    this.linesEl.className = 'banner-lines';
    this.el.append(this.titleEl, this.linesEl);
  }

  update(item) {
    Object.assign(this.el.style, { fontFamily: `"${item.font}", sans-serif`, color: item.color });
    Object.assign(this.titleEl.style, {
      fontSize: `${item.size}px`,
      color: item.accent,
      textShadow: `0 0 ${item.size * 0.15}px ${item.accent}`,
    });
    this.linesEl.style.fontSize = `${item.lineSize || Math.round(item.size * 0.42)}px`;
    this.backdrop = item.backdropOpacity
      ? `${item.backdrop}${Math.round((item.backdropOpacity / 100) * 255).toString(16).padStart(2, '0')}` : 'transparent';
  }

  game() {
    const banner = this.stage.banner() ?? { title: '', lines: [] };
    if (this.titleEl.textContent !== banner.title) this.titleEl.textContent = banner.title;
    const lines = banner.lines.join('\n');
    if (this.linesEl.textContent !== lines) this.linesEl.textContent = lines;
    this.el.classList.toggle('attract', this.stage.state === 'idle');
    // The backdrop is only there while there's something to read on it.
    this.el.style.background = banner.title ? this.backdrop : 'transparent';
  }
}

// Roughly what a committed visitor's numbers look like a share of the way to the climax.
function sessionAt(share) {
  const reels = Math.round(1 + 60 * share);
  return {
    scrolling: true,
    arousal: share,
    pleasure: Math.max(0.03, 1 - 0.95 * share),
    bpm: Math.round(58 + 100 * share),
    breaths: 8 + 26 * share,
    jackpot: (0.25 + 1.6 * share) % 0.97,
    reels,
    score: Math.round(28000 * share ** 0.6),
    streak: reels % 11,
    multiplier: [1, 2, 5, 10][Math.min(3, Math.floor((reels % 11) / 3))],
    success: 74,
    session_time: Math.round(215 * share),
    dwell: 2.5,
    last: { band: 'sweet', dwell: 3.1 },
  };
}

// In excitement or plateau, with the first swipe made: the clocks are running.
function isScrolling(game) {
  return (game.state === 'excitement' || game.state === 'plateau') && game.scrolling;
}

function layer(className) {
  const element = document.createElement('div');
  element.className = className;
  return element;
}

function bump(element) {
  element.classList.remove('bump');
  void element.offsetWidth;
  element.classList.add('bump');
}

function justify(align) {
  return { left: 'flex-start', center: 'center', right: 'flex-end' }[align] ?? 'center';
}

function clock(seconds) {
  const whole = Math.max(0, Math.floor(seconds));
  return `${Math.floor(whole / 60)}:${String(whole % 60).padStart(2, '0')}`;
}

// The same slowly climbing number on every screen, from the clock.
function fakeJackpot() {
  const seconds = Date.now() / 1000;
  return `$${Math.floor(4_200_000 + (seconds % 86_400) * 37.7).toLocaleString('en-US')}`;
}
