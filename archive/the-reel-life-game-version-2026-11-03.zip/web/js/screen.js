// One screen, at /screen/<id>: shows that screen's layout from the setup and
// the live game, and follows every change made in the editor.
//
// Operator keys: D debug readout · Space fake swipe · P phone in / out / auto
// · 1-5 jump to a phase: idle, excitement, plateau, climax, resolution

import { connect } from './link.js';
import { playSound, unlockSound, updateBody } from './sound.js';
import { Stage, GAME_STATES, camerasIn } from './stage.js';

const screenId = decodeURIComponent(location.pathname.split('/').pop());
const stage = new Stage(document.getElementById('root'));

// A still of any moment, for documentation or tweaking the look:
// /screen/game?state=plateau&session=70 (session: 0-100% of the way to the climax).
const asked = new URLSearchParams(location.search);
if (asked.has('state')) stage.setPreviewState(asked.get('state'));
if (asked.has('session')) stage.setPreviewSession(Number(asked.get('session')) / 100);
const debug = document.getElementById('debug');
const notice = document.getElementById('notice');

let screen = null;
let cameras = {};
let phoneOverride = null;
let framesThisSecond = {};
let framesPerSecond = {};

const link = connect({
  onMessage,
  onFrame(name, bitmap) {
    stage.frame(name, bitmap);
    framesThisSecond[name] = (framesThisSecond[name] ?? 0) + 1;
  },
  onConnection(connected) {
    showNotice(connected ? '' : 'EYE OFFLINE, RECONNECTING');
  },
});
stage.send = link.send;

function onMessage(message) {
  switch (message.type) {
    case 'hello':
      show(message.setup);
      applyStatus(message.status);
      stage.gameText = message.game_text;
      stage.setGame(message.game);
      stage.reelFace(message.reel_face);
      break;
    case 'reel_face':
      stage.reelFace(message);
      break;
    case 'setup':
      show(message.setup);
      break;
    case 'status':
      applyStatus(message);
      break;
    case 'game':
      stage.setGame(message);
      if (screen?.sound) updateBody(message);
      break;
    case 'game_event':
      stage.gameEvent(message);
      // The visitor's sounds thin out as their pleasure drains.
      if (screen?.sound) playSound(message.kind, stage.game?.pleasure ?? 1);
      break;
    case 'say':
      stage.say(message);
      break;
    case 'hit':
      stage.hit(message);
      break;
  }
}

function applyStatus(status) {
  cameras = status.cameras;
  phoneOverride = status.phone_override;
  stage.setStatus(cameras);
  stage.faces = status.faces?.recorded ?? {};
}

function show(setup) {
  screen = setup.screens.find((candidate) => candidate.id === screenId) ?? null;
  showNotice(screen ? '' : `NO SCREEN "${screenId}" IN THE SETUP`);
  stage.show(screen);
  stage.speechAllowed = Boolean(screen?.sound); // a voice source only speaks on a screen with sound on
  link.watch(camerasIn(screen));
  document.title = screen ? `${screen.name} · The Reel Life` : 'The Reel Life';
}

function showNotice(text) {
  notice.textContent = text;
  notice.hidden = !text;
}

addEventListener('pointerdown', unlockSound);
addEventListener('keydown', (event) => {
  unlockSound();
  const key = event.key.toLowerCase();
  if (key === 'd') debug.hidden = !debug.hidden;
  else if (key === ' ') link.send({ type: 'fake_swipe' });
  else if (key === 'p') link.send({ type: 'fake_phone', present: phoneOverride === null ? true : phoneOverride ? false : null });  else if (GAME_STATES[Number(key) - 1]) link.send({ type: 'force_state', state: GAME_STATES[Number(key) - 1] });
  else return;
  event.preventDefault();
});

setInterval(() => {
  framesPerSecond = framesThisSecond;
  framesThisSecond = {};
  if (debug.hidden || !screen) return;
  const game = stage.game ?? {};
  const lines = [
    `${screen.name} (${screenId}) ${screen.width}×${screen.height}, window ${innerWidth}×${innerHeight}`,
    `game: ${game.state}, phone ${game.phone ? 'in' : 'out'}${phoneOverride === null ? '' : ' (forced)'}, score ${game.score}`,
    `arousal ${Math.round(100 * (game.arousal ?? 0))}%, your pleasure ${Math.round(100 * (game.pleasure ?? 1))}%, ${game.bpm} bpm`,
    'keys: Space swipe · P phone · 1-5 phase · D hide',
  ];
  for (const name of new Set(camerasIn(screen).filter(Boolean))) {
    const camera = cameras[name] ?? {};
    lines.push(`${name}: ${camera.status ?? '-'}, capture ${camera.fps ?? 0} fps, here ${framesPerSecond[name] ?? 0} fps`);
  }
  debug.textContent = lines.join('\n');
}, 1000);
