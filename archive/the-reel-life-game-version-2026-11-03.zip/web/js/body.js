// The concept layer's sources: the visitor's draining pleasure, and the
// machine's body warming up (arousal, reservoir, heartbeat, flush), the
// dopamine hits travelling to it, its voice, and the two-column payout.
// "Dopamine" is a metaphor throughout, never a measurement.

export const COLD = '#2a5cff';
export const HOT = '#ff2a8d';

// Where a game value comes from, for gauges.
const VALUES = {
  pleasure: (game) => game.pleasure,
  arousal: (game) => game.arousal,
  jackpot: (game) => game.jackpot,
};

export function mix(from, to, amount) {
  const a = parseInt(from.slice(1), 16);
  const b = parseInt(to.slice(1), 16);
  const channel = (shift) => Math.round(((a >> shift) & 255) + (((b >> shift) & 255) - ((a >> shift) & 255)) * amount);
  return `rgb(${channel(16)}, ${channel(8)}, ${channel(0)})`;
}

export class GaugeView {
  constructor(stage) {
    this.stage = stage;
    this.el = document.createElement('div');
    this.el.className = 'gauge-source';
    this.labelEl = document.createElement('div');
    this.labelEl.className = 'gauge-label';
    this.track = document.createElement('div');
    this.track.className = 'gauge-track';
    this.fill = document.createElement('div');
    this.fill.className = 'gauge-fill';
    this.track.append(this.fill);
    this.el.append(this.labelEl, this.track);
  }

  update(item) {
    this.el.classList.toggle('vertical', item.orientation === 'vertical');
    Object.assign(this.el.style, { fontFamily: `"${item.font}", sans-serif`, fontSize: `${item.size}px` });
  }

  draw() {
    const game = this.stage.liveGame();
    if (!game || !this.item) return;
    const value = Math.max(0, Math.min(1, (VALUES[this.item.value] ?? VALUES.pleasure)(game)));
    const color = mix(this.item.low, this.item.high, value);
    this.fill.style[this.item.orientation === 'vertical' ? 'height' : 'width'] = `${value * 100}%`;
    this.fill.style[this.item.orientation === 'vertical' ? 'width' : 'height'] = '100%';
    this.fill.style.background = color;
    this.fill.style.boxShadow = `0 0 0.6em ${color}`;
    const text = `${this.item.label}  ${Math.round(value * 100)}%`;
    if (this.labelEl.textContent !== text) this.labelEl.textContent = text;
  }
}

export class ReservoirView {
  constructor(stage) {
    this.stage = stage;
    this.el = document.createElement('canvas');
    this.ctx = this.el.getContext('2d');
    this.level = 0;
    this.ripples = [];
  }

  update(item) {
    const w = Math.max(2, Math.round(item.w));
    const h = Math.max(2, Math.round(item.h));
    if (this.el.width !== w || this.el.height !== h) Object.assign(this.el, { width: w, height: h });
  }

  landed(strength) {
    this.ripples.push({ born: performance.now(), strength });
  }

  draw(now) {
    const game = this.stage.liveGame();
    const { ctx, item } = this;
    if (!item) return;
    const { width: w, height: h } = this.el;
    this.level += ((game?.arousal ?? 0) - this.level) * 0.06; // eases up as hits land
    ctx.clearRect(0, 0, w, h);
    const pad = Math.min(w, h) * 0.08;
    const top = pad + item.size * 1.6;
    const vessel = { x: pad, y: top, w: w - 2 * pad, h: h - top - pad };
    const radius = vessel.w * 0.18;

    ctx.save();
    roundRect(ctx, vessel.x, vessel.y, vessel.w, vessel.h, radius);
    ctx.clip();
    const surface = vessel.y + vessel.h * (1 - this.level);
    // All of the liquid takes the current heat, brighter at the surface.
    const color = mix(item.low, item.high, this.level);
    const gradient = ctx.createLinearGradient(0, surface, 0, vessel.y + vessel.h);
    gradient.addColorStop(0, mix(item.high, '#ffffff', 0.25 * this.level));
    gradient.addColorStop(0.15, color);
    gradient.addColorStop(1, mix(item.low, item.high, this.level * 0.6));
    ctx.fillStyle = gradient;
    ctx.beginPath();
    ctx.moveTo(vessel.x, vessel.y + vessel.h);
    for (let x = 0; x <= vessel.w; x += 4) {
      const wave = Math.sin(x / 18 + now / 400) * 3 + Math.sin(x / 7 - now / 250) * 1.5 * this.level;
      ctx.lineTo(vessel.x + x, surface + wave);
    }
    ctx.lineTo(vessel.x + vessel.w, vessel.y + vessel.h);
    ctx.closePath();
    ctx.shadowColor = color;
    ctx.shadowBlur = 30 * this.level;
    ctx.fill();
    // Rings where hits land.
    this.ripples = this.ripples.filter((ripple) => now - ripple.born < 900);
    for (const ripple of this.ripples) {
      const age = (now - ripple.born) / 900;
      ctx.strokeStyle = `rgba(255, 255, 255, ${(1 - age) * 0.8})`;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.ellipse(vessel.x + vessel.w / 2, surface, vessel.w * (0.1 + 0.4 * age) * (0.5 + ripple.strength), 6 + 10 * age, 0, 0, Math.PI * 2);
      ctx.stroke();
    }
    ctx.restore();

    ctx.strokeStyle = 'rgba(255, 255, 255, 0.55)';
    ctx.lineWidth = 3;
    roundRect(ctx, vessel.x, vessel.y, vessel.w, vessel.h, radius);
    ctx.stroke();
    ctx.fillStyle = item.labelColor;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'top';
    fitText(ctx, `${item.label} ${Math.round(this.level * 100)}%`, w / 2, pad * 0.5, w - 8, item.size, item.font);
  }
}

// Text at up to this size, smaller if that's what it takes to fit the width.
function fitText(ctx, text, x, y, width, size, font) {
  ctx.font = `${size}px "${font}", sans-serif`;
  const fitted = Math.min(size, Math.floor((size * width) / Math.max(1, ctx.measureText(text).width)));
  ctx.font = `${fitted}px "${font}", sans-serif`;
  ctx.fillText(text, x, y);
}

export class HeartbeatView {
  constructor(stage) {
    this.stage = stage;
    this.el = document.createElement('canvas');
    this.ctx = this.el.getContext('2d');
    this.samples = [];
    this.phase = 0;
    this.last = performance.now();
  }

  update(item) {
    const w = Math.max(2, Math.round(item.w));
    const h = Math.max(2, Math.round(item.h));
    if (this.el.width !== w || this.el.height !== h) Object.assign(this.el, { width: w, height: h });
  }

  draw(now) {
    const game = this.stage.liveGame();
    const { ctx, item } = this;
    if (!item) return;
    const { width: w, height: h } = this.el;
    const bpm = game?.bpm ?? 58;
    const arousal = game?.arousal ?? 0;
    // The trace scrolls at a steady speed; beats come as often as the heart rate says.
    const seconds = Math.min(0.1, (now - this.last) / 1000);
    this.last = now;
    const step = 1 / 120;
    for (let elapsed = 0; elapsed < seconds; elapsed += step) {
      this.phase = (this.phase + (step * bpm) / 60) % 1;
      this.samples.push(ecg(this.phase));
    }
    const shown = Math.round(w / 2);
    if (this.samples.length > shown) this.samples.splice(0, this.samples.length - shown);

    ctx.clearRect(0, 0, w, h);
    const color = mix(item.low, item.high, arousal);
    const textHeight = item.size * 1.4;
    const middle = textHeight + (h - textHeight) * 0.6;
    const amplitude = (h - textHeight) * 0.45;
    ctx.strokeStyle = color;
    ctx.lineWidth = Math.max(3, h / 40);
    ctx.lineJoin = 'round';
    ctx.shadowColor = color;
    ctx.shadowBlur = 16;
    ctx.beginPath();
    this.samples.forEach((value, index) => {
      const x = w - (this.samples.length - index) * 2;
      const y = middle - value * amplitude;
      if (index) ctx.lineTo(x, y);
      else ctx.moveTo(x, y);
    });
    ctx.stroke();
    ctx.shadowBlur = 0;
    ctx.fillStyle = color;
    ctx.font = `${item.size}px "${item.font}", sans-serif`;
    ctx.textBaseline = 'top';
    ctx.fillText(`♥ ${bpm} BPM`, 4, 2);
  }
}

// One heartbeat, as an ECG trace: a small P wave, the sharp QRS, a T wave.
function ecg(phase) {
  const bump = (centre, width, height) => height * Math.exp(-(((phase - centre) / width) ** 2));
  return bump(0.12, 0.025, 0.12) + bump(0.28, 0.008, -0.15) + bump(0.3, 0.01, 1) + bump(0.32, 0.009, -0.3) + bump(0.55, 0.05, 0.25);
}

export class FlushView {
  constructor(stage) {
    this.stage = stage;
    this.el = document.createElement('div');
    this.el.className = 'flush-source';
  }

  update() {}

  draw(now) {
    const game = this.stage.liveGame();
    if (!this.item) return;
    const arousal = game?.arousal ?? 0;
    // It breathes: a slow swell, at most once every couple of seconds.
    const breath = this.item.breathe ? 0.5 + 0.5 * Math.sin((now / 1000) * Math.PI * 2 * ((game?.breaths ?? 8) / 60)) : 1;
    const color = mix(this.item.low, this.item.high, arousal);
    this.el.style.background = `radial-gradient(ellipse at center, ${color} 0%, ${mix(this.item.low, '#000000', 0.6)} ${70 + 25 * breath}%)`;
  }
}

export class HitsView {
  constructor(stage) {
    this.stage = stage;
    this.el = document.createElement('canvas');
    this.el.className = 'hits-source';
    this.ctx = this.el.getContext('2d');
    this.drops = [];
  }

  update(item) {
    const w = Math.max(2, Math.round(item.w));
    const h = Math.max(2, Math.round(item.h));
    if (this.el.width !== w || this.el.height !== h) Object.assign(this.el, { width: w, height: h });
  }

  hit(event) {
    const from = this.centre(this.item.from, 0.5);
    const to = this.centre(this.item.to, 0.3);
    if (!from || !to) return;
    // The machine's taste: sweet-spot hits are big and fast, the rest weak and slow.
    const sweet = event.band === 'sweet' || event.band === 'first';
    this.drops.push({ from, to, born: performance.now(), seconds: sweet ? 0.7 : 1.6, size: 8 + 26 * event.strength, strength: event.strength });
  }

  centre(id, down) {
    const target = this.stage.screen?.items.find((candidate) => candidate.id === id);
    if (!target) return null;
    return { x: target.x + target.w / 2 - this.item.x, y: target.y + target.h * down - this.item.y };
  }

  draw(now) {
    const { ctx, item } = this;
    if (!item) return;
    ctx.clearRect(0, 0, this.el.width, this.el.height);
    this.drops = this.drops.filter((drop) => {
      const progress = (now - drop.born) / 1000 / drop.seconds;
      if (progress >= 1) {
        this.stage.views.get(item.to)?.landed?.(drop.strength);
        return false;
      }
      // An arc from the phone up and over to the reservoir, with a fading trail.
      for (let trail = 0; trail < 6; trail++) {
        const t = Math.max(0, progress - trail * 0.025);
        const x = (1 - t) ** 2 * drop.from.x + 2 * (1 - t) * t * ((drop.from.x + drop.to.x) / 2) + t ** 2 * drop.to.x;
        const lift = Math.min(drop.from.y, drop.to.y) - 220;
        const y = (1 - t) ** 2 * drop.from.y + 2 * (1 - t) * t * lift + t ** 2 * drop.to.y;
        ctx.fillStyle = trail ? `rgba(255, 120, 200, ${0.35 - trail * 0.05})` : item.color;
        ctx.shadowColor = item.color;
        ctx.shadowBlur = trail ? 0 : 25;
        ctx.beginPath();
        ctx.arc(x, y, drop.size * (1 - trail * 0.12), 0, Math.PI * 2);
        ctx.fill();
      }
      return true;
    });
    ctx.shadowBlur = 0;
  }
}

export class VoiceView {
  constructor(stage) {
    this.stage = stage;
    this.el = document.createElement('div');
    this.el.className = 'voice-source';
    this.textEl = document.createElement('div');
    this.el.append(this.textEl);
    this.line = '';
    this.saidAt = -1e9;
  }

  update(item) {
    Object.assign(this.el.style, {
      fontFamily: `"${item.font}", sans-serif`,
      fontSize: `${item.size}px`,
      color: item.color,
      textAlign: item.align,
      justifyContent: { left: 'flex-start', center: 'center', right: 'flex-end' }[item.align] ?? 'center',
    });
  }

  say(event) {
    this.line = event.text;
    this.saidAt = performance.now();
    if (this.item.speak && this.stage.speechAllowed && 'speechSynthesis' in window) {
      // Flat and synthetic, on purpose.
      const speech = new SpeechSynthesisUtterance(event.text);
      speech.pitch = 0.6;
      speech.rate = 0.9;
      speechSynthesis.cancel();
      speechSynthesis.speak(speech);
    }
  }

  draw(now) {
    if (!this.item) return;
    // Typed out a letter at a time, held, then faded.
    const age = (now - this.saidAt) / 1000;
    const shown = this.line.slice(0, Math.floor(age * 28));
    if (this.textEl.textContent !== shown) this.textEl.textContent = shown;
    const fadeFrom = this.line.length / 28 + this.item.seconds;
    this.el.style.opacity = age < fadeFrom ? '1' : String(Math.max(0, 1 - (age - fadeFrom) / 1.5));
  }
}

const SAMPLE_SUMMARY = {
  you: ['REELS CONSUMED: 61 (measured)', 'AVERAGE: 3.4 S PER REEL (measured)', 'MOMENTS YOU LINGERED: 3 · PUNISHED: 3',
    'STILLNESS CHALLENGE: FAILED', 'THUMB TRAVEL: 5.5 M (estimated)', 'YOUR PLEASURE: 4% (estimated)', 'WANTED: 61 TIMES. LIKED: UNCLEAR.'],
  it: ['HITS RECEIVED: 61', 'PEAK AROUSAL: 100%', 'TIME TO CLIMAX: 3:34', 'SATISFACTION: 100%', 'WAS IT GOOD FOR YOU? OUR RECORDS SAY NO.'],
};

export class PayoutView {
  constructor(stage) {
    this.stage = stage;
    this.el = document.createElement('div');
    this.el.className = 'payout-source';
    this.columns = ['you', 'it'].map((side) => {
      const column = document.createElement('div');
      column.className = `payout-column payout-${side}`;
      const heading = document.createElement('div');
      heading.className = 'payout-heading';
      heading.textContent = side.toUpperCase();
      const lines = document.createElement('div');
      lines.className = 'payout-lines';
      column.append(heading, lines);
      this.el.append(column);
      return { side, heading, lines };
    });
  }

  update(item) {
    Object.assign(this.el.style, { fontFamily: `"${item.font}", sans-serif`, fontSize: `${item.size}px` });
    this.columns[0].heading.style.color = item.youColor;
    this.columns[1].heading.style.color = item.itColor;
  }

  game(snapshot) {
    // In the editor's preview of resolution there's no real session: show a sample.
    const summary = snapshot.summary ?? (this.stage.previewState === 'resolution' ? SAMPLE_SUMMARY : null);
    for (const column of this.columns) {
      const text = summary ? summary[column.side].join('\n') : '';
      if (column.lines.textContent !== text) column.lines.textContent = text;
    }
  }
}

function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}
