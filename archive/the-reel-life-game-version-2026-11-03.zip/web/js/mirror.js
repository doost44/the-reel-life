// The YOU mirror: the visitor's own face, live, on their side of the game
// screen while they play. Mirrored, like a mirror, and draining to grey with
// YOUR PLEASURE (the source's "Fades with YOUR PLEASURE"), while IT's face
// flushes. The eye sends the picture only while someone is playing, and this
// drops it the moment they aren't: nothing is kept, here or there. Never
// shown on IT's face.

export const MIRROR_VIEW = '@mirror';

export const MIRROR_DEFAULTS = {
  dim: 30, caption: 'LIVE · NOT RECORDED', captionSize: 22, fades: true, states: ['excitement', 'plateau'],
};

export class MirrorView {
  constructor(stage) {
    this.stage = stage;
    this.el = document.createElement('canvas');
    this.ctx = this.el.getContext('2d');
  }

  update(item) {
    const w = Math.max(2, Math.round(item.w));
    const h = Math.max(2, Math.round(item.h));
    if (this.el.width !== w || this.el.height !== h) Object.assign(this.el, { width: w, height: h });
  }

  game(snapshot) {
    if (!snapshot.mirror) this.stage.dropFeed(MIRROR_VIEW);
  }

  draw() {
    const { ctx, item } = this;
    if (!item || this.el.style.display === 'none') return;
    const { width: w, height: h } = this.el;
    ctx.clearRect(0, 0, w, h);
    const bitmap = this.stage.game?.mirror ? this.stage.feeds.get(MIRROR_VIEW) : null;
    if (!bitmap) {
      // Nothing on a screen until someone plays; a stand-in in the editor, to lay it out.
      if (this.stage.editing) drawStandIn(ctx, w, h, this.stage.game?.mirror ? 'MIRROR CAMERA STARTING' : 'VISITOR\'S FACE · WHILE PLAYING');
      return;
    }
    ctx.save();
    ctx.translate(w, 0);
    ctx.scale(-1, 1);
    const scale = Math.max(w / bitmap.width, h / bitmap.height);
    ctx.drawImage(bitmap, (w - bitmap.width * scale) / 2, (h - bitmap.height * scale) / 2, bitmap.width * scale, bitmap.height * scale);
    ctx.restore();
    if (item.dim) {
      ctx.fillStyle = `rgba(0, 0, 0, ${item.dim / 100})`;
      ctx.fillRect(0, 0, w, h);
    }
    if (item.caption && item.captionSize) drawCaption(ctx, w, h, item.caption, item.captionSize);
  }
}

// Says what it is, every second it's on: live, and not recorded.
function drawCaption(ctx, w, h, text, size) {
  ctx.font = `${size}px Consolas, monospace`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  const band = size * 1.8;
  ctx.fillStyle = 'rgba(0, 0, 0, 0.55)';
  ctx.fillRect(0, h - band, w, band);
  ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
  ctx.fillText(text, w / 2, h - band / 2, w - size);
}

// Strong enough to see through the source's own opacity and the fade.
function drawStandIn(ctx, w, h, label) {
  ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
  const head = Math.min(w, h) * 0.22;
  ctx.beginPath();
  ctx.arc(w / 2, h * 0.4, head, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(w / 2, h * 0.4 + head * 3.1, head * 2, head * 1.6, 0, Math.PI, 0);
  ctx.fill();
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.8)';
  ctx.setLineDash([12, 8]);
  ctx.lineWidth = 4;
  ctx.strokeRect(2, 2, w - 4, h - 4);
  ctx.setLineDash([]);
  ctx.fillStyle = '#ffffff';
  ctx.font = `${Math.max(12, Math.round(w / 26))}px Consolas, monospace`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(label, w / 2, h * 0.08, w - 20);
}
