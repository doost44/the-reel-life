// The reel face: the visitor's own head, rebuilt from what they watch, as a 3D
// model on a plain background. The eye builds the head (face_capture.py) and
// sends its mesh (a reel_face message), its skin (the "@reelface" picture),
// which piece of reel each triangle belongs to, and the six distortion
// controls (distortion.py). This draws it with WebGL, turning slowly, and
// breaks it as the controls rise:
//
//   the head      pieces pulled apart and sliding (fracture_amount), whole
//                 patches or single triangles (shard_size), some missing,
//                 some doubled, the head pinched and stretched, each piece in
//                 its own mismatched tone (colour_shift)
//   the picture   bands stretched sideways and down (pixel_stretch), JPEG's
//                 squares and colour banding (jpeg_blockiness), the old
//                 picture dragged along in blocks (smear), colours split
//
// While the eye is asking for the face, it shows the face camera with the
// prompt and looks for the face itself (landmarks.js).

import { FaceFinder } from './landmarks.js';
import { MIRROR_VIEW } from './mirror.js';

export const REEL_FACE_VIEW = '@reelface';

export const REEL_FACE_DEFAULTS = { background: '#b4b1ab', shade: 60, turn: 35, size: 56, font: 'Arial Black', color: '#141414' };

const VIEWS = ['front', 'left', 'right'];
const CLEAN = { fracture_amount: 0, shard_size: 1, pixel_stretch: 0, jpeg_blockiness: 0, smear: 0, colour_shift: 0 };

const HEAD_VERTEX = `#version 300 es
in vec3 position;
in vec2 uv;
in vec3 normal;
in vec4 shard;   // the direction its piece comes away in, and which piece (w; -1: the visitor's own skin)
in vec3 facet;   // the direction this triangle comes away in on its own
uniform mat4 projection;
uniform mat4 model;
uniform float time;
uniform float fracture;
uniform float shardSize;
uniform float ghost;
out vec2 vUv;
out vec3 vNormal;
out float vSeed;
void main() {
  float seed = shard.w;
  float piece = step(0.0, seed);
  float slide = 0.65 + 0.35 * sin(time * 0.45 + seed * 37.0);
  vec3 apart = piece * shard.xyz * 0.12 * shardSize + facet * 0.025 * (1.0 - 0.6 * shardSize) * mix(0.35, 1.0, piece);
  vec3 p = position + fracture * slide * apart;
  // Pulled and pinched, like a stretched photograph of a head.
  p.x *= 1.0 + fracture * 0.2 * sin(p.y * 2.3 + time * 0.15);
  p.y *= 1.0 + fracture * 0.08 * cos(p.x * 3.1 - time * 0.1);
  p += ghost * vec3(0.16 * sin(seed * 17.0 + time * 0.2), 0.06 * cos(seed * 11.0), 0.05);
  vUv = uv;
  vNormal = mat3(model) * normal;
  vSeed = seed;
  gl_Position = projection * model * vec4(p, 1.0);
}`;

const HEAD_FRAGMENT = `#version 300 es
precision highp float;
in vec2 vUv;
in vec3 vNormal;
in float vSeed;
uniform sampler2D skin;
uniform float shade;
uniform float colourShift;
uniform float missing;
uniform float ghost;
uniform float doubled;
out vec4 colour;
float hash(float n) { return fract(sin(n * 12.9898 + 4.1414) * 43758.5453); }
void main() {
  bool piece = vSeed >= 0.0;
  if (piece && hash(vSeed + 0.5) < missing) discard;                      // gone
  if (ghost > 0.0 && (!piece || hash(vSeed + 1.5) > doubled)) discard;    // only some pieces are doubled
  vec3 c = texture(skin, vUv).rgb;
  if (piece) {
    vec3 tone = vec3(hash(vSeed + 2.5), hash(vSeed + 3.5), hash(vSeed + 4.5)) - 0.5;
    c *= 1.0 + colourShift * (tone * 0.35 + (hash(vSeed + 5.5) - 0.5) * 0.5);
  }
  float light = 0.55 + 0.45 * max(dot(normalize(vNormal), normalize(vec3(-0.35, 0.4, 1.0))), 0.0);
  colour = vec4(clamp(c * mix(1.0, light, shade), 0.0, 1.0), ghost > 0.0 ? 0.6 : 1.0);
}`;

const QUAD_VERTEX = `#version 300 es
in vec2 corner;
void main() { gl_Position = vec4(corner, 0.0, 1.0); }`;

// The picture's damage, from the head drawn on its own (scene) and the last
// frame's result (previous), which is how the smear drags.
const DAMAGE_FRAGMENT = `#version 300 es
precision highp float;
uniform sampler2D scene;
uniform sampler2D previous;
uniform vec2 size;
uniform float time;
uniform float stretch;
uniform float blocky;
uniform float smear;
uniform float shift;
out vec4 colour;
float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
vec4 at(vec2 px) { return texture(scene, px / size); }
void main() {
  vec2 px = gl_FragCoord.xy;
  float tick = floor(time * 2.5);  // the glitches jump a few times a second
  // Stretch: in some thin bands of rows, short runs repeat their first
  // pixel, smearing it sideways (and out past the head's edge); fewer
  // columns, downwards.
  vec2 from = px;
  float row = floor(px.y / (4.0 + 12.0 * hash(vec2(floor(px.y / 48.0), tick))));
  if (hash(vec2(row, tick + 3.0)) < stretch * 0.1) {
    float run = 40.0 + 160.0 * hash(vec2(row, tick + 7.0));
    from.x = floor((px.x + hash(vec2(row, tick + 9.0)) * run) / run) * run - hash(vec2(row, tick + 9.0)) * run;
  }
  float column = floor(px.x / 6.0);
  if (hash(vec2(column, tick + 11.0)) < stretch * 0.025) {
    float run = 30.0 + 90.0 * hash(vec2(column, tick + 13.0));
    from.y = floor(px.y / run) * run;
  }
  // JPEG: its squares (bigger as it worsens), some flattened to one colour;
  // colour taken from the square, light from the pixel; then banding.
  float square = floor(8.0 * (1.0 + blocky));
  vec2 cell = floor(from / square);
  vec2 middle = (cell + 0.5) * square;
  vec2 source = hash(cell + tick * 0.013) < blocky * 0.25 ? middle : from;
  vec4 here = at(source);
  vec4 block = at(middle);
  float split = shift * 4.0;
  vec3 c = vec3(at(source + vec2(split, 0.0)).r, here.g, at(source - vec2(split, split * 0.5)).b);
  float light = dot(c, vec3(0.299, 0.587, 0.114));
  vec3 chroma = block.rgb - dot(block.rgb, vec3(0.299, 0.587, 0.114));
  c = mix(c, light + chroma, blocky * 0.7);
  float levels = mix(64.0, 10.0, blocky);
  c = floor(c * levels + 0.5) / levels;
  // Smear: blocks of the old picture stay stuck and drift; behind the head, it trails.
  vec2 drift = (vec2(hash(floor(px / 32.0) + tick), hash(floor(px / 32.0) + tick + 5.0)) - 0.5) * 6.0 * smear;
  vec4 before = texture(previous, (px + drift) / size);
  float stuck = step(hash(floor(px / 16.0) + floor(time * 1.3)), smear * 0.12) * before.a;
  vec3 now = mix(c, before.rgb, stuck);
  float trail = before.a * smear * 0.8;
  float alpha = here.a + trail * (1.0 - here.a);
  colour = alpha > 0.0 ? vec4((now * here.a + before.rgb * trail * (1.0 - here.a)) / alpha, alpha) : vec4(0.0);
}`;

const SHOW_FRAGMENT = `#version 300 es
precision mediump float;
uniform sampler2D picture;
uniform vec3 background;
out vec4 colour;
void main() {
  vec4 p = texelFetch(picture, ivec2(gl_FragCoord.xy), 0);
  colour = vec4(mix(background, p.rgb, p.a), 1.0);
}`;

export class ReelFaceView {
  constructor(stage) {
    this.stage = stage;
    this.el = document.createElement('div');
    this.glCanvas = layerCanvas();
    this.overlay = layerCanvas();
    this.el.append(this.glCanvas, this.overlay);
    this.ctx = this.overlay.getContext('2d');
    this.gl = this.glCanvas.getContext('webgl2', { antialias: false });
    if (this.gl) this.setUpGl();
    this.info = null;
    this.mesh = null;
    this.pieces = null;
    this.skin = null;
    this.skinReady = false;
    this.controls = { ...CLEAN };
    this.lastDraw = 0;
    this.finder = new FaceFinder((message) => stage.send?.(message));
    if (stage.reelFaceInfo) this.reelFace(stage.reelFaceInfo);
  }

  update(item) {
    const w = Math.max(2, Math.round(item.w));
    const h = Math.max(2, Math.round(item.h));
    for (const canvas of [this.glCanvas, this.overlay]) {
      if (canvas.width !== w || canvas.height !== h) Object.assign(canvas, { width: w, height: h });
    }
    this.el.style.background = item.background;
  }

  reelFace(info) {
    this.info = info;
    if (info.shards) this.pieces = info.shards;
    if (info.mesh) this.loadMesh(info.mesh); // ...which loads the pieces too
    else if (info.shards) this.loadPieces();
    if (!info.version) this.mesh = null; // the visit ended, or a recapture: no head until the next one
  }

  draw(now) {
    const { item } = this;
    if (!item || this.el.style.display === 'none') return;
    const info = this.info ?? {};
    const seconds = Math.min(0.1, (now - this.lastDraw) / 1000);
    this.lastDraw = now;
    // The controls ease towards the eye's, so a new reel makes it lurch, not jump.
    const target = info.distortion ?? CLEAN;
    for (const key of Object.keys(CLEAN)) this.controls[key] += ((target[key] ?? CLEAN[key]) - this.controls[key]) * Math.min(1, seconds * 1.5);
    const picture = this.stage.feeds.get(REEL_FACE_VIEW);
    if (this.gl && picture && picture !== this.skin) this.uploadSkin(picture);
    const hasHead = Boolean(this.gl && this.mesh && this.skinReady && info.version);
    if (this.gl) this.drawHead(now, hasHead);

    const { ctx } = this;
    const { width: w, height: h } = this.overlay;
    ctx.clearRect(0, 0, w, h);
    if (!this.gl) {
      caption(ctx, w, h, 'NO WEBGL ON THIS COMPUTER', item, h / 2);
    } else if (info.state === 'capturing') {
      const camera = this.stage.feeds.get(MIRROR_VIEW);
      this.finder.look(camera, now);
      if (!hasHead) this.drawCamera(camera, w, h);
      this.drawPrompt(info, w, h);
    } else if (!hasHead && this.stage.editing) {
      caption(ctx, w, h, info.state === 'off' ? 'REEL FACE · WAITING FOR A VISIT' : 'REEL FACE · BUILDING', item, h / 2);
    }
  }

  // WebGL

  setUpGl() {
    const { gl } = this;
    this.head = program(gl, HEAD_VERTEX, HEAD_FRAGMENT, ['position', 'uv', 'normal', 'shard', 'facet']);
    this.damage = program(gl, QUAD_VERTEX, DAMAGE_FRAGMENT, ['corner']);
    this.show = program(gl, QUAD_VERTEX, SHOW_FRAGMENT, ['corner']);
    this.texture = gl.createTexture();
    this.vao = gl.createVertexArray();
    this.buffers = [0, 1, 2, 3, 4].map(() => gl.createBuffer());
    // One triangle over the whole canvas, for the picture passes.
    this.quad = gl.createVertexArray();
    gl.bindVertexArray(this.quad);
    gl.bindBuffer(gl.ARRAY_BUFFER, gl.createBuffer());
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
    gl.enableVertexAttribArray(0);
    gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
    gl.bindVertexArray(null);
    this.targets = null; // the head on its own, and two pictures that take turns (this frame, the last)
  }

  loadMesh(mesh) {
    const { gl } = this;
    if (!gl) return;
    const positions = new Float32Array(mesh.positions);
    const normals = flatNormals(positions);
    this.mesh = { version: mesh.version, count: positions.length / 3, positions, normals };
    gl.bindVertexArray(this.vao);
    [[positions, 3], [new Float32Array(mesh.uvs), 2], [normals, 3]].forEach(([data, size], index) => this.fill(index, data, size));
    // Each triangle's own way out: mostly outwards, partly anywhere.
    const facets = new Float32Array(positions.length);
    for (let t = 0; t < this.mesh.count / 3; t++) {
      const n = normals.subarray(t * 9, t * 9 + 3);
      const away = [n[0] + random(t * 3) - 0.5, n[1] + random(t * 3 + 1) - 0.5, n[2] + random(t * 3 + 2) - 0.5];
      const length = 0.4 + 0.6 * random(t * 7 + 0.3);
      for (let corner = 0; corner < 3; corner++) facets.set(away.map((v) => v * length), t * 9 + corner * 3);
    }
    this.fill(4, facets, 3);
    gl.bindVertexArray(null);
    this.loadPieces();
  }

  // Which piece of reel each triangle belongs to, and the way each piece comes away.
  loadPieces() {
    const { gl, mesh } = this;
    if (!gl || !mesh) return;
    const triangles = mesh.count / 3;
    const pieces = this.pieces?.length === triangles ? this.pieces : new Array(triangles).fill(-1);
    const outward = new Map();
    pieces.forEach((piece, t) => {
      if (piece < 0) return;
      const sum = outward.get(piece) ?? [0, 0, 0];
      for (let axis = 0; axis < 3; axis++) sum[axis] += mesh.normals[t * 9 + axis];
      outward.set(piece, sum);
    });
    const ways = new Map();
    for (const [piece, sum] of outward) {
      const way = sum.map((v, axis) => v / (Math.hypot(...sum) || 1) + 0.7 * (random(piece * 5 + axis) - 0.5));
      const length = Math.hypot(...way) || 1;
      ways.set(piece, way.map((v) => v / length));
    }
    const data = new Float32Array(triangles * 12);
    pieces.forEach((piece, t) => {
      const value = piece < 0 ? [0, 0, 0, -1] : [...ways.get(piece), piece + 1];
      for (let corner = 0; corner < 3; corner++) data.set(value, t * 12 + corner * 4);
    });
    gl.bindVertexArray(this.vao);
    this.fill(3, data, 4);
    gl.bindVertexArray(null);
  }

  fill(index, data, size) {
    const { gl } = this;
    gl.bindBuffer(gl.ARRAY_BUFFER, this.buffers[index]);
    gl.bufferData(gl.ARRAY_BUFFER, data, gl.STATIC_DRAW);
    gl.enableVertexAttribArray(index);
    gl.vertexAttribPointer(index, size, gl.FLOAT, false, 0, 0);
  }

  uploadSkin(picture) {
    const { gl } = this;
    this.skin = picture;
    gl.bindTexture(gl.TEXTURE_2D, this.texture);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false); // the skin's rows go top down, like its v
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, picture);
    gl.generateMipmap(gl.TEXTURE_2D);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    this.skinReady = true;
  }

  // Off-screen pictures the size of the canvas: the head alone (with depth), and two for the damage.
  makeTargets(width, height) {
    const { gl } = this;
    const picture = () => {
      const texture = gl.createTexture();
      gl.bindTexture(gl.TEXTURE_2D, texture);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, width, height, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
      for (const [key, value] of [[gl.TEXTURE_MIN_FILTER, gl.NEAREST], [gl.TEXTURE_MAG_FILTER, gl.NEAREST],
        [gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE], [gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE]]) gl.texParameteri(gl.TEXTURE_2D, key, value);
      const framebuffer = gl.createFramebuffer();
      gl.bindFramebuffer(gl.FRAMEBUFFER, framebuffer);
      gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, texture, 0);
      return { texture, framebuffer };
    };
    if (this.targets) {
      for (const target of [this.targets.scene, ...this.targets.turns]) {
        gl.deleteTexture(target.texture);
        gl.deleteFramebuffer(target.framebuffer);
      }
      gl.deleteRenderbuffer(this.targets.depth);
    }
    const scene = picture();
    const depth = gl.createRenderbuffer();
    gl.bindRenderbuffer(gl.RENDERBUFFER, depth);
    gl.renderbufferStorage(gl.RENDERBUFFER, gl.DEPTH_COMPONENT24, width, height);
    gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.RENDERBUFFER, depth);
    const turns = [picture(), picture()];
    for (const turn of turns) {
      gl.bindFramebuffer(gl.FRAMEBUFFER, turn.framebuffer);
      gl.clearColor(0, 0, 0, 0);
      gl.clear(gl.COLOR_BUFFER_BIT);
    }
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    this.targets = { width, height, scene, depth, turns, current: 0 };
  }

  drawHead(now, hasHead) {
    const { gl, item, controls } = this;
    const { width, height } = this.glCanvas;
    const background = rgb(item.background);
    if (!hasHead) {
      gl.bindFramebuffer(gl.FRAMEBUFFER, null);
      gl.viewport(0, 0, width, height);
      gl.clearColor(...background, 1);
      gl.clear(gl.COLOR_BUFFER_BIT);
      if (this.targets && !this.targets.blank) {
        // The next head starts without the last one's smear.
        for (const turn of this.targets.turns) {
          gl.bindFramebuffer(gl.FRAMEBUFFER, turn.framebuffer);
          gl.clearColor(0, 0, 0, 0);
          gl.clear(gl.COLOR_BUFFER_BIT);
        }
        gl.bindFramebuffer(gl.FRAMEBUFFER, null);
        this.targets.blank = true;
      }
      return;
    }
    if (!this.targets || this.targets.width !== width || this.targets.height !== height) this.makeTargets(width, height);
    this.targets.blank = false;
    const t = now / 1000;
    const fracture = controls.fracture_amount;

    // 1. The head on its own, broken apart.
    gl.bindFramebuffer(gl.FRAMEBUFFER, this.targets.scene.framebuffer);
    gl.viewport(0, 0, width, height);
    gl.clearColor(0, 0, 0, 0);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    // A slow sway across the front, left and right, with a little nod and tilt.
    const yaw = ((item.turn ?? 35) * Math.PI / 180) * Math.sin((t * 2 * Math.PI) / 16);
    const pitch = 0.06 * Math.sin((t * 2 * Math.PI) / 11);
    const roll = 0.035 * Math.sin((t * 2 * Math.PI) / 13);
    // Turn about the middle of the skull, then frame the head and neck.
    const model = multiply(translation(0, 0.14, -4.7),
      multiply(rotationY(yaw), multiply(rotationX(pitch), multiply(rotationZ(roll), translation(0, 0.1, 0.3)))));
    const { uniforms } = this.head;
    gl.useProgram(this.head.program);
    gl.uniformMatrix4fv(uniforms.projection, false, perspective(28, width / height, 0.1, 20));
    gl.uniformMatrix4fv(uniforms.model, false, model);
    gl.uniform1f(uniforms.time, t);
    gl.uniform1f(uniforms.fracture, fracture);
    gl.uniform1f(uniforms.shardSize, controls.shard_size);
    gl.uniform1f(uniforms.shade, Math.min(1, (item.shade ?? 60) / 100 + fracture * 0.3)); // more faceted as it breaks
    gl.uniform1f(uniforms.colourShift, controls.colour_shift);
    gl.uniform1f(uniforms.missing, fracture * 0.12);
    const doubled = fracture * 0.15 + controls.smear * 0.1;
    gl.uniform1f(uniforms.doubled, doubled);
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, this.texture);
    gl.uniform1i(uniforms.skin, 0);
    gl.bindVertexArray(this.vao);
    gl.enable(gl.DEPTH_TEST);
    gl.enable(gl.CULL_FACE);
    gl.uniform1f(uniforms.ghost, 0);
    gl.drawArrays(gl.TRIANGLES, 0, this.mesh.count);
    if (doubled > 0.01) {
      // Some pieces again, knocked sideways and see-through: doubled features.
      gl.enable(gl.BLEND);
      gl.blendFuncSeparate(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA, gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
      gl.depthMask(false);
      gl.uniform1f(uniforms.ghost, 1);
      gl.drawArrays(gl.TRIANGLES, 0, this.mesh.count);
      gl.depthMask(true);
      gl.disable(gl.BLEND);
    }
    gl.disable(gl.DEPTH_TEST);
    gl.disable(gl.CULL_FACE);

    // 2. The picture's damage, into this frame's picture, from the head and the last frame's.
    const targets = this.targets;
    const last = targets.turns[targets.current];
    const next = targets.turns[1 - targets.current];
    gl.bindFramebuffer(gl.FRAMEBUFFER, next.framebuffer);
    gl.useProgram(this.damage.program);
    const damage = this.damage.uniforms;
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, targets.scene.texture);
    gl.uniform1i(damage.scene, 0);
    gl.activeTexture(gl.TEXTURE1);
    gl.bindTexture(gl.TEXTURE_2D, last.texture);
    gl.uniform1i(damage.previous, 1);
    gl.uniform2f(damage.size, width, height);
    gl.uniform1f(damage.time, t);
    gl.uniform1f(damage.stretch, controls.pixel_stretch);
    gl.uniform1f(damage.blocky, controls.jpeg_blockiness);
    gl.uniform1f(damage.smear, controls.smear);
    gl.uniform1f(damage.shift, controls.colour_shift);
    gl.bindVertexArray(this.quad);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
    targets.current = 1 - targets.current;

    // 3. Onto the screen, over the plain background.
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    gl.useProgram(this.show.program);
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, next.texture);
    gl.uniform1i(this.show.uniforms.picture, 0);
    gl.uniform3f(this.show.uniforms.background, ...background);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
    gl.bindVertexArray(null);
  }

  // The capture overlay

  // The face camera, mirrored and grey, with the points MediaPipe finds on the face.
  drawCamera(camera, w, h) {
    const { ctx } = this;
    if (!camera) return;
    const scale = Math.min(w / camera.width, (h * 0.8) / camera.height);
    const dw = camera.width * scale;
    const dh = camera.height * scale;
    const dx = (w - dw) / 2;
    const dy = (h * 0.8 - dh) / 2;
    ctx.save();
    ctx.translate(dx + dw, dy);
    ctx.scale(-1, 1);
    ctx.filter = 'grayscale(1) contrast(1.15)';
    ctx.drawImage(camera, 0, 0, dw, dh);
    ctx.filter = 'none';
    const face = this.finder.found;
    if (face) {
      ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
      for (const point of face) ctx.fillRect(point.x * dw - 1, point.y * dh - 1, 2, 2);
    }
    ctx.restore();
  }

  drawPrompt(info, w, h) {
    const { ctx, item } = this;
    const text = this.finder.ready ? info.prompt : 'STARTING THE FACE CAMERA…';
    caption(ctx, w, h, text, item, h * 0.88);
    // FRONT · LEFT · RIGHT, ticked off as they're taken.
    const size = item.size * 0.4;
    ctx.font = `${size}px Consolas, monospace`;
    ctx.textAlign = 'center';
    VIEWS.forEach((view, index) => {
      const taken = info.views?.includes(view);
      ctx.fillStyle = view === info.wanted ? item.color : taken ? 'rgba(20, 20, 20, 0.85)' : 'rgba(20, 20, 20, 0.35)';
      ctx.fillText(`${taken ? '■' : '□'} ${view.toUpperCase()}`, w / 2 + (index - 1) * size * 7, h * 0.96);
    });
  }
}

function program(gl, vertexSource, fragmentSource, attributes) {
  const made = gl.createProgram();
  for (const [type, source] of [[gl.VERTEX_SHADER, vertexSource], [gl.FRAGMENT_SHADER, fragmentSource]]) {
    const shader = gl.createShader(type);
    gl.shaderSource(shader, source);
    gl.compileShader(shader);
    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) console.error(gl.getShaderInfoLog(shader));
    gl.attachShader(made, shader);
  }
  attributes.forEach((name, index) => gl.bindAttribLocation(made, index, name));
  gl.linkProgram(made);
  if (!gl.getProgramParameter(made, gl.LINK_STATUS)) console.error(gl.getProgramInfoLog(made));
  const uniforms = {};
  for (let i = 0; i < gl.getProgramParameter(made, gl.ACTIVE_UNIFORMS); i++) {
    const { name } = gl.getActiveUniform(made, i);
    uniforms[name] = gl.getUniformLocation(made, name);
  }
  return { program: made, uniforms };
}

function layerCanvas() {
  const canvas = document.createElement('canvas');
  Object.assign(canvas.style, { position: 'absolute', inset: '0', width: '100%', height: '100%' });
  return canvas;
}

function caption(ctx, w, h, text, item, y) {
  if (!text) return;
  ctx.font = `${item.size}px "${item.font}", sans-serif`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = item.color;
  ctx.fillText(text, w / 2, y, w * 0.9);
}

// The same "random" number for the same n, every time and on every screen.
function random(n) {
  const x = Math.sin(n * 12.9898 + 78.233) * 43758.5453;
  return x - Math.floor(x);
}

// One normal per triangle, given to all three corners: a faceted head.
function flatNormals(positions) {
  const normals = new Float32Array(positions.length);
  for (let i = 0; i < positions.length; i += 9) {
    const ax = positions[i + 3] - positions[i], ay = positions[i + 4] - positions[i + 1], az = positions[i + 5] - positions[i + 2];
    const bx = positions[i + 6] - positions[i], by = positions[i + 7] - positions[i + 1], bz = positions[i + 8] - positions[i + 2];
    let nx = ay * bz - az * by, ny = az * bx - ax * bz, nz = ax * by - ay * bx;
    const length = Math.hypot(nx, ny, nz) || 1;
    nx /= length; ny /= length; nz /= length;
    for (let corner = 0; corner < 9; corner += 3) normals.set([nx, ny, nz], i + corner);
  }
  return normals;
}

function rgb(hex) {
  const value = parseInt((hex || '#000000').slice(1), 16);
  return [(value >> 16) / 255, ((value >> 8) & 255) / 255, (value & 255) / 255];
}

// 4×4 matrices, column by column, as WebGL wants them.

function perspective(fovDegrees, aspect, near, far) {
  const f = 1 / Math.tan((fovDegrees * Math.PI) / 360);
  return new Float32Array([f / aspect, 0, 0, 0, 0, f, 0, 0, 0, 0, (far + near) / (near - far), -1, 0, 0, (2 * far * near) / (near - far), 0]);
}

function translation(x, y, z) {
  return new Float32Array([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, x, y, z, 1]);
}

function rotationX(a) {
  const c = Math.cos(a), s = Math.sin(a);
  return new Float32Array([1, 0, 0, 0, 0, c, s, 0, 0, -s, c, 0, 0, 0, 0, 1]);
}

function rotationY(a) {
  const c = Math.cos(a), s = Math.sin(a);
  return new Float32Array([c, 0, -s, 0, 0, 1, 0, 0, s, 0, c, 0, 0, 0, 0, 1]);
}

function rotationZ(a) {
  const c = Math.cos(a), s = Math.sin(a);
  return new Float32Array([c, s, 0, 0, -s, c, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]);
}

function multiply(a, b) {
  const out = new Float32Array(16);
  for (let column = 0; column < 4; column++) {
    for (let row = 0; row < 4; row++) {
      let sum = 0;
      for (let k = 0; k < 4; k++) sum += a[k * 4 + row] * b[column * 4 + k];
      out[column * 4 + row] = sum;
    }
  }
  return out;
}
