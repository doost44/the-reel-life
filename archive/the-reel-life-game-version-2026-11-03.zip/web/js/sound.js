// Sounds, synthesised in the browser so there are no files to load.
//
// The visitor's side: casino blips, played quieter as YOUR PLEASURE drains.
// The machine's side: an ambient body (a heartbeat, breathing, a purr) that
// rises in pitch and tempo with its arousal, a held tone at the climax and a
// shutdown thud. Abstract on purpose: no recorded human sounds.

// Each casino sound is a list of notes: [frequency in Hz, seconds, waveform].
const SOUNDS = {
  start: [[523, 0.1], [659, 0.1], [784, 0.22]],
  perfect: [[1319, 0.06], [1976, 0.16]],
  multiplier_up: [[659, 0.07], [784, 0.07], [988, 0.07], [1319, 0.25]],
  bonus: [[1568, 0.08], [2093, 0.08], [1568, 0.08], [2093, 0.3]],
  jackpot_almost: [[1568, 0.08], [2093, 0.08], [1976, 0.12], [1760, 0.4]],
  near_miss: [[523, 0.1], [494, 0.22]],
  too_fast: [[233, 0.18, 'sawtooth']],
  too_slow: [[196, 0.3, 'sawtooth']],
  slow_warning: [[440, 0.1, 'square'], [0, 0.08], [440, 0.1, 'square']],
  penalty: [[330, 0.12, 'square'], [247, 0.12, 'square'], [165, 0.35, 'square']],
  challenge: [[880, 0.15], [0, 0.1], [880, 0.15]],
  challenge_passed: [[523, 0.12], [784, 0.3]],
  challenge_failed: [[311, 0.3, 'sawtooth']],
};

let audio = null;
let body = null;

// Browsers start sound paused until someone clicks or presses a key on the
// page; the fullscreen screens are opened with autoplay allowed.
export function unlockSound() {
  audio ??= new AudioContext();
  if (audio.state === 'suspended') audio.resume();
}

// A casino sound, at a volume (0-1): the visitor's sounds thin out as their pleasure drains.
export function playSound(kind, volume = 1) {
  const notes = SOUNDS[kind];
  if (!notes) return;
  unlockSound();
  let at = audio.currentTime + 0.01;
  for (const [frequency, seconds, wave = 'triangle'] of notes) {
    if (frequency) tone(frequency, at, seconds, 0.2 * Math.max(0.15, volume), wave);
    at += seconds;
  }
}

function tone(frequency, at, seconds, level, wave = 'sine') {
  const oscillator = audio.createOscillator();
  const gain = audio.createGain();
  oscillator.type = wave;
  oscillator.frequency.value = frequency;
  gain.gain.setValueAtTime(0.0001, at);
  gain.gain.exponentialRampToValueAtTime(level, at + 0.01);
  gain.gain.exponentialRampToValueAtTime(0.0001, at + seconds);
  oscillator.connect(gain).connect(audio.destination);
  oscillator.start(at);
  oscillator.stop(at + seconds + 0.02);
}

// The machine's body, following each game snapshot.
export function updateBody(game) {
  if (!audio || audio.state !== 'running') return;
  body ??= makeBody();
  const playing = ['excitement', 'plateau', 'climax'].includes(game.state) || game.state === 'resolution';
  body.arousal = playing ? game.arousal : 0;
  body.bpm = game.bpm;
  body.breaths = game.breaths;
  const now = audio.currentTime;
  const a = body.arousal;
  // Breathing: filtered noise, brighter and faster as it warms up.
  body.breathFilter.frequency.setTargetAtTime(300 + 900 * a, now, 0.3);
  // A purr underneath, only once it's properly going.
  body.purr.gain.setTargetAtTime(0.06 * a * a, now, 0.5);
  body.purrTone.frequency.setTargetAtTime(45 + 25 * a, now, 0.5);
  if (game.state === 'climax' && !body.climaxing) climaxTone(game);
  body.climaxing = game.state === 'climax';
}

function makeBody() {
  const noise = audio.createBuffer(1, audio.sampleRate * 2, audio.sampleRate);
  const samples = noise.getChannelData(0);
  for (let i = 0; i < samples.length; i++) samples[i] = Math.random() * 2 - 1;
  const source = audio.createBufferSource();
  source.buffer = noise;
  source.loop = true;
  const breathFilter = audio.createBiquadFilter();
  breathFilter.type = 'bandpass';
  breathFilter.Q.value = 0.8;
  const breath = audio.createGain();
  breath.gain.value = 0;
  source.connect(breathFilter).connect(breath).connect(audio.destination);
  source.start();

  const purrTone = audio.createOscillator();
  purrTone.type = 'triangle';
  const purr = audio.createGain();
  purr.gain.value = 0;
  const flutter = audio.createOscillator(); // the purr's rumble
  flutter.frequency.value = 23;
  const flutterDepth = audio.createGain();
  flutterDepth.gain.value = 0.5;
  flutter.connect(flutterDepth).connect(purr.gain);
  purrTone.connect(purr).connect(audio.destination);
  purrTone.start();
  flutter.start();

  const state = { arousal: 0, bpm: 58, breaths: 8, breathFilter, purr, purrTone, climaxing: false, nextBeat: 0, breathPhase: 0 };
  // Heartbeats and breaths are scheduled a little ahead, often.
  setInterval(() => {
    const now = audio.currentTime;
    const level = state.arousal;
    if (level > 0.01) {
      if (state.nextBeat < now) state.nextBeat = now + 0.05;
      while (state.nextBeat < now + 0.2) {
        // Lub-dub: two low thumps.
        tone(55 + 20 * level, state.nextBeat, 0.12, 0.25 * (0.3 + level));
        tone(48 + 16 * level, state.nextBeat + 0.16, 0.1, 0.18 * (0.3 + level));
        state.nextBeat += 60 / state.bpm;
      }
    }
    state.breathPhase += 0.05 * (state.breaths / 60);
    const swell = Math.max(0, Math.sin(state.breathPhase * Math.PI * 2));
    breath.gain.setTargetAtTime(0.09 * level * swell * swell, now, 0.08);
  }, 50);
  return state;
}

// A held tone that swells with the white-out and stops dead at the collapse.
function climaxTone(game) {
  const seconds = game.climax_seconds || 14;
  const start = audio.currentTime;
  const rise = seconds * 0.35;
  const cut = seconds * 0.55;
  for (const frequency of [220, 277.2, 329.6, 440]) {
    const oscillator = audio.createOscillator();
    const gain = audio.createGain();
    oscillator.frequency.value = frequency;
    gain.gain.setValueAtTime(0.0001, start);
    gain.gain.exponentialRampToValueAtTime(0.06, start + rise);
    gain.gain.setValueAtTime(0.06, start + cut);
    gain.gain.exponentialRampToValueAtTime(0.0001, start + cut + 0.08);
    oscillator.connect(gain).connect(audio.destination);
    oscillator.start(start);
    oscillator.stop(start + cut + 0.1);
  }
  // The fake shutdown: a falling thud as the picture collapses.
  const thud = audio.createOscillator();
  const thudGain = audio.createGain();
  thud.frequency.setValueAtTime(120, start + cut);
  thud.frequency.exponentialRampToValueAtTime(30, start + cut + 0.6);
  thudGain.gain.setValueAtTime(0.0001, start + cut);
  thudGain.gain.exponentialRampToValueAtTime(0.4, start + cut + 0.02);
  thudGain.gain.exponentialRampToValueAtTime(0.0001, start + cut + 0.7);
  thud.connect(thudGain).connect(audio.destination);
  thud.start(start + cut);
  thud.stop(start + cut + 0.75);
}
