// IT's face: the artist's own face in pieces, on six little screens mounted on
// circuit boards and wired to a head rig. Each screen shows one feature cut
// from a mood clip recorded in the Face studio, and the face crossfades from
// mood to mood as the machine warms up. Never a visitor's face.

import { COLD, HOT, mix } from './body.js';

export const MOODS = ['bored', 'curious', 'warm', 'flushed', 'peak', 'indifferent'];

// Each screen: where its feature sits in a clip (the Face studio's guide), and
// where the screen sits on the face, both as shares of the whole.
const SCREENS = [
  { name: 'forehead', from: [0.3, 0.08, 0.4, 0.22], to: [0.3, 0.02, 0.4, 0.22] },
  { name: 'left eye', from: [0.08, 0.32, 0.4, 0.18], to: [0.01, 0.28, 0.38, 0.18] },
  { name: 'right eye', from: [0.52, 0.32, 0.4, 0.18], to: [0.61, 0.28, 0.38, 0.18] },
  { name: 'mouth', from: [0.24, 0.66, 0.52, 0.2], to: [0.24, 0.62, 0.52, 0.22] },
  { name: 'chin', from: [0.38, 0.86, 0.24, 0.12], to: [0.4, 0.88, 0.2, 0.1] },
  { name: 'nose', from: [0.36, 0.42, 0.28, 0.24], to: [0.38, 0.3, 0.24, 0.3] }, // last: it sits over the others
];

// One <video> per mood, shared by every Face source on the page.
const clips = new Map();

function clip(mood, stamp) {
  const known = clips.get(mood);
  if (known && known.stamp === stamp) return known.video;
  const video = known?.video ?? Object.assign(document.createElement('video'), { muted: true, loop: true, playsInline: true });
  video.src = `/faces/${mood}.mp4?v=${stamp}`;
  video.play().catch(() => {});
  clips.set(mood, { video, stamp });
  return video;
}

// Which mood the face is in: the phases, and how far the plateau has got.
function moodFor(state, arousal) {
  if (state === 'idle') return 'bored';
  if (state === 'excitement') return 'curious';
  if (state === 'climax') return 'peak';
  if (state === 'resolution') return 'indifferent';
  return arousal < 0.45 ? 'warm' : arousal < 0.85 ? 'flushed' : 'peak';
}

// The nearest mood that has been recorded, so a half-finished set still works.
function recordedMood(wanted, recorded) {
  if (recorded[wanted]) return wanted;
  const at = MOODS.indexOf(wanted);
  return [...MOODS].sort((a, b) => Math.abs(MOODS.indexOf(a) - at) - Math.abs(MOODS.indexOf(b) - at)).find((mood) => recorded[mood]) ?? null;
}

export class FaceView {
  constructor(stage) {
    this.stage = stage;
    this.el = document.createElement('canvas');
    this.ctx = this.el.getContext('2d');
    this.mood = null;
    this.previous = null;
    this.changedAt = 0;
  }

  update(item) {
    const w = Math.max(2, Math.round(item.w));
    const h = Math.max(2, Math.round(item.h));
    if (this.el.width !== w || this.el.height !== h) Object.assign(this.el, { width: w, height: h });
  }

  draw(now) {
    const { ctx, item } = this;
    if (!item) return;
    const { width: w, height: h } = this.el;
    const game = this.stage.liveGame();
    const arousal = game?.arousal ?? 0;
    const recorded = this.stage.faces ?? {};
    const mood = recordedMood(moodFor(this.stage.state, arousal), recorded);
    if (mood !== this.mood) {
      this.previous = this.mood;
      this.mood = mood;
      this.changedAt = now;
    }
    const fade = Math.min(1, (now - this.changedAt) / 1000); // a second's crossfade between moods
    const breath = Math.sin((now / 1000) * Math.PI * 2 * ((game?.breaths ?? 8) / 60));
    const heat = mix(item.low, item.high, arousal);

    ctx.clearRect(0, 0, w, h);
    if (item.rig) drawRig(ctx, w, h, item.wires);
    for (const screen of SCREENS) {
      // The rig breathes: every screen rises and falls a little, more as it warms up.
      const bob = breath * h * 0.004 * (0.3 + arousal);
      const [x, y, sw, sh] = [screen.to[0] * w, screen.to[1] * h + bob, screen.to[2] * w, screen.to[3] * h];
      drawBoard(ctx, x, y, sw, sh, item.board);
      const inset = Math.min(sw, sh) * 0.09;
      const area = [x + inset, y + inset, sw - inset * 2, sh - inset * 2];
      ctx.save();
      ctx.beginPath();
      ctx.rect(...area);
      ctx.clip();
      ctx.fillStyle = '#05070c';
      ctx.fillRect(...area);
      if (this.mood) {
        if (this.previous && recorded[this.previous] && fade < 1) {
          drawFeature(ctx, clip(this.previous, recorded[this.previous]), screen.from, area, 1);
        }
        drawFeature(ctx, clip(this.mood, recorded[this.mood]), screen.from, area, fade);
      } else {
        drawStatic(ctx, area, now, screen.name === 'mouth' ? 'RECORD YOUR FACE' : '');
      }
      if (item.tint) {
        // Its heat shows through the screens.
        ctx.globalCompositeOperation = 'soft-light';
        ctx.globalAlpha = 0.25 + 0.5 * arousal;
        ctx.fillStyle = heat;
        ctx.fillRect(...area);
        ctx.globalCompositeOperation = 'source-over';
        ctx.globalAlpha = 1;
      }
      ctx.fillStyle = 'rgba(0, 0, 0, 0.18)'; // the screens' own scanlines
      for (let line = area[1]; line < area[1] + area[3]; line += 3) ctx.fillRect(area[0], line, area[2], 1);
      ctx.restore();
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.25)';
      ctx.strokeRect(...area);
    }
  }
}

function drawFeature(ctx, video, from, area, alpha) {
  if (video.readyState < 2 || !video.videoWidth) return;
  const [fx, fy, fw, fh] = from;
  const sw = video.videoWidth * fw;
  const sh = video.videoHeight * fh;
  // Fill the screen with the feature, cropping whichever way it doesn't fit.
  const scale = Math.max(area[2] / sw, area[3] / sh);
  const cw = area[2] / scale;
  const chh = area[3] / scale;
  const sx = video.videoWidth * fx + (sw - cw) / 2;
  const sy = video.videoHeight * fy + (sh - chh) / 2;
  ctx.globalAlpha = alpha;
  ctx.drawImage(video, sx, sy, cw, chh, ...area);
  ctx.globalAlpha = 1;
}

function drawStatic(ctx, [x, y, w, h], now, label) {
  const seed = Math.floor(now / 80);
  for (let i = 0; i < 120; i++) {
    const shade = (seed * 7919 + i * 104729) % 90;
    ctx.fillStyle = `rgb(${shade}, ${shade}, ${shade + 20})`;
    ctx.fillRect(x + ((i * 37 + seed * 13) % w), y + ((i * 53 + seed * 29) % h), 6, 2);
  }
  if (label) {
    ctx.fillStyle = '#ffd6ef';
    ctx.font = `${Math.max(10, Math.floor(h / 6))}px Consolas, monospace`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(label, x + w / 2, y + h / 2);
  }
}

// A little screen's circuit board: the board, its mounting holes and a row of pins.
function drawBoard(ctx, x, y, w, h, color) {
  const radius = Math.min(w, h) * 0.04;
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.roundRect(x, y, w, h, radius);
  ctx.fill();
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.35)';
  ctx.lineWidth = 1.5;
  ctx.stroke();
  const hole = Math.max(2, Math.min(w, h) * 0.03);
  ctx.fillStyle = '#c9c9c9';
  for (const [hx, hy] of [[x + hole * 2, y + hole * 2], [x + w - hole * 2, y + hole * 2], [x + hole * 2, y + h - hole * 2], [x + w - hole * 2, y + h - hole * 2]]) {
    ctx.beginPath();
    ctx.arc(hx, hy, hole, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.fillStyle = '#d8b84a';
  const pins = 8;
  for (let pin = 0; pin < pins; pin++) {
    ctx.fillRect(x + w * 0.2 + (pin * w * 0.6) / pins, y + h - Math.max(2, h * 0.04), Math.max(2, w * 0.03), Math.max(2, h * 0.025));
  }
}

// The head rig: a thin metal arc over the top, and bright ribbon wires.
function drawRig(ctx, w, h, wires) {
  ctx.strokeStyle = 'rgba(200, 205, 215, 0.7)';
  ctx.lineWidth = Math.max(2, w * 0.006);
  ctx.beginPath();
  ctx.ellipse(w / 2, h * 0.42, w * 0.47, h * 0.46, 0, Math.PI * 1.05, Math.PI * 1.95);
  ctx.stroke();
  if (!wires) return;
  const colours = ['#ff4d4d', '#ffb02e', '#ffe14d', '#3ddc84', '#2da8ff', '#b06bff'];
  colours.forEach((colour, index) => {
    ctx.strokeStyle = colour;
    ctx.lineWidth = Math.max(1.5, w * 0.004);
    ctx.beginPath();
    const offset = (index - 2.5) * w * 0.008;
    ctx.moveTo(w * 0.42 + offset, h * 0.24);
    ctx.bezierCurveTo(w * 0.3 + offset, h * 0.26, w * 0.22 + offset, h * 0.26, w * 0.2 + offset, h * 0.29);
    ctx.moveTo(w * 0.58 + offset, h * 0.24);
    ctx.bezierCurveTo(w * 0.7 + offset, h * 0.26, w * 0.78 + offset, h * 0.26, w * 0.8 + offset, h * 0.29);
    ctx.stroke();
  });
}

export const FACE_DEFAULTS = { board: '#14324a', rig: true, wires: true, tint: true, low: COLD, high: HOT };
