"""The reel face: the visitor's own head, rebuilt out of the reels they watch.

Capture: when a visit starts, the Reel face screen asks the visitor to look
up at the face camera, then to turn left and right. The page runs MediaPipe
on the face camera's picture and sends every face it finds (its landmarks
and the photo); the eye keeps the ones that match the view it's asking for
and builds the base head from them (face_capture.py). The head appears after
the front photo and improves as the profiles come in.

The copy: every reel watched past the threshold (reel_sampler.py) becomes
shards of the copy's skin (atlas.py). The base head is never changed; the
copy starts as it and is rebuilt from it if the photos change. A snapshot
after every reel can be scrubbed back to.

Everything is held in memory for one visit and wiped when it ends. Nothing
is saved.

States: off (no visit, or no face camera), capturing (asking for a view),
ready (the head is built).
"""

from __future__ import annotations

import base64
import threading

import cv2
import numpy as np

from . import distortion, face_capture
from .atlas import ReelCopy
from .face_capture import CHIN, TOP, VIEWS
from .reel_sampler import ReelRecord, test_reel

REEL_FACE_VIEW = "@reelface"  # the copy's skin, sent to pages like a camera picture
_LABEL = REEL_FACE_VIEW.encode()


class ReelFace:
    def __init__(self, settings: dict) -> None:
        self.settings = settings
        self._layout: face_capture.Layout | None = None
        self._lock = threading.Lock()  # the head and the copy are built in a worker thread
        self._visit = 0
        self._built = 0
        self._skin_version = 0
        self._random = np.random.default_rng()
        self.override: float | None = None  # the operator's intensity, for testing; None follows the session
        self._wipe()

    def _wipe(self) -> None:
        self.state = "off"
        self.views: dict[str, face_capture.View] = {}
        self.head: face_capture.Head | None = None
        self.copy: ReelCopy | None = None
        self.reels: list[ReelRecord] = []  # the reels watched this visit, oldest first
        self.forced: str | None = None
        self.last_face: dict | None = None  # how the last face found was posed, for tuning
        self.asked_since = 0.0
        self.scrub_to: int | None = None  # a snapshot shown instead of the live copy
        self._skin_frame: bytes | None = None
        self._taken = 0        # photos kept this visit (a retake counts again)
        self._built_from = 0   # ...and how many the current head was built from
        self._resets = 0
        self._copy_reset = False
        self._skin_stale = False
        self._stats = {"fragments": 0, "history": 0, "painted": 0}
        self._shown = (0, 0.0, None)  # the copy on show (live or scrubbed to): its reels, seconds and shards

    # What happens

    def begin(self, t: float) -> None:
        """A visit started: ask for their face."""
        self._visit += 1
        self._wipe()
        self.state = "capturing"
        self.asked_since = t

    def end(self) -> None:
        """The visit is over: forget the face and the reels."""
        self._visit += 1
        self._wipe()

    def recapture(self, t: float) -> None:
        """New photos; the reels watched so far stay, and go onto the new head."""
        if self.state == "off":
            return
        self.views, self.forced = {}, None
        self.state, self.asked_since = "capturing", t

    def force(self, view: str, t: float) -> None:
        """The operator: take the next face found as this view, whatever its angle."""
        if view in VIEWS and self.state != "off":
            self.forced = view
            self.state = "capturing"
            self.asked_since = t

    def add_reel(self, reel: ReelRecord) -> bool:
        """A reel was watched. Kept (and painted on once there's a head) while a visit is on."""
        if self.state == "off":
            return False
        self.reels.append(reel)
        return True

    def add_test_reels(self, count: int, t: float) -> bool:
        """Made-up reels, for trying it without a phone (tests/reels, or invented)."""
        if self.state == "off":
            return False
        for _ in range(max(0, min(count, 50))):
            self.reels.append(test_reel(len(self.reels) + 1, t, self._random))
        return True

    def reset_copy(self) -> None:
        """Back to the clean base head: the reels so far are dropped."""
        if self.state != "off":
            self.reels = []
            self.scrub_to = None
            self._copy_reset = True

    def set_intensity(self, value: float | None) -> None:
        """The operator's override of how broken it looks (0-1), or None to follow the session."""
        self.override = None if value is None else min(1.0, max(0.0, float(value)))

    def scrub(self, index: int | None) -> None:
        """Show an earlier state of the copy (None: the live one)."""
        self.scrub_to = None if index is None else max(0, int(index))
        self._skin_stale = True

    @property
    def wanted(self) -> str | None:
        if self.forced:
            return self.forced
        return next((view for view in VIEWS if view not in self.views), None)

    def offer(self, message: dict, t: float) -> bool:
        """A page found a face. Keeps it if it's a view still wanted; then the
        head needs building again."""
        if self.state != "capturing":
            return False
        try:
            landmarks = np.array(message["landmarks"], dtype=np.float64)
            image = cv2.imdecode(np.frombuffer(base64.b64decode(message["image"]), np.uint8), cv2.IMREAD_COLOR)
        except (KeyError, TypeError, ValueError):
            return False
        if image is None or landmarks.shape != (478, 3):
            return False
        view = self._which_view(landmarks)
        if view is None:
            return False
        height, width = image.shape[:2]
        self.views[view] = face_capture.View(view, landmarks * [width, height, width], image)
        self._taken += 1
        self.forced = None
        self.asked_since = t
        if self.wanted is None:
            self.state = "ready"
        return True

    def _which_view(self, landmarks: np.ndarray) -> str | None:
        s = self.settings
        turn, tilt = face_capture.pose(landmarks)
        height = landmarks[CHIN, 1] - landmarks[TOP, 1]
        self.last_face = {"turn": round(turn, 2), "tilt": round(tilt, 2), "height": round(float(height), 2)}
        if self.forced:
            return self.forced
        if height < s["min_face_height"]:
            return None  # too far away
        if "front" not in self.views:
            low, high = s["front_tilt"]
            return "front" if abs(turn - 0.5) <= s["front_turn"] and low <= tilt <= high else None
        if turn >= 0.5 + s["profile_turn"] and "left" not in self.views:
            return "left"
        if turn <= 0.5 - s["profile_turn"] and "right" not in self.views:
            return "right"
        return None

    def tick(self, t: float) -> bool:
        """Stops asking for profiles that don't come. Returns whether the state changed."""
        waited = t - self.asked_since >= self.settings["profile_seconds"]
        if self.state == "capturing" and "front" in self.views and not self.forced and waited:
            self.state = "ready"
            return True
        return False

    def refresh(self) -> tuple[bool, bool]:
        """Brings the head and the copy up to date, in a worker thread: builds
        the head from new photos (and the copy afresh on it), paints reels not
        painted yet, and makes the picture pages get. Returns whether there's
        a new head, and whether the picture changed."""
        with self._lock:
            visit, views, taken, reels = self._visit, dict(self.views), self._taken, list(self.reels)
            reset, self._copy_reset = self._copy_reset, False
            stale, self._skin_stale = self._skin_stale, False
            if self._layout is None:
                self._layout = face_capture.load_layout()
            head = self.head
            new_head = None
            if "front" in views and taken != self._built_from:
                self._built += 1
                new_head = head = face_capture.build_head(views, self._layout, self.settings["skin_size"], self._built)
            copy = self.copy
            if head is not None and (new_head is not None or reset or copy is None):
                self._resets += 1
                copy = ReelCopy(head, self._layout, self.settings, seed=self._visit * 1000 + self._resets)
            changed = copy is not self.copy or stale
            if copy is not None:
                for reel in reels[copy.reels:]:
                    copy.add(reel)
                    changed = True
            if visit != self._visit:
                return False, False  # the visit ended while it was building
            if new_head is not None:
                self.head, self._built_from = new_head, taken
            self.copy = copy
            if copy is not None and changed:
                index = self.scrub_to if self.scrub_to is not None and self.scrub_to < len(copy.history) else -1
                shown = copy.history[index]
                self._skin_frame = bytes([len(_LABEL)]) + _LABEL + shown.jpeg
                self._skin_version += 1
                self._stats = {"fragments": shown.fragments, "history": len(copy.history), "painted": copy.reels}
                self._shown = (shown.reels, shown.watched, shown.shards)
            return new_head is not None, changed

    # What pages see

    def message(self, mesh: bool = False, pieces: bool = False) -> dict:
        """Its state for pages; with the head's mesh, and with which piece each
        triangle belongs to now (both only when they change: they're large)."""
        wanted = self.wanted if self.state == "capturing" else None
        reels, watched, shards = self._shown
        at = self.override if self.override is not None else distortion.progress(reels, watched, self.settings)
        message = {
            "type": "reel_face",
            "state": self.state,
            "wanted": wanted,
            "prompt": self.settings["text"].get(wanted, "") if wanted else "",
            "views": [view for view in VIEWS if view in self.views],
            "version": self.head.version if self.head else 0,
            "last_face": self.last_face,
            "reels": len(self.reels),
            "watched": round(sum(reel.watched for reel in self.reels), 1),
            "scrub": self.scrub_to,
            **self._stats,
            "progress": round(at, 3),
            "override": self.override,
            "distortion": distortion.controls(at, self.settings),
        }
        if pieces and shards is not None:
            message["shards"] = shards.tolist()
        if mesh and self.head:
            head = self.head
            message["mesh"] = {
                "version": head.version,
                "positions": np.round(head.positions, 4).ravel().tolist(),
                "uvs": np.round(head.uvs, 4).ravel().tolist(),
                "parts": head.parts.tolist(),
            }
        return message

    def skin(self) -> tuple[int, bytes | None]:
        """The copy's skin, ready to send as a picture: its version and bytes."""
        return self._skin_version, self._skin_frame
