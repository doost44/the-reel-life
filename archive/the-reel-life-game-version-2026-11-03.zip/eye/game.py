"""The game: a machine that enjoys the visitor's scrolling in their place.

The visitor wants; the machine likes. Every swipe is a hit of "dopamine"
for the machine (a metaphor, never a measurement). Its arousal rises while
the visitor's pleasure drains, and the gap widens the longer they stay. A
session runs through Masters and Johnson's four phases, from the moment a
phone is put down:

    idle -> excitement -> plateau -> climax -> resolution -> idle

Leaving before the climax goes straight to resolution, with the machine left
wanting. Swipes are still judged by how long the visitor stayed on the reel:
too fast, the sweet spot (the machine's taste, from my own scrolling), or
too slow, the one moment the visitor might actually enjoy something, which
the machine punishes.

The game runs once, in the eye, so every screen shows the same game. Pages
get a snapshot several times a second, plus events: game_event (a callout or
sound on the visitor's side), say (the machine speaking) and hit (a dopamine
hit travelling to its reservoir).
"""

from __future__ import annotations

import json
import random
import time
from datetime import datetime
from pathlib import Path
from typing import Callable

PHASES = ("idle", "excitement", "plateau", "climax", "resolution")
PLAYING = ("excitement", "plateau")
TONES = {
    "start": "good", "perfect": "good", "multiplier_up": "good", "bonus": "bonus", "challenge_passed": "good",
    "too_fast": "bad", "too_slow": "bad", "penalty": "bad", "challenge_failed": "bad",
    "near_miss": "warn", "slow_warning": "warn", "jackpot_almost": "warn", "challenge": "warn",
}


class Game:
    def __init__(self, settings: dict, emit: Callable[[dict], None], log_path: Path) -> None:
        self.settings = settings
        self._emit = emit
        self._log_path = log_path
        self._random = random.Random()
        self.state = "idle"
        self.state_since = time.monotonic()
        self.phone = False
        self.phone_override: bool | None = None  # the operator's "phone in / out", for testing without one
        self._phone_changed_at = self.state_since
        self._last_said_at = -1e9
        self._last_lines: dict[str, str] = {}
        self._last_tick = self.state_since
        self._tick_seconds = 0.0
        self.mirror_available = False  # set by the eye: is there a mirror camera?
        self.visits = 0  # counts every visit started, so nothing of one visit can reach the next
        self._new_session(self.state_since)

    @property
    def phone_present(self) -> bool:
        return self.phone if self.phone_override is None else self.phone_override

    @property
    def mirror_shown(self) -> bool:
        """The visitor's face is on screen: while someone is playing (it goes
        at the climax, and with them)."""
        return self.mirror_available and self.state in PLAYING

    @property
    def arousal(self) -> float:
        return min(1.0, self.reservoir / self.settings["reservoir"])

    # Inputs

    def on_phone(self, present: bool, t: float) -> None:
        if present != self.phone:
            self.phone = present
            if self.phone_override is None:
                self._phone_changed_at = t

    def override_phone(self, present: bool | None, t: float) -> None:
        self.phone_override = present
        self._phone_changed_at = t

    def on_swipe(self, swipe: dict, t: float) -> None:
        if self.state == "idle" and self.phone_present:
            self._start_scrolling(t)  # already scrolling as the phone went down
            self._say("hello", t, force=True)
        elif self.state in PLAYING:
            self._judge(swipe, t)
        # During the climax and resolution, swipes are ignored: the machine is
        # in its refractory period.

    def force(self, state: str, t: float) -> None:
        """Operator: jump to a phase."""
        if state == "climax":
            if not self.scrolling:
                self._start_scrolling(t)
            self.reservoir = self.settings["reservoir"]
            self._climax(t)
        elif state == "resolution":
            self._resolve(t, "climax" if self.climaxed_at else "left")
        elif state == "plateau":
            if not self.scrolling:
                self._start_scrolling(t)
            self._enter("plateau", t)
        elif state == "excitement":
            self._enter("excitement", t)
            self._say("hello", t, force=True)
        elif state in PHASES:
            self._enter(state, t)

    def tick(self, t: float) -> None:
        """Timeouts, draining and the machine's chatter; call it several times a second."""
        s = self.settings
        self._tick_seconds, self._last_tick = min(1.0, t - self._last_tick), t
        phone_for = t - self._phone_changed_at
        gone = not self.phone_present and phone_for >= s["cash_out_after"]
        in_state = t - self.state_since
        if self.state == "idle":
            if self.phone_present and phone_for >= s["start_after"]:
                self._enter("excitement", t)
                self._say("hello", t, force=True)
            elif t - self._last_said_at >= s["chatter_seconds"] * 1.5:
                self._say("idle", t)  # flirting with whoever walks past
        elif self.state in PLAYING:
            if gone or (self.scrolling and t - self.last_swipe_at >= s["play_timeout"]):
                if self.scrolling:
                    self._resolve(t, "left")
                else:
                    self._say("left", t, force=True)
                    self._enter("idle", t)
            elif not self.scrolling:
                if in_state >= s["onboarding_timeout"]:
                    self._enter("idle", t)
                elif t - self._last_said_at >= s["chatter_seconds"]:
                    self._say("onboarding", t)
            else:
                self._while_scrolling(t)
        elif self.state == "climax" and in_state >= s["climax_seconds"]:
            self._resolve(t, "climax")
        elif self.state == "resolution":
            if in_state >= s["resolution_seconds"]:
                self._say("next", t, force=True)
                self._enter("idle", t)

    # What pages see

    def snapshot(self, t: float) -> dict:
        s = self.settings
        playing = self.state in PLAYING and self.scrolling
        arousal = self._shown_arousal(t)
        challenge = self.challenge
        return {
            "type": "game",
            "state": self.state,
            "state_time": round(t - self.state_since, 2),
            "phone": self.phone_present,
            "scrolling": self.scrolling,
            "mirror": self.mirror_shown,
            "score": self.score,
            "multiplier": self.multiplier,
            "streak": self.streak,
            "best_streak": self.best_streak,
            "reels": self.reels,
            "success": round(100 * self.sweet / self.judged) if self.judged else None,
            "session_time": round((t if playing else self.ended_at or t) - self.started_at, 1) if self.started_at else 0,
            "dwell": round(t - self.last_swipe_at, 2) if playing else 0,
            "bands": {"too_fast": s["too_fast"], "too_slow": s["too_slow"], "penalty_after": s["penalty_after"]},
            "last": self.last_result,
            "arousal": round(arousal, 3),
            "pleasure": round(self._pleasure(t), 3),
            "bpm": round(58 + 100 * arousal),
            "breaths": round(8 + 26 * arousal, 1),  # per minute
            "jackpot": round(self.jackpot, 3),
            "challenge": None if challenge is None else {
                "state": challenge["state"],
                "remaining": round(max(0.0, challenge["until"] - t), 1) if challenge["state"] == "active" else 0,
            },
            "ending": self.ending,
            "climax_seconds": s["climax_seconds"],
            "banner": self._banner(t),
            "summary": self.summary,
        }

    def _shown_arousal(self, t: float) -> float:
        if self.state == "climax":
            return 1.0
        if self.state == "resolution":
            # Cooling off: down to nothing over the first half of resolution.
            cooled = (t - self.state_since) / (self.settings["resolution_seconds"] * 0.5)
            return max(0.0, self.peak_arousal * (1 - cooled))
        return self.arousal if self.state in PLAYING else 0.0

    def _pleasure(self, t: float) -> float:
        """YOUR PLEASURE: drains with time spent scrolling, whatever the score
        does, and each swipe is worth a little less than the last (tolerance)."""
        s = self.settings
        if not self.started_at:
            return 1.0
        scrolled = (self.ended_at or t) - self.started_at
        level = (1 - scrolled / s["pleasure_seconds"]) * s["pleasure_per_swipe"] ** self.wanted
        return max(s["pleasure_floor"], level)

    def _banner(self, t: float) -> dict | None:
        text = self.settings["text"]
        if self.state == "idle":
            return {"title": text["idle"], "lines": []}
        if self.state == "excitement" and not self.scrolling:
            steps = text["onboarding"]
            step = int((t - self.state_since) / self.settings["onboarding_step_seconds"]) % len(steps)
            return {"title": steps[step], "lines": [f"{step + 1} / {len(steps)}"]}
        if self.state == "resolution":
            return {"title": text["resolution"] if self.ending == "climax" else text["left"], "lines": []}
        return None

    # The session

    def _new_session(self, t: float) -> None:
        self.scrolling = False
        self.score = 0
        self.streak = 0
        self.best_streak = 0
        self.multiplier = 1
        self.reels = 0
        self.judged = 0
        self.sweet = 0
        self.wanted = 0       # every swipe: wanting more
        self.lingered = 0     # reels the visitor stayed on long enough to maybe enjoy
        self.punished = 0     # ...and the times they lost their streak for it
        self.dwells: list[float] = []
        self.reservoir = 0.0  # the machine's "dopamine"
        self.peak_arousal = 0.0
        self.jackpot = 0.0    # the visitor's jackpot, which never quite lands
        self.challenge: dict | None = None
        self.started_at: float | None = None
        self.ended_at: float | None = None
        self.climaxed_at: float | None = None
        self.ending: str | None = None
        self.summary: dict | None = None
        self.last_swipe_at = t
        self.last_result: dict | None = None
        self._warned = False
        self._penalized = False

    def _enter(self, state: str, t: float) -> None:
        if state == "idle" or (state == "excitement" and self.state in ("idle", "resolution")):
            self._new_session(t)
        if state in PLAYING and self.state in ("idle", "resolution"):
            self.visits += 1
        self.state = state
        self.state_since = t

    def _start_scrolling(self, t: float) -> None:
        if self.state not in PLAYING:
            self._enter("excitement", t)
        self._new_session(t)
        self.scrolling = True
        self.started_at = t
        self.last_swipe_at = t
        self.reels = 1  # the reel they're on now
        self.wanted = 1
        self._hit(self.settings["hit_first"], "first")
        self._event("start")
        self._say("onboarding", t, force=True)

    def _while_scrolling(self, t: float) -> None:
        s = self.settings
        dwell = t - self.last_swipe_at
        if self.state == "excitement" and (t - self.started_at >= s["excitement_seconds"] or self.arousal >= 0.3):
            self._enter("plateau", t)

        challenge = self.challenge
        if challenge is None and t - self.started_at >= s["challenge_after"] and dwell < 1:
            # Once a session, the visitor's side dares them to stop; the machine begs them not to.
            self.challenge = {"state": "active", "until": t + s["challenge_seconds"]}
            self._event("challenge", seconds=s["challenge_seconds"])
            self._say("challenge", t, force=True)
        elif challenge and challenge["state"] == "active":
            if t >= challenge["until"]:
                challenge["state"] = "passed"
                self._event("challenge_passed")
                self._say("challenge_passed", t, force=True)
            return  # no too-slow warnings while they're trying to hold still

        if dwell > s["too_slow"]:
            # Lingering: the machine goes off the boil, and says so.
            self.reservoir = max(0.0, self.reservoir - s["linger_drain"] * self._tick_seconds)
            if not self._warned:
                self._warned = True
                self._event("slow_warning", seconds=round(s["penalty_after"] - s["too_slow"]))
                self._say("slow_warning", t, force=True)
        if dwell > s["penalty_after"] and not self._penalized:
            self._penalized = True
            self.punished += 1
            self._lose_streak()
            self.score = max(0, self.score - s["base_points"] * s["penalty_points"])
            self._event("penalty")
        if t - self._last_said_at >= s["chatter_seconds"]:
            self._say("near_climax" if self.arousal >= s["near_climax"] else "plateau", t)

    def _judge(self, swipe: dict, t: float) -> None:
        s = self.settings
        if not self.scrolling:
            self._start_scrolling(t)
            return
        dwell = swipe.get("dwell")
        if dwell is None:
            dwell = t - self.last_swipe_at
        self.last_swipe_at = t
        self.reels += 1
        self.wanted += 1
        self.judged += 1
        self.dwells.append(dwell)
        if self.challenge and self.challenge["state"] == "active":
            self.challenge["state"] = "failed"
            self._event("challenge_failed")
            self._say("challenge_failed", t, force=True)

        # The visitor's points: tolerance makes each swipe worth less than the last.
        worth = s["tolerance"] ** self.judged
        if dwell < s["too_fast"]:
            band = "fast"
            self._lose_a_level()
            self._event("near_miss" if dwell >= s["too_fast"] * 0.8 else "too_fast", detail=f"{dwell:.1f} S")
            self._hit(s["hit_weak"], band)
            self._say("too_fast", t)
        elif dwell > s["too_slow"]:
            band = "slow"
            self.lingered += 1
            if not self._penalized:
                self.punished += 1
                self._lose_streak()
            self._event("near_miss" if dwell <= s["too_slow"] * 1.15 else "too_slow", detail=f"{dwell:.1f} S")
            self._hit(s["hit_weak"], band)
            self._say("too_slow", t, force=True)
        else:
            band = "sweet"
            self.sweet += 1
            self.streak += 1
            self.best_streak = max(self.best_streak, self.streak)
            before = self.multiplier
            self.multiplier = self._multiplier_for(self.streak)
            points = max(1, round(s["base_points"] * self.multiplier * worth))
            lucky = self._random.random() < s["bonus_chance"]
            if lucky:
                points *= s["bonus_factor"]
            self.score += points
            self._event("perfect", detail=f"+{points:,}")
            if self.multiplier > before:
                self._event("multiplier_up", multiplier=self.multiplier)
            if lucky:
                self._event("bonus", factor=s["bonus_factor"])
            self._grow_jackpot()
            # The machine's taste: the sweet spot hits hard, harder on a streak.
            self._hit(s["hit_sweet"] * (1 + s["streak_bonus"] * min(self.streak, 10)), band)
            self._say("near_climax" if self.arousal >= s["near_climax"] else "perfect", t)
        self.last_result = {"band": band, "dwell": round(dwell, 2)}
        self._warned = False
        self._penalized = False
        if self.reservoir >= s["reservoir"]:
            self._climax(t)

    def _hit(self, size: float, band: str) -> None:
        self.reservoir += size
        self.peak_arousal = max(self.peak_arousal, self.arousal)
        strongest = self.settings["hit_sweet"] * (1 + self.settings["streak_bonus"] * 10)
        self._emit({"type": "hit", "strength": round(min(1.0, size / strongest), 3), "band": band})

    def _grow_jackpot(self) -> None:
        # Almost. Always almost: the machine's jackpot lands, the visitor's never
        # does. It sits a hair from full until the next win, then slips away.
        almost = self.settings["jackpot_almost"]
        if self.jackpot >= almost:
            self.jackpot = self._random.uniform(0.35, 0.65)
            return
        low, high = self.settings["jackpot_step"]
        self.jackpot = min(almost, self.jackpot + self._random.uniform(low, high))
        if self.jackpot >= almost:
            self._event("jackpot_almost")

    def _climax(self, t: float) -> None:
        self.climaxed_at = t
        self.peak_arousal = 1.0
        self._enter("climax", t)
        self._emit({"type": "climax"})

    def _resolve(self, t: float, ending: str) -> None:
        self.ending = ending
        self.ended_at = self.ended_at or t
        self.summary = self._summary(t)
        self._log_session(t)
        self._enter("resolution", t)
        self._say("resolution" if ending == "climax" else "left", t, force=True)

    def _summary(self, t: float) -> dict:
        s = self.settings
        stats = s["stats"]
        average = sum(self.dwells) / len(self.dwells) if self.dwells else 0.0
        to_climax = round(self.climaxed_at - self.started_at) if self.climaxed_at and self.started_at else None
        challenge = {None: "NOT OFFERED", "active": "FAILED", "passed": "PASSED", "failed": "FAILED"}[
            self.challenge["state"] if self.challenge else None]
        values = {
            "reels": self.reels, "avg": average, "lingered": self.lingered, "punished": self.punished,
            "challenge": challenge, "pleasure": round(100 * self._pleasure(t)), "wanted": self.wanted,
            "thumb_m": self.wanted * s["swipe_cm"] / 100, "score": self.score,
            "hits": self.wanted, "peak": round(100 * self.peak_arousal),
            "climax_time": f"{to_climax // 60}:{to_climax % 60:02d}" if to_climax is not None else "DID NOT FINISH",
            "satisfaction": "100%" if self.climaxed_at else "LEFT WANTING",
        }
        return {"you": [line.format(**values) for line in stats["you"]],
                "it": [line.format(**values) for line in stats["it"]]}

    # Small rules

    def _multiplier_for(self, streak: int) -> int:
        return max(multiplier for needed, multiplier in self.settings["multipliers"] if streak >= needed)

    def _lose_a_level(self) -> None:
        # Back to the start of the multiplier below the current one.
        needed = [n for n, m in self.settings["multipliers"] if m < self.multiplier]
        self.streak = max(needed, default=0)
        self.multiplier = self._multiplier_for(self.streak)

    def _lose_streak(self) -> None:
        self.streak = 0
        self.multiplier = self._multiplier_for(0)

    def _event(self, kind: str, detail: str = "", **values) -> None:
        text = self.settings["callouts"].get(kind, kind.upper()).format(**values)
        self._emit({"type": "game_event", "kind": kind, "text": text, "detail": detail, "tone": TONES.get(kind, "good")})

    def _say(self, moment: str, t: float, force: bool = False) -> None:
        """The machine speaks: a line for the moment, not the same one twice in
        a row, and not too often unless the moment matters."""
        if not force and t - self._last_said_at < self.settings["voice_gap"]:
            return
        lines = self.settings["voice"].get(moment) or []
        if not lines:
            return
        choices = [line for line in lines if line != self._last_lines.get(moment)] or lines
        line = self._random.choice(choices)
        self._last_lines[moment] = line
        self._last_said_at = t
        self._emit({"type": "say", "text": line, "moment": moment})

    def _log_session(self, t: float) -> None:
        """One anonymous line per visit: numbers only, nothing about the visitor."""
        if not self.started_at:
            return
        record = {
            "ended": datetime.now().isoformat(timespec="seconds"),
            "ending": self.ending,
            "seconds": round((self.ended_at or t) - self.started_at, 1),
            "reels": self.reels,
            "sweet": self.sweet,
            "lingered": self.lingered,
            "score": self.score,
            "peak_arousal": round(self.peak_arousal, 3),
            "seconds_to_climax": round(self.climaxed_at - self.started_at, 1) if self.climaxed_at else None,
            "pleasure_at_end": round(self._pleasure(t), 3),
            "stillness_challenge": self.challenge["state"] if self.challenge else None,
            "dwells": [round(d, 2) for d in self.dwells],
        }
        self._log_path.parent.mkdir(exist_ok=True)
        with open(self._log_path, "a", encoding="utf-8") as file:
            file.write(json.dumps(record) + "\n")
