"""The reel face's base head: the visitor's own head, built from three photos
(front, left and right) and the face landmarks MediaPipe finds in each, which
a screen page sends. Held in memory for one visit, never saved.

The face is MediaPipe's face mesh: 468 points, with its own layout for the
skin (canonical_face_model.obj, from MediaPipe). The rest of the head, the
skull and the neck, is a shell fitted to the face. The skin is one picture:
the face's layout on the left half, the shell's on the right, wrapped round
the head like a label round a tin. Each triangle's skin is cut from whichever
photo faces it best, so the cheeks come from the profiles rather than being
stretched from the front. Where no photo saw the head (the back), the nearest
skin is smeared across, until reels cover it.
"""

from __future__ import annotations

from dataclasses import dataclass

import cv2
import numpy as np

from .settings import ROOT

MESH_PATH = ROOT / "web" / "vendor" / "mediapipe" / "canonical_face_model.obj"
VIEWS = ("front", "left", "right")
FACE, SHELL, NECK, CAP = 0, 1, 2, 3  # what each triangle belongs to

# Landmarks used to measure a face (MediaPipe's numbering). "Image left" is the
# visitor's right cheek, as an unmirrored camera sees it.
TOP, CHIN, NOSE = 10, 152, 1
IMAGE_LEFT_EDGE, IMAGE_RIGHT_EDGE = 234, 454
IMAGE_LEFT_EYE, IMAGE_RIGHT_EYE = 33, 263
FACE_POINTS = 468  # the mesh's points; MediaPipe adds 10 for the irises, unused here


@dataclass
class Layout:
    """MediaPipe's face mesh: its triangles and where each corner sits on the skin."""
    triangles: np.ndarray  # (T, 3) point numbers
    uvs: np.ndarray        # (T, 3, 2) on the face's own layout, 0-1, v from the top
    point_uvs: np.ndarray  # (468, 2) one place on the skin per point
    oval: np.ndarray       # the face's outline, in order
    holes: list            # any openings inside it (eyes, mouth), each in order


@dataclass
class View:
    name: str
    landmarks: np.ndarray  # (478, 3) in pixels: x right, y down, z smaller towards the camera
    image: np.ndarray      # the photo they were found in (BGR)


@dataclass
class Head:
    version: int
    positions: np.ndarray  # (T, 3, 3) each triangle's corners: x right, y up, z towards the viewer, the face 1 tall
    uvs: np.ndarray        # (T, 3, 2) where each corner sits on the skin, 0-1, v from the top
    parts: np.ndarray      # (T,) FACE, SHELL, NECK or CAP
    skin: np.ndarray       # BGR, twice as wide as tall
    views: tuple
    triangles: np.ndarray  # (T, 3) the point numbers, for which triangles touch
    normals: np.ndarray    # (T, 3) pointing out of the head


def load_layout() -> Layout:
    vt, triangles, uv_triangles = [], [], []
    for line in MESH_PATH.read_text(encoding="utf-8").splitlines():
        parts = line.split()
        if parts and parts[0] == "vt":
            vt.append((float(parts[1]), 1 - float(parts[2])))
        elif parts and parts[0] == "f":
            corners = [corner.split("/") for corner in parts[1:4]]
            triangles.append([int(corner[0]) - 1 for corner in corners])
            uv_triangles.append([int(corner[1]) - 1 for corner in corners])
    vt, triangles, uv_triangles = np.array(vt), np.array(triangles), np.array(uv_triangles)
    point_uvs = np.zeros((FACE_POINTS, 2))
    point_uvs[triangles.ravel()] = vt[uv_triangles.ravel()]
    loops = sorted(_boundary_loops(triangles), key=len, reverse=True)
    return Layout(triangles, vt[uv_triangles], point_uvs, loops[0], loops[1:])


def _boundary_loops(triangles: np.ndarray) -> list:
    """The mesh's open edges, joined into loops. Edges keep their triangle's
    direction, so each loop comes out in order."""
    counts: dict = {}
    for triangle in triangles:
        for a, b in zip(triangle, np.roll(triangle, -1)):
            key = (min(a, b), max(a, b))
            counts[key] = counts.get(key, 0) + 1
    following = {int(a): int(b) for triangle in triangles for a, b in zip(triangle, np.roll(triangle, -1))
                 if counts[(min(a, b), max(a, b))] == 1}
    loops, seen = [], set()
    for start in following:
        loop, point = [], start
        while point not in seen and point in following:
            seen.add(point)
            loop.append(point)
            point = following[point]
        if len(loop) > 2:
            loops.append(np.array(loop))
    return loops


def pose(landmarks: np.ndarray) -> tuple[float, float]:
    """Which way the face points, from its landmarks (normalised or pixels):
    turn is 0.5 square on, higher turned to the visitor's left, lower to their
    right; tilt is where the nose sits between the top of the face and the chin."""
    left, right, nose = landmarks[IMAGE_LEFT_EDGE], landmarks[IMAGE_RIGHT_EDGE], landmarks[NOSE]
    turn = (nose[0] - left[0]) / max(1e-6, right[0] - left[0])
    tilt = (nose[1] - landmarks[TOP][1]) / max(1e-6, landmarks[CHIN][1] - landmarks[TOP][1])
    return float(turn), float(tilt)


def build_head(views: dict, layout: Layout, size: int, version: int) -> Head:
    """The visitor's head from their photos. Needs the front; the profiles,
    when there, give the sides of the face and head."""
    model = _face_in_model_space(views["front"].landmarks[:FACE_POINTS])
    points, triangles, parts, uvs, centre = _head_mesh(model, layout)
    normals, flipped = _outward_normals(points, triangles, parts, centre)
    uvs[flipped] = uvs[flipped][:, [0, 2, 1]]

    width, height = size, size // 2
    skin = np.zeros((height, width, 3), np.uint8)
    filled = np.zeros((height, width), bool)
    targets = uvs * [width, height]
    best = np.full(len(triangles), 0.05)  # a photo must face a triangle at least this much to give it skin
    chosen: list = [None] * len(triangles)
    for view in views.values():
        projected, toward = _project(model, points, view.landmarks[:FACE_POINTS])
        facing = normals @ toward
        if view.name == "front":
            facing = facing + np.where(np.isin(parts, (FACE, CAP)), 0.2, 0.0)  # the face keeps its likeness
        image_h, image_w = view.image.shape[:2]
        corners = projected[triangles]
        inside = np.all((corners[..., 0] >= 0) & (corners[..., 0] < image_w)
                        & (corners[..., 1] >= 0) & (corners[..., 1] < image_h), axis=1)
        for index in np.flatnonzero(inside & (facing > best)):
            best[index] = facing[index]
            chosen[index] = (view.image, corners[index])
    for index, pick in enumerate(chosen):
        if pick is not None:
            paste_triangle(skin, filled, pick[0], pick[1], targets[index])
    half = width // 2
    _smear(skin[:, :half], filled[:, :half])
    _smear(skin[:, half:], filled[:, half:])
    return Head(version, points[triangles], uvs, parts, skin, tuple(views), triangles, normals)


def _face_in_model_space(landmarks: np.ndarray) -> np.ndarray:
    """The front photo's landmarks as a face standing upright and square on:
    y up, z towards the viewer, 1 tall from the top of the forehead to the chin."""
    points = landmarks.astype(np.float64) * [1, -1, -1]

    def turn(axis: int, angle: float) -> None:
        c, s = np.cos(angle), np.sin(angle)
        i, j = [(1, 2), (2, 0), (0, 1)][axis]
        a, b = points[:, i].copy(), points[:, j].copy()
        points[:, i], points[:, j] = c * a - s * b, s * a + c * b

    across = points[IMAGE_RIGHT_EDGE] - points[IMAGE_LEFT_EDGE]
    turn(1, np.arctan2(across[2], across[0]))      # square on, side to side
    down = points[CHIN] - points[TOP]
    turn(0, -np.arctan2(down[2], -down[1]))        # upright, not looking down
    eyes = points[IMAGE_RIGHT_EYE] - points[IMAGE_LEFT_EYE]
    turn(2, -np.arctan2(eyes[1], eyes[0]))          # level
    points -= points.mean(axis=0)
    return points / np.linalg.norm(points[TOP] - points[CHIN])


def _head_mesh(model: np.ndarray, layout: Layout, rings: int = 8, neck_rings: int = 4, around: int = 24):
    """The face, plus a shell swept back from its outline round an egg-shaped
    skull, a neck, and caps over any openings (eyes, mouth). Returns every
    point, the triangles, what each belongs to, their places on the skin and
    the skull's centre."""
    face_width = np.linalg.norm(model[IMAGE_RIGHT_EDGE] - model[IMAGE_LEFT_EDGE])
    oval = layout.oval
    radii = np.array([face_width * 0.56, 0.68, 0.6])
    centre = np.array([model[oval, 0].mean(), model[TOP, 1] + 0.14 - radii[1], model[oval, 2].mean() - radii[2] * 0.45])
    pole = np.array([0.0, 0.3, -1.0])
    pole /= np.linalg.norm(pole)

    points = [model]
    count = FACE_POINTS
    triangles = [layout.triangles]
    parts = [np.full(len(layout.triangles), FACE)]
    uvs = [layout.uvs * [0.5, 1]]  # the face's layout, on the left half of the skin

    # The shell: each point of the outline sweeps back to the pole, reaching the skull's surface quickly.
    ring_points = [oval]
    for ring in range(1, rings):
        t = ring / rings
        shaped = []
        for start in model[oval]:
            relative = (start - centre) / radii
            reach = np.linalg.norm(relative)
            direction = _slerp(relative / reach, pole, t)
            shaped.append(centre + radii * direction * (reach + (1 - reach) * min(1.0, t / 0.3)))
        points.append(np.array(shaped))
        ring_points.append(np.arange(count, count + len(oval)))
        count += len(oval)
    points.append((centre + radii * pole)[None])
    pole_point = count
    count += 1
    shell = []
    for inner, outer in zip(ring_points, ring_points[1:]):
        for i in range(len(oval)):
            j = (i + 1) % len(oval)
            shell += [(inner[i], inner[j], outer[i]), (inner[j], outer[j], outer[i])]
    last = ring_points[-1]
    shell += [(last[i], last[(i + 1) % len(oval)], pole_point) for i in range(len(oval))]

    # The neck: a tube from inside the head's underside down.
    chin = model[CHIN]
    top_y, bottom_y = chin[1] + 0.08, chin[1] - 0.75
    neck_centre_z = centre[2] - 0.02
    first_neck = count
    for ring in range(neck_rings + 1):
        y = top_y + (bottom_y - top_y) * ring / neck_rings
        angles = 2 * np.pi * np.arange(around) / around
        points.append(np.c_[centre[0] + face_width * 0.36 * np.sin(angles), np.full(around, y),
                            neck_centre_z + face_width * 0.42 * np.cos(angles)])
        count += around
    neck = []
    for ring in range(neck_rings):
        a, b = first_neck + ring * around, first_neck + (ring + 1) * around
        for i in range(around):
            j = (i + 1) % around
            neck += [(a + i, b + i, a + j), (a + j, b + i, b + j)]

    all_points = np.concatenate(points)
    wrapped = np.array(shell + neck)
    triangles.append(wrapped)
    parts.append(np.r_[np.full(len(shell), SHELL), np.full(len(neck), NECK)])
    uvs.append(_wrap_uvs(all_points[wrapped], centre, centre[1] + radii[1], bottom_y))

    # Caps over the eyes and mouth, if the mesh leaves them open: a fan to a point just behind.
    for hole in layout.holes:
        middle = all_points[hole].mean(axis=0) - [0, 0, 0.015]
        all_points = np.vstack([all_points, middle])
        middle_point = len(all_points) - 1
        fan = np.array([(hole[i], hole[(i + 1) % len(hole)], middle_point) for i in range(len(hole))])
        triangles.append(fan)
        parts.append(np.full(len(fan), CAP))
        hole_uvs = layout.point_uvs[hole] * [0.5, 1]
        uvs.append(np.stack([hole_uvs, np.roll(hole_uvs, -1, axis=0), np.repeat(hole_uvs.mean(axis=0)[None], len(hole), 0)], axis=1))

    return all_points, np.concatenate(triangles), np.concatenate(parts), np.concatenate(uvs), centre


def _wrap_uvs(corners: np.ndarray, centre: np.ndarray, top_y: float, bottom_y: float) -> np.ndarray:
    """The shell and neck on the right half of the skin, wrapped round the head:
    across is the way round (the join at the front, hidden behind the face),
    down is height. A triangle across the join is kept whole, just past it."""
    around = np.arctan2(corners[..., 0] - centre[0], -(corners[..., 2] - centre[2]))  # 0 at the back
    across_join = around.max(axis=1) - around.min(axis=1) > np.pi
    around[across_join] = np.where(around[across_join] < 0, around[across_join] + 2 * np.pi, around[across_join])
    u = 0.5 + 0.45 * (around + np.pi) / (2 * np.pi)
    v = (top_y - corners[..., 1]) / (top_y - bottom_y)
    return np.stack([u, np.clip(v, 0, 1)], axis=-1)


def _outward_normals(points: np.ndarray, triangles: np.ndarray, parts: np.ndarray, centre: np.ndarray):
    """Each triangle's normal, pointing out of the head (the neck: out from its
    middle). Flips triangles wound the other way, so they all face outwards,
    and says which it flipped."""
    corners = points[triangles]
    normals = np.cross(corners[:, 1] - corners[:, 0], corners[:, 2] - corners[:, 0])
    middles = corners.mean(axis=1)
    out = middles - centre
    out[parts == NECK, 1] = 0  # the neck's outside is away from its axis, not from the skull's centre
    inward = np.einsum("ij,ij->i", normals, out) < 0
    triangles[inward] = triangles[inward][:, [0, 2, 1]]
    normals[inward] *= -1
    return normals / np.maximum(1e-12, np.linalg.norm(normals, axis=1))[:, None], inward


def _project(model: np.ndarray, points: np.ndarray, landmarks: np.ndarray):
    """Where every point of the head lands in one photo, and the direction
    towards that camera. A simple camera is fitted to the face's landmarks;
    the face's own points use the landmarks themselves."""
    solved, *_ = np.linalg.lstsq(np.c_[model, np.ones(len(model))], landmarks[:, :2], rcond=None)
    projected = np.c_[points, np.ones(len(points))] @ solved
    projected[:FACE_POINTS] = landmarks[:, :2]
    toward = -np.cross(solved[:3, 0], solved[:3, 1])
    return projected, toward / np.linalg.norm(toward)


def paste_triangle(skin: np.ndarray, filled: np.ndarray, image: np.ndarray, source: np.ndarray, target: np.ndarray) -> None:
    """One triangle of a picture, onto its place on the skin (and marked in filled)."""
    height, width = filled.shape
    x0, y0 = np.maximum(np.floor(target.min(axis=0)).astype(int) - 1, 0)
    x1, y1 = np.minimum(np.ceil(target.max(axis=0)).astype(int) + 2, [width, height])
    if x1 - x0 < 1 or y1 - y0 < 1:
        return
    local = (target - [x0, y0]).astype(np.float32)
    (ax, ay), (bx, by) = local[1] - local[0], local[2] - local[0]
    if abs(ax * by - ay * bx) < 0.5:
        return  # too thin to hold anything
    matrix = cv2.getAffineTransform(source.astype(np.float32), local)
    patch = cv2.warpAffine(image, matrix, (x1 - x0, y1 - y0), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
    mask = np.zeros((y1 - y0, x1 - x0), np.uint8)
    cv2.fillConvexPoly(mask, np.round(local * 4).astype(np.int32), 1, shift=2)
    mask = cv2.dilate(mask, np.ones((3, 3), np.uint8)).astype(bool)  # no hairline gaps between triangles
    skin[y0:y1, x0:x1][mask] = patch[mask]
    filled[y0:y1, x0:x1] |= mask


def _smear(skin: np.ndarray, filled: np.ndarray) -> None:
    """What no photo saw: the nearest skin stretched across, row by row, then
    down the columns for rows that saw nothing at all."""
    if not filled.any():
        skin[:] = 96
        return
    rows, _ = np.indices(filled.shape)
    seen_rows = filled.any(axis=1)
    across = _nearest(filled, axis=1)
    fill = ~filled & seen_rows[:, None]
    skin[fill] = skin[rows[fill], across[fill]]
    if not seen_rows.all():
        down = _nearest(seen_rows[:, None], axis=0)[:, 0]
        skin[~seen_rows] = skin[down[~seen_rows]]


def _nearest(have: np.ndarray, axis: int) -> np.ndarray:
    """For every place along an axis, the nearest place that has something."""
    length = have.shape[axis]
    shape = [1, 1]
    shape[axis] = length
    index = np.arange(length).reshape(shape)
    before = np.maximum.accumulate(np.where(have, index, -1), axis=axis)
    after = np.flip(np.minimum.accumulate(np.flip(np.where(have, index, length), axis=axis), axis=axis), axis=axis)
    take_before = (before >= 0) & ((after >= length) | (index - before <= after - index))
    return np.clip(np.where(take_before, before, after), 0, length - 1)


def _slerp(a: np.ndarray, b: np.ndarray, t: float) -> np.ndarray:
    angle = np.arccos(np.clip(a @ b, -1, 1))
    if angle < 1e-6:
        return a
    return (np.sin((1 - t) * angle) * a + np.sin(t * angle) * b) / np.sin(angle)
