"""The copy of the visitor's head, made of the reels they watched.

It starts as the base head's skin, which is never changed. Each reel watched
past the threshold becomes shards painted over the copy's skin. A shard is a
patch of the head's own triangles, with one of the reel's stills draped over
it, so the reel wraps the geometry: the forehead, a cheek, the jaw. Early
reels take big, coherent patches; later ones are smaller, split into several
pieces, and land over the old ones.

The eyes, nose and mouth stay readable: the base face's light and dark is
laid over the reels there, and more faintly over the rest of the face. So it
is still recognisably their face, but the skin is reels. As the session goes
on the features fade a little, and each new reel arrives more damaged than
the last (distortion.py): its colour knocked off its neighbours', pixelated,
and saved as a worse and worse JPEG, for real.

A snapshot after every reel is kept, to scrub back through. All of it in
memory, for one visit.
"""

from __future__ import annotations

import heapq
from dataclasses import dataclass

import cv2
import numpy as np

from . import distortion
from .face_capture import FACE, Head, Layout, paste_triangle
from .reel_sampler import STILL_SIZE, ReelRecord

# The face's features, by MediaPipe's landmark numbers: kept readable over the reels.
FEATURES = [
    [33, 7, 163, 144, 145, 153, 154, 155, 133, 173, 157, 158, 159, 160, 161, 246],         # an eye
    [263, 249, 390, 373, 374, 380, 381, 382, 362, 398, 384, 385, 386, 387, 388, 466],      # the other eye
    [70, 63, 105, 66, 107, 55, 65, 52, 53, 46],                                           # a brow
    [300, 293, 334, 296, 336, 285, 295, 282, 283, 276],                                   # the other brow
    [1, 2, 98, 327, 168, 6, 197, 195, 5, 4, 45, 275, 64, 294],                             # the nose
    [61, 146, 91, 181, 84, 17, 314, 405, 321, 375, 291, 409, 270, 269, 267, 0, 37, 39, 40, 185],  # the mouth
]


@dataclass
class Snapshot:
    reels: int
    fragments: int
    watched: float
    jpeg: bytes
    shards: np.ndarray  # which shard each triangle belonged to then (-1: the base)


class ReelCopy:
    def __init__(self, head: Head, layout: Layout, settings: dict, seed: int) -> None:
        self.head = head
        self.settings = settings
        self.random = np.random.default_rng(seed)
        self.skin = head.skin.copy()
        height, width = self.skin.shape[:2]
        self.covered = np.zeros((height, width), bool)
        count = len(head.triangles)
        self.owner = np.full(count, -1)  # which reel each triangle shows now (-1: still the base)
        self.shard = np.full(count, -1)  # ...and which shard
        self.shards = 0
        self.reels = 0
        self.watched = 0.0
        corners = head.positions
        self.areas = 0.5 * np.linalg.norm(np.cross(corners[:, 1] - corners[:, 0], corners[:, 2] - corners[:, 0]), axis=1)
        self.middles = corners.mean(axis=1)
        self.neighbours = _neighbours(head.triangles)
        half = width // 2
        self.structure = _structure(head.skin[:, :half])
        self.features = _features(layout, (height, half))
        self.likeness = settings["likeness"] + (settings["feature_likeness"] - settings["likeness"]) * self.features
        self._shown: np.ndarray | None = None
        self.history: list[Snapshot] = []
        self._snapshot()

    @property
    def fragments(self) -> int:
        """Shards still showing somewhere on the head."""
        return int(np.unique(self.shard[self.shard >= 0]).size)

    @property
    def progress(self) -> float:
        return distortion.progress(self.reels, self.watched, self.settings)

    def add(self, reel: ReelRecord) -> None:
        s = self.settings
        self.reels += 1
        self.watched += reel.watched
        n = self.reels
        share = max(s["smallest_shard"], s["first_shard"] * s["shard_shrink"] ** (n - 1))
        share *= float(np.clip(reel.watched / s["typical_watch"], 0.6, 1.6))  # watched longer, a bigger piece of you
        pieces = 1 if n <= 3 else min(s["most_pieces"], 1 + (n - 3) // 4)
        stills = [cv2.imdecode(np.frombuffer(jpeg, np.uint8), cv2.IMREAD_COLOR) for jpeg in reel.stills]
        stills = [still for still in stills if still is not None] or [_colour_tile(reel.colour, self.random)]
        damage = distortion.controls(self.progress, s)
        total = self.areas.sum()
        for piece in range(pieces):
            triangles = self._grow(self._seed(), share / pieces * total)
            self._drape(triangles, _damage(stills[piece % len(stills)], damage, self.random))
            self.owner[triangles] = n
            self.shard[triangles] = self.shards
            self.shards += 1
        self._shown = None
        self._snapshot()

    def shown(self) -> np.ndarray:
        """The skin as the head wears it: the reels, with the face's features
        laid over them."""
        if self._shown is None:
            skin = self.skin.copy()
            half = skin.shape[1] // 2
            fading = 1 - 0.3 * self.progress  # the features fade a little, never away
            strength = self.likeness * fading * self.covered[:, :half]
            factor = 1 + strength * (self.structure - 1)
            face = skin[:, :half] * factor[..., None]
            # The visitor's own eyes, brows, nose and mouth, half showing through: half-erased.
            keep = (self.settings["feature_keep"] * fading * self.features * self.covered[:, :half])[..., None]
            face = face * (1 - keep) + self.head.skin[:, :half] * keep
            skin[:, :half] = np.clip(face, 0, 255).astype(np.uint8)
            self._shown = skin
        return self._shown

    # Where the shards go

    def _seed(self) -> int:
        """Where a shard starts: mostly where the base still shows, while it
        does, and mostly on the face and the sides people see, not the back."""
        head = self.head
        weights = self.areas * np.where(head.parts == FACE, 2.0, 1.0)
        weights = weights * np.where(head.normals[:, 2] < -0.3, 0.25, 1.0)
        if (self.owner < 0).any():
            weights = weights * np.where(self.owner < 0, self.settings["uncovered_pull"], 1.0)
        return int(self.random.choice(len(weights), p=weights / weights.sum()))

    def _grow(self, seed: int, area: float) -> np.ndarray:
        """A patch of triangles round the seed, roughly round but with ragged,
        torn-looking edges, until it covers the area."""
        middle = self.middles[seed]
        chosen = {seed}
        covered = self.areas[seed]
        frontier: list = []

        def reach(triangle: int) -> None:
            for neighbour in self.neighbours[triangle]:
                if neighbour not in chosen:
                    distance = np.linalg.norm(self.middles[neighbour] - middle) * self.random.uniform(0.6, 1.4)
                    heapq.heappush(frontier, (distance, neighbour))

        reach(seed)
        while frontier and covered < area:
            _, triangle = heapq.heappop(frontier)
            if triangle in chosen:
                continue
            chosen.add(triangle)
            covered += self.areas[triangle]
            reach(triangle)
        return np.array(sorted(chosen))

    def _drape(self, triangles: np.ndarray, still: np.ndarray) -> None:
        """Lays a still over the patch like a sheet of paper over the head:
        projected straight on from the patch's own direction, upright, a little
        turned and zoomed, and cut along the triangles' edges."""
        head = self.head
        corners = head.positions[triangles]
        normal = (head.normals[triangles] * self.areas[triangles, None]).sum(axis=0)
        normal /= np.linalg.norm(normal) or 1
        up = np.array([0.0, 1.0, 0.0]) if abs(normal[1]) < 0.9 else np.array([0.0, 0.0, -1.0])
        across = np.cross(up, normal)
        across /= np.linalg.norm(across)
        upward = np.cross(normal, across)
        points = corners.reshape(-1, 3)
        a, b = points @ across, points @ upward
        turn = self.random.normal(0, 0.25)
        a, b = a * np.cos(turn) - b * np.sin(turn), a * np.sin(turn) + b * np.cos(turn)
        still_w, still_h = still.shape[1], still.shape[0]
        span_a, span_b = max(np.ptp(a), 1e-6), max(np.ptp(b), 1e-6)
        scale = max(still_w / span_a, still_h / span_b) * self.random.uniform(1.0, 1.5)
        slack = np.array([span_a * scale - still_w, span_b * scale - still_h]).clip(0)
        shift = self.random.uniform(-0.5, 0.5, 2) * slack
        x = still_w / 2 + (a - (a.min() + a.max()) / 2) * scale + shift[0]
        y = still_h / 2 - (b - (b.min() + b.max()) / 2) * scale + shift[1]
        sources = np.stack([x, y], axis=1).reshape(-1, 3, 2)
        height, width = self.skin.shape[:2]
        targets = head.uvs[triangles] * [width, height]
        for source, target in zip(sources, targets):
            paste_triangle(self.skin, self.covered, still, source, target)

    def _snapshot(self) -> None:
        _, jpeg = cv2.imencode(".jpg", self.shown(), [cv2.IMWRITE_JPEG_QUALITY, 85])
        self.history.append(Snapshot(self.reels, self.fragments, round(self.watched, 1), jpeg.tobytes(), self.shard.copy()))
        if len(self.history) > self.settings["history_size"]:
            del self.history[1]  # keep the clean base, drop the oldest after it


def _neighbours(triangles: np.ndarray) -> list:
    """For each triangle, the ones sharing an edge with it."""
    by_edge: dict = {}
    for index, triangle in enumerate(triangles):
        for a, b in zip(triangle, np.roll(triangle, -1)):
            by_edge.setdefault((min(a, b), max(a, b)), []).append(index)
    neighbours: list = [[] for _ in triangles]
    for sharing in by_edge.values():
        for index in sharing:
            neighbours[index].extend(other for other in sharing if other != index)
    return neighbours


def _structure(face: np.ndarray) -> np.ndarray:
    """The base face's light and dark, against its surroundings: below 1 where
    it's darker (eyes, brows, nostrils, lips), above where it's lighter."""
    gray = cv2.cvtColor(face, cv2.COLOR_BGR2GRAY).astype(np.float32)
    local = cv2.GaussianBlur(gray, (0, 0), 18)
    return np.clip((gray + 8) / (local + 8), 0.3, 1.7)


def _features(layout: Layout, size: tuple) -> np.ndarray:
    """Where the eyes, brows, nose and mouth are on the face's half of the
    skin: 1 on them, fading to 0 around them."""
    height, width = size
    mask = np.zeros(size, np.float32)
    for feature in FEATURES:
        points = (layout.point_uvs[feature] * [width, height]).astype(np.int32)
        cv2.fillConvexPoly(mask, cv2.convexHull(points), 1.0)
    return cv2.GaussianBlur(cv2.dilate(mask, np.ones((25, 25), np.uint8)), (0, 0), 12)


def _damage(still: np.ndarray, controls: dict, random: np.random.Generator) -> np.ndarray:
    """A still, damaged as far as the copy has got: its exposure and colour
    knocked off its neighbours', pixelated, and saved as a JPEG again and
    again at a falling quality, nudged a little each time (generation loss)."""
    shift, blocky = controls["colour_shift"], controls["jpeg_blockiness"]
    gain = 1 + random.normal(0, 0.25 * shift)
    cast = random.normal(0, 22 * shift, 3)
    damaged = np.clip(still.astype(np.float32) * gain + cast, 0, 255).astype(np.uint8)
    height, width = damaged.shape[:2]
    if blocky > 0.15:
        factor = 1 + 5 * blocky * random.uniform(0.5, 1.0)
        small = cv2.resize(damaged, (max(8, int(width / factor)), max(8, int(height / factor))), interpolation=cv2.INTER_AREA)
        damaged = cv2.resize(small, (width, height), interpolation=cv2.INTER_NEAREST)
    quality = max(4, int(round(85 - 80 * blocky)))
    for _ in range(1 + int(blocky * 3)):
        damaged = np.roll(damaged, tuple(random.integers(-2, 3, 2)), axis=(0, 1))
        damaged = cv2.imdecode(cv2.imencode(".jpg", damaged, [cv2.IMWRITE_JPEG_QUALITY, quality])[1], cv2.IMREAD_COLOR)
    return damaged


def _colour_tile(colour: tuple, random: np.random.Generator) -> np.ndarray:
    """A reel with no usable still: its main colour, blurred and uneven."""
    width, height = STILL_SIZE
    noise = random.normal(0, 18, (height // 24, width // 24, 1))
    tile = np.clip(np.array(colour, np.float32) + cv2.resize(noise, (width, height), interpolation=cv2.INTER_CUBIC)[..., None], 0, 255)
    return cv2.GaussianBlur(tile.astype(np.uint8), (0, 0), 6)
