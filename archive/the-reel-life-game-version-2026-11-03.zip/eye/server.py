"""The eye's web server.

Serves the setup editor (/editor) and each screen (/screen/<id>), streams
camera previews to them over one WebSocket per page, saves what the editor
sends to setup.json, and opens screens fullscreen on their monitors.

It also runs the swipe detector on the detection camera and the game, and
sends the game to every page.

Messages, as JSON:
  to pages:   hello, setup, devices, status, notice, game (a snapshot, often),
              game_event (something to react to), swipe (each one detected)
  from pages: watch {cameras}, setup {setup}, refresh_devices,
              open_screen {id}, close_screen {id}, lock_zone, unlock_zone,
              set_zone {zone: four [x, y] corners as fractions of the picture},
              record {on: true/false} (footage of a test session, into footage/live-tests),
              face_record {mood, seconds},
              fake_swipe, fake_phone {present: true/false/null}, force_state {state},
              reelface_view {landmarks, image} (a face a page found, for the reel face),
              reelface_capture {view} (take the next face as this view), reelface_recapture,
              reelface_reset (the copy back to the clean head), reelface_scrub {index or null},
              reelface_test_reels {count}, reelface_intensity {value 0-1, or null to follow the session}
  also to pages: reel_face (its state, and its mesh when the head is rebuilt)
Camera frames go to pages as binary: one byte for the camera name's length,
the name, then a JPEG. The detection view is sent the same way, as "@detection",
the visitor's face as "@mirror", only while someone is playing, and the reel
face's skin as "@reelface".
"""

from __future__ import annotations

import asyncio
import json
import mimetypes
import os
import re
import subprocess
import time
import webbrowser
from pathlib import Path

import cv2
import numpy as np
from aiohttp import WSMsgType, web

from . import cameras, faces, monitors, settings
from .game import Game
from .reel_face import REEL_FACE_VIEW, ReelFace
from .reel_sampler import ReelRecord, ReelSampler
from .watcher import DETECTION_VIEW, SwipeWatcher

GAME_UPDATES_PER_SECOND = 10
MIRROR_VIEW = "@mirror"

WEB = settings.ROOT / "web"
BROWSER_PROFILES = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "TheReelLife" / "browser-profiles"


def _valid_zone(zone: object) -> list | None:
    """Four [x, y] corners, each a fraction of the picture, or None."""
    try:
        corners = [[float(x), float(y)] for x, y in zone]
    except (TypeError, ValueError):
        return None
    if len(corners) != 4 or not all(0 <= v <= 1 for corner in corners for v in corner):
        return None
    return [[round(x, 4), round(y, 4)] for x, y in corners]


def encode_preview(name: str, frame: np.ndarray, max_width: int, quality: int) -> bytes:
    height, width = frame.shape[:2]
    if width > max_width:
        frame = cv2.resize(frame, (max_width, round(height * max_width / width)), interpolation=cv2.INTER_AREA)
    _, jpeg = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, quality])
    label = name.encode("utf-8")[:255]
    return bytes([len(label)]) + label + jpeg.tobytes()


class Client:
    """One open page. Everything sent to it goes out through writer(), one
    message at a time. Only the newest frame per camera is kept, so a slow
    page skips frames instead of falling behind."""

    def __init__(self, ws: web.WebSocketResponse) -> None:
        self.ws = ws
        self.watching: set[str] = set()
        self.skin_version = 0  # the reel face's skin this page has
        self._messages: list[str] = []
        self._frames: dict[str, bytes] = {}
        self._wake = asyncio.Event()

    def send_json(self, message: dict) -> None:
        self._messages.append(json.dumps(message))
        self._wake.set()

    def send_frame(self, camera: str, data: bytes) -> None:
        self._frames[camera] = data
        self._wake.set()

    async def writer(self) -> None:
        try:
            while not self.ws.closed:
                await self._wake.wait()
                self._wake.clear()
                messages, self._messages = self._messages, []
                frames, self._frames = self._frames, {}
                for text in messages:
                    await self.ws.send_str(text)
                for data in frames.values():
                    await self.ws.send_bytes(data)
        except (ConnectionResetError, RuntimeError):
            pass


class Eye:
    def __init__(self, config: dict, port: int) -> None:
        self.config = config
        self.port = port
        self.camera_settings = config["cameras"]
        self.devices = cameras.list_sources()
        self.monitors = monitors.list_monitors()
        self.setup = settings.load_setup() or settings.default_setup(self.devices, self.camera_settings["default_device"])
        self.hub = cameras.CameraHub(self.camera_settings)
        self.game = Game(config["game"], self._broadcast, settings.ROOT / "logs" / "sessions.jsonl")
        self.faces = faces.FaceRecorder()
        self.reel_face = ReelFace(config["reel_face"])
        self._visit_seen = self.game.visits
        self._refreshing = False
        self._refresh_again = False
        self.sampler: ReelSampler | None = None
        self.watcher: SwipeWatcher | None = None
        self.clients: set[Client] = set()
        self.windows: dict[str, subprocess.Popen] = {}
        self._pending_save: asyncio.TimerHandle | None = None
        self._tasks: list[asyncio.Task] = []
        self._mirror_open = False

    # Lifecycle

    async def start(self, app: web.Application) -> None:
        self._sync_cameras()
        loop = asyncio.get_running_loop()
        self.sampler = ReelSampler(self.config["reel_face"], self.config["detection"]["rotate"],
                                   lambda reel: loop.call_soon_threadsafe(self._on_reel, reel))
        self.sampler.start()
        self.watcher = SwipeWatcher(self.hub, self.config["detection"], self._on_detection, loop, self.sampler)
        self._watch_detection_camera()
        self.watcher.start()
        self._tasks = [asyncio.create_task(self._pump_frames()), asyncio.create_task(self._pump_status()),
                       asyncio.create_task(self._pump_game())]
        if app["open_screens"]:
            for screen in self.setup["screens"]:
                if screen.get("monitor"):
                    self._report(self.open_screen(screen["id"]))
        if app["open_editor"]:
            webbrowser.open(f"http://localhost:{self.port}/editor")

    async def stop(self, _app: web.Application) -> None:
        for task in self._tasks:
            task.cancel()
        if self._pending_save:
            self._pending_save.cancel()
            settings.save_setup(self.setup)
        for screen_id in list(self.windows):
            self.close_screen(screen_id)
        if self.watcher:
            await asyncio.to_thread(self.watcher.stop)
        if self.sampler:
            await asyncio.to_thread(self.sampler.stop)
        await asyncio.to_thread(self.hub.stop_all)

    # Pages

    async def websocket(self, request: web.Request) -> web.WebSocketResponse:
        ws = web.WebSocketResponse(heartbeat=10, max_msg_size=8 * 1024 * 1024)
        await ws.prepare(request)
        client = Client(ws)
        self.clients.add(client)
        writer = asyncio.create_task(client.writer())
        client.send_json({"type": "hello", "setup": self.setup, "devices": self.devices,
                          "monitors": self.monitors, "status": self._status(),
                          "game": self.game.snapshot(time.monotonic()), "game_text": self.config["game"]["text"],
                          "reel_face": self.reel_face.message(mesh=True, pieces=True)})
        try:
            async for message in ws:
                if message.type == WSMsgType.TEXT:
                    await self._handle(client, json.loads(message.data))
        finally:
            self.clients.discard(client)
            writer.cancel()
        return ws

    async def _handle(self, client: Client, message: dict) -> None:
        kind = message.get("type")
        if kind == "watch":
            client.watching = set(message.get("cameras") or [])
            if REEL_FACE_VIEW not in client.watching:
                client.skin_version = 0  # send it again if it comes back
        elif kind == "setup":
            setup = message.get("setup")
            if not settings.is_valid(setup):
                client.send_json({"type": "notice", "text": "The eye ignored a setup it couldn't read."})
                return
            self.setup = setup
            self._sync_cameras()
            self._watch_detection_camera()
            self._save_soon()
            self._broadcast({"type": "setup", "setup": setup}, skip=client)
        elif kind == "refresh_devices":
            self.devices = await asyncio.to_thread(cameras.list_sources)
            self.monitors = await asyncio.to_thread(monitors.list_monitors)
            self._broadcast({"type": "devices", "devices": self.devices, "monitors": self.monitors})
        elif kind in ("lock_zone", "unlock_zone", "set_zone"):
            if kind == "lock_zone":
                zone = self.watcher.detector.zone_from_quad(self.watcher.frame_size)
            elif kind == "set_zone":
                zone = _valid_zone(message.get("zone"))
            else:
                zone = None
            if kind != "unlock_zone" and zone is None:
                problem = ("No phone outline to lock yet. Put the phone under the camera first." if kind == "lock_zone"
                           else "The eye couldn't use those corners. Click four on the detection view.")
                client.send_json({"type": "notice", "text": problem})
                return
            self.setup["detection_zone"] = zone
            self._watch_detection_camera()
            self._save_soon()
            self._broadcast({"type": "setup", "setup": self.setup})
        elif kind == "record":
            self.watcher.record(bool(message.get("on")))
        elif kind == "face_record":
            name = self.setup.get("face_camera", "")
            camera = self.hub.get(name)
            if camera is None:
                problem = "Choose a camera in the Face studio first."
            elif name == self.setup.get("mirror_camera") and self.game.state != "idle":
                problem = "Someone is playing. The mirror camera is never recorded while a visitor could be in front of it."
            else:
                problem = self.faces.record(camera, message.get("mood", ""), float(message.get("seconds", 8)))
            if problem:
                client.send_json({"type": "notice", "text": problem})
        elif kind == "reelface_view":
            kept = self.reel_face.offer(message, time.monotonic())
            self._broadcast(self.reel_face.message())  # with how the face was posed, kept or not
            if kept:
                asyncio.create_task(self._refresh_reel_face())
        elif kind == "reelface_capture":
            self.reel_face.force(message.get("view", ""), time.monotonic())
            self._broadcast(self.reel_face.message())
        elif kind == "reelface_recapture":
            self.reel_face.recapture(time.monotonic())
            self._broadcast(self.reel_face.message())
        elif kind == "reelface_intensity":
            value = message.get("value")
            self.reel_face.set_intensity(value if isinstance(value, (int, float)) else None)
            self._broadcast(self.reel_face.message())
        elif kind in ("reelface_reset", "reelface_scrub", "reelface_test_reels"):
            if kind == "reelface_reset":
                self.reel_face.reset_copy()
            elif kind == "reelface_scrub":
                index = message.get("index")
                self.reel_face.scrub(index if isinstance(index, int) else None)
            elif not self.reel_face.add_test_reels(int(message.get("count", 1)), time.monotonic()):
                client.send_json({"type": "notice", "text": "Test reels need a visit: choose a face camera and press Start."})
            self._broadcast(self.reel_face.message())
            asyncio.create_task(self._refresh_reel_face())
        elif kind == "fake_swipe":
            self._pretend_phone_if_none()
            self.game.on_swipe({"dwell": None, "fake": True}, time.monotonic())
            self._send_game()
        elif kind == "fake_phone":
            self.game.override_phone(message.get("present"), time.monotonic())
        elif kind == "force_state":
            state = message.get("state", "idle")
            if state in ("excitement", "plateau"):
                self._pretend_phone_if_none()
            self.game.force(state, time.monotonic())
            self._sync_cameras()  # the mirror camera opens or closes with the phase
            self._send_game()
        elif kind == "open_screen":
            problem = self.open_screen(message.get("id", ""))
            if problem:
                client.send_json({"type": "notice", "text": problem})
            self._broadcast(self._status())
        elif kind == "close_screen":
            self.close_screen(message.get("id", ""))
            self._broadcast(self._status())

    def _broadcast(self, message: dict, skip: Client | None = None) -> None:
        for client in self.clients:
            if client is not skip:
                client.send_json(message)

    def _status(self) -> dict:
        open_screens = [screen_id for screen_id, window in self.windows.items() if window.poll() is None]
        return {"type": "status", "cameras": self.hub.info(), "open_screens": open_screens,
                "detection": self.watcher.info() if self.watcher else None,
                "phone_override": self.game.phone_override, "faces": self.faces.info()}

    # Detection and the game

    def _sync_cameras(self) -> None:
        """Open the cameras the setup uses. The mirror camera opens only while
        someone is playing, so its light means their face is on screen."""
        self.game.mirror_available = bool(self.setup.get("mirror_camera"))
        self._mirror_open = self.game.mirror_shown
        self.hub.sync(settings.camera_modes(self.setup, mirror=self._mirror_open))

    def _frames_for(self, name: str):
        """Where a page's frames come from. The visitor's face leaves the eye
        only while someone is playing: never otherwise, by any name."""
        mirror = self.setup.get("mirror_camera")
        if name == DETECTION_VIEW:
            return self.watcher
        if name == MIRROR_VIEW:
            return self.hub.get(mirror) if mirror and self.game.mirror_shown else None
        if name == mirror and not self.game.mirror_shown:
            # The same camera by its own name: only for the Face studio, while no one's playing.
            return self.hub.get(name) if name == self.setup.get("face_camera") and self.game.state == "idle" else None
        return self.hub.get(name)

    async def _refresh_reel_face(self) -> None:
        """Brings the reel face's head and copy up to date in a worker thread,
        once at a time; anything that arrives meanwhile gets a turn of its own
        straight after."""
        if self._refreshing:
            self._refresh_again = True
            return
        self._refreshing = True
        try:
            while True:
                self._refresh_again = False
                new_head, changed = await asyncio.to_thread(self.reel_face.refresh)
                if new_head or changed:
                    self._broadcast(self.reel_face.message(mesh=new_head, pieces=True))
                if not self._refresh_again:
                    break
        finally:
            self._refreshing = False

    def _on_reel(self, reel: ReelRecord) -> None:
        """A reel was watched long enough (from the sampler's thread, via the loop)."""
        if self.reel_face.add_reel(reel):
            self._broadcast(self.reel_face.message())
            asyncio.create_task(self._refresh_reel_face())

    def _follow_visit(self, t: float) -> None:
        """The reel face follows the visit: it forgets everything when a new
        visit starts (counted by the game, so a visit that ends and another
        that starts between two ticks still can't carry anything over) or the
        eye goes back to idle, and asks for the new visitor's face."""
        if self.game.visits != self._visit_seen:
            self._visit_seen = self.game.visits
            if self.game.mirror_available:
                self.reel_face.begin(t)
            else:
                self.reel_face.end()
            self.sampler.reset()
        elif self.game.state == "idle" and self.reel_face.state != "off":
            self.reel_face.end()
            self.sampler.reset()
        elif not self.reel_face.tick(t):
            return
        self._broadcast(self.reel_face.message())

    def _watch_detection_camera(self) -> None:
        if self.watcher:
            self.watcher.watch(self.setup.get("detection_camera", ""), self.setup.get("detection_zone"))

    def _on_detection(self, event: dict) -> None:
        if event["type"] == "phone":
            self.game.on_phone(event["present"], event["t"])
        elif event["type"] == "swipe":
            self._broadcast(event)  # every detected swipe, for testing and tuning
            self.game.on_swipe(event, event["detected_at"])
            self._send_game()  # straight away, rather than at the next update

    def _pretend_phone_if_none(self) -> None:
        # Testing by hand implies a phone; without one the game would cash out straight away.
        if not self.game.phone_present:
            self.game.override_phone(True, time.monotonic())

    def _send_game(self) -> None:
        self._broadcast(self.game.snapshot(time.monotonic()))

    def _save_soon(self) -> None:
        # The editor sends changes many times a second while dragging; write the file once it settles.
        if self._pending_save:
            self._pending_save.cancel()
        self._pending_save = asyncio.get_running_loop().call_later(0.5, settings.save_setup, self.setup)

    def _report(self, problem: str | None) -> None:
        if problem:
            print(problem)

    # Screens on monitors

    def open_screen(self, screen_id: str) -> str | None:
        """Open a screen fullscreen on its monitor. Returns what went wrong, if anything."""
        screen = next((screen for screen in self.setup["screens"] if screen["id"] == screen_id), None)
        if screen is None:
            return "That screen isn't in the setup."
        self.monitors = monitors.list_monitors()
        monitor = next((monitor for monitor in self.monitors if monitor["id"] == screen.get("monitor")), None)
        if monitor is None:
            return f"Choose a monitor for {screen['name']} first, or check that it's connected."
        browser = monitors.find_browser(self.config.get("browser", {}).get("path", ""))
        if browser is None:
            return "Couldn't find Chrome or Edge. Set browser.path in config.yaml."
        self.close_screen(screen_id)
        profile = BROWSER_PROFILES / re.sub(r"[^\w-]", "_", screen_id)
        url = f"http://127.0.0.1:{self.port}/screen/{screen_id}"
        self.windows[screen_id] = monitors.open_fullscreen(url, monitor, profile, browser)
        return None

    def close_screen(self, screen_id: str) -> None:
        window = self.windows.pop(screen_id, None)
        if window and window.poll() is None:
            window.terminate()

    # Background loops

    async def _pump_frames(self) -> None:
        period = 1 / self.camera_settings["preview_fps"]
        max_width = self.camera_settings["preview_max_width"]
        quality = self.camera_settings["jpeg_quality"]
        last_sent: dict[str, int] = {}
        loop = asyncio.get_running_loop()
        next_tick = loop.time()
        while True:
            next_tick = max(next_tick + period, loop.time())
            await asyncio.sleep(next_tick - loop.time())
            for name in {name for client in self.clients for name in client.watching}:
                if name == REEL_FACE_VIEW:
                    # The head's skin: already a JPEG, sent at full size, once to each page that needs it.
                    version, data = self.reel_face.skin()
                    for client in self.clients:
                        if data and name in client.watching and client.skin_version != version:
                            client.skin_version = version
                            client.send_frame(name, data)
                    continue
                source = self._frames_for(name)
                frame, frame_id = source.latest() if source else (None, 0)
                if frame is None or last_sent.get(name) == frame_id:
                    continue
                last_sent[name] = frame_id
                data = await asyncio.to_thread(encode_preview, name, frame, max_width, quality)
                for client in self.clients:
                    if name in client.watching:
                        client.send_frame(name, data)

    async def _pump_status(self) -> None:
        while True:
            await asyncio.sleep(1)
            self._broadcast(self._status())

    async def _pump_game(self) -> None:
        while True:
            await asyncio.sleep(1 / GAME_UPDATES_PER_SECOND)
            self.game.tick(time.monotonic())
            if self.game.mirror_shown != self._mirror_open:
                self._sync_cameras()  # the visitor left, or the climax: the mirror camera closes
            self._follow_visit(time.monotonic())
            self._send_game()


@web.middleware
async def _no_cache(request: web.Request, handler) -> web.StreamResponse:
    # Always serve the latest page and scripts after an edit.
    response = await handler(request)
    if not response.prepared:
        response.headers["Cache-Control"] = "no-store"
    return response


def _page(filename: str):
    async def handler(_request: web.Request) -> web.FileResponse:
        return web.FileResponse(WEB / filename)
    return handler


async def _to_editor(_request: web.Request) -> web.Response:
    raise web.HTTPFound("/editor")


def run(port: int | None = None, open_editor: bool = False, open_screens: bool = False) -> None:
    config = settings.load_config()
    port = port or config["server"]["port"]
    eye = Eye(config, port)

    app = web.Application(middlewares=[_no_cache])
    app["open_editor"] = open_editor
    app["open_screens"] = open_screens
    app.router.add_get("/", _to_editor)
    app.router.add_get("/editor", _page("editor.html"))
    app.router.add_get("/screen/{id}", _page("screen.html"))
    app.router.add_get("/ws", eye.websocket)
    app.router.add_static("/js", WEB / "js")
    app.router.add_static("/css", WEB / "css")
    faces.FACES.mkdir(exist_ok=True)
    app.router.add_static("/faces", faces.FACES)  # IT's face clips, for the Face source
    # MediaPipe, for finding the visitor's face (the reel face). Windows can't be trusted with these types.
    mimetypes.add_type("text/javascript", ".mjs")
    mimetypes.add_type("application/wasm", ".wasm")
    app.router.add_static("/vendor", WEB / "vendor")
    app.on_startup.append(eye.start)
    app.on_cleanup.append(eye.stop)

    print(f"The Reel Life eye is running. Editor: http://localhost:{port}/editor  (Ctrl+C to stop)")
    print(f"Cameras found: {', '.join(eye.devices) or 'none (is ffmpeg installed?)'}")
    web.run_app(app, host="127.0.0.1", port=port, print=None)
