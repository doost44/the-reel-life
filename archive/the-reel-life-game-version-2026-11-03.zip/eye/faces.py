"""IT's face: short clips of the artist's own face, one per mood, recorded in
the editor's Face studio and played back in pieces by the Face source.

Only ever the artist's own face (or a consenting performer's), never a
visitor's: the machine wants your attention, not you. The clips stay in
faces/ on this computer and are kept out of git.
"""

from __future__ import annotations

import threading
import time

import cv2
import numpy as np

from .cameras import Camera
from .footage import convert_to_mp4
from .settings import ROOT

FACES = ROOT / "faces"
MOODS = ["bored", "curious", "warm", "flushed", "peak", "indifferent"]
CLIP_SIZE = (480, 640)  # portrait, 3:4


def guide_crop(frame: np.ndarray) -> np.ndarray:
    """The part of the picture inside the on-screen face guide: a centred
    3:4 portrait, 90% of the picture's height. The Face source cuts the
    features out of it at fixed places, so the face has to fill the guide."""
    height, width = frame.shape[:2]
    crop_h = int(height * 0.9)
    crop_w = min(width, int(crop_h * 0.75))
    x, y = (width - crop_w) // 2, (height - crop_h) // 2
    return cv2.resize(frame[y:y + crop_h, x:x + crop_w], CLIP_SIZE, interpolation=cv2.INTER_AREA)


def recorded() -> dict[str, int]:
    """The moods with a clip, and when each was last recorded (for reloading pages)."""
    if not FACES.exists():
        return {}
    return {path.stem: int(path.stat().st_mtime) for path in FACES.glob("*.mp4") if path.stem in MOODS}


class FaceRecorder:
    """Records one mood at a time from a camera, on its own thread."""

    def __init__(self) -> None:
        self.mood: str | None = None
        self.until = 0.0
        self.converting = False

    def info(self) -> dict:
        return {
            "recording": self.mood,
            "left": round(max(0.0, self.until - time.monotonic()), 1) if self.mood else 0,
            "converting": self.converting,
            "recorded": recorded(),
        }

    def record(self, camera: Camera, mood: str, seconds: float) -> str | None:
        """Start recording; returns what's wrong, if anything."""
        if mood not in MOODS:
            return f"Unknown mood: {mood}"
        if self.mood or self.converting:
            return "Already recording."
        if camera.status != "ok":
            return "That camera has no picture yet."
        self.mood = mood
        self.until = time.monotonic() + seconds
        threading.Thread(target=self._run, args=(camera, mood, seconds), name=f"face: {mood}", daemon=True).start()
        return None

    def _run(self, camera: Camera, mood: str, seconds: float) -> None:
        FACES.mkdir(exist_ok=True)
        path = FACES / f"{mood}.avi"
        writer = cv2.VideoWriter(str(path), cv2.VideoWriter_fourcc(*"MJPG"), max(1.0, camera.fps or 30), CLIP_SIZE)
        writer.set(cv2.VIDEOWRITER_PROP_QUALITY, 92)
        frame_id = 0
        try:
            while time.monotonic() < self.until:
                frame, new_id, _ = camera.wait_newer(frame_id, timeout=0.5)
                if frame is not None and new_id != frame_id:
                    frame_id = new_id
                    writer.write(guide_crop(frame))
        finally:
            writer.release()
            self.mood = None
            self.converting = True
            convert_to_mp4(FACES)  # replaces the old clip for this mood, if there was one
            self.converting = False
