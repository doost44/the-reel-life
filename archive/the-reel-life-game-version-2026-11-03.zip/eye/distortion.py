"""How broken the reel face looks.

Six controls, each rising with the session's progress: the reels watched and
the seconds spent watching them. A long scroll looks measurably more broken
than a short one. An override sets the progress by hand, for testing.

    fracture_amount  pieces of the head pulled apart, sliding, missing, doubled
    shard_size       how big the pieces that come apart are: whole patches (1) down to single triangles (0)
    pixel_stretch    bands of the picture smeared sideways and down
    jpeg_blockiness  JPEG's squares, colour banding, and each new reel saved worse
    smear            datamosh: the old picture dragged along, blocks of it stuck
    colour_shift     neighbouring pieces in mismatched tones and exposures, colours split
"""

from __future__ import annotations

CONTROLS = ("fracture_amount", "shard_size", "pixel_stretch", "jpeg_blockiness", "smear", "colour_shift")


def progress(reels: int, watched: float, settings: dict) -> float:
    """0 for a clean head, 1 for fully broken: mostly the reels, partly the time."""
    distortion = settings["distortion"]
    return min(1.0, 0.6 * reels / distortion["full_at_reels"] + 0.4 * watched / distortion["full_at_seconds"])


def controls(at: float, settings: dict) -> dict:
    """Each control at this progress. Each comes in between its own start and
    end, so they arrive one after another rather than all at once."""
    distortion = settings["distortion"]
    values = {}
    for name in CONTROLS:
        start, end, strength = distortion[name]
        t = min(1.0, max(0.0, (at - start) / max(1e-6, end - start)))
        t = t * t * (3 - 2 * t)
        values[name] = round(1 - (1 - strength) * t if name == "shard_size" else strength * t, 3)
    return values
