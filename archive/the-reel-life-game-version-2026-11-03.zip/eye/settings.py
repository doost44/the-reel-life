"""config.yaml (edited by hand) and setup.json (saved by the editor)."""

from __future__ import annotations

import json
import os
from pathlib import Path

from ruamel.yaml import YAML

ROOT = Path(__file__).resolve().parent.parent
CONFIG_PATH = ROOT / "config.yaml"
SETUP_PATH = ROOT / "setup.json"

DEFAULT_MODE = {"width": 720, "height": 480, "fps": 30}
# The detection camera defaults to 60 fps: half the movement between frames, so fast swipes measure cleanly.
DETECTION_MODE = {**DEFAULT_MODE, "fps": 60}


def load_config() -> dict:
    return YAML(typ="safe").load(CONFIG_PATH.read_text(encoding="utf-8"))


def load_setup() -> dict | None:
    if not SETUP_PATH.exists():
        return None
    try:
        setup = json.loads(SETUP_PATH.read_text(encoding="utf-8"))
    except (OSError, ValueError) as error:
        print(f"setup.json couldn't be read ({error}); starting from the default layout.")
        return None
    if not is_valid(setup):
        return None
    for screen in setup["screens"]:
        for item in screen["items"]:
            if "states" in item:
                item["states"] = renamed_states(item["states"])
    return setup


# The game's phases were renamed for the concept layer (sexual response cycle),
# and the terms screen (consent) was dropped: a source shown only then is never shown.
OLD_STATES = {"onboarding": ["excitement"], "play": ["excitement", "plateau"], "cashout": ["resolution"]}
PHASES = ["idle", "excitement", "plateau", "climax", "resolution"]


def renamed_states(states: list[str]) -> list[str]:
    wanted = {new for state in states for new in OLD_STATES.get(state, [state])}
    return [phase for phase in PHASES if phase in wanted]


def save_setup(setup: dict) -> None:
    # Write a copy and swap it in, so a crash mid-write can't leave half a file.
    temporary = SETUP_PATH.with_suffix(".json.tmp")
    temporary.write_text(json.dumps(setup, indent=2), encoding="utf-8")
    os.replace(temporary, SETUP_PATH)


def is_valid(setup: object) -> bool:
    return (
        isinstance(setup, dict)
        and isinstance(setup.get("screens"), list)
        and all(isinstance(screen, dict) and isinstance(screen.get("items"), list) for screen in setup["screens"])
    )


def camera_modes(setup: dict, mirror: bool = False) -> dict[str, dict]:
    """Every camera the setup uses (by any source, hidden or not, or by the
    detector), with the capture size and frame rate to open it at. The mirror
    camera only while someone is playing."""
    names = {
        item.get("camera")
        for screen in setup["screens"]
        for item in screen["items"]
        if item.get("type") == "camera"
    }
    detection = setup.get("detection_camera")
    names.add(detection)
    names.add(setup.get("face_camera"))  # the Face studio's camera, for recording IT's face
    if mirror:
        names.add(setup.get("mirror_camera"))
    names.discard(None)
    names.discard("")
    chosen = setup.get("cameras", {})
    return {name: {**(DETECTION_MODE if name == detection else DEFAULT_MODE), **chosen.get(name, {})} for name in names}


COLD, HOT = "#2a5cff", "#ff2a8d"
PLAYING = ["excitement", "plateau"]


def concept_game_screen(camera: str) -> dict:
    """Screen 2 in three parts: YOU on the left (casino-loud, fading to grey as
    YOUR PLEASURE drains), the camcorder in the middle, IT on the right (the
    machine's body, warming from cold blue to hot pink). 1920×1080."""
    gold, cyan, pink = "#ffd23f", "#2de2e6", "#ff2a6d"

    def item(item_id: str, kind: str, name: str, box: tuple, states: list | None = None, **values) -> dict:
        x, y, w, h = box
        made = {"id": item_id, "type": kind, "name": name, "visible": True, "x": x, "y": y, "w": w, "h": h, **values}
        return {**made, "states": states} if states else made

    def you(item_id: str, kind: str, name: str, box: tuple, states: list | None = None, **values) -> dict:
        return item(item_id, kind, name, box, states, fades=True, **values)  # the visitor's side drains to grey

    def stat(item_id: str, stat_name: str, label: str, box: tuple, size: int, color: str = gold) -> dict:
        return you(item_id, "stat", label.title(), box, PLAYING, stat=stat_name, label=label, size=size, color=color,
                   labelColor=pink, font="Arial Black", align="center", glow=True)

    return {
        "id": "game", "name": "Game screen", "width": 1920, "height": 1080, "background": "#0b0016",
        "monitor": "", "sound": True, "climax": True,
        "items": [
            mirror_item(),
            # IT: the machine's body, behind everything on the right.
            item("it-flush", "flush", "IT body (flush)", (1300, 0, 620, 1080), low=COLD, high=HOT, breathe=True),
            item("it-label", "text", "IT", (1320, 12, 580, 80), text="IT", size=64, color="#ffd6ef", font="Arial Black", align="center"),
            # Its face: the artist's own, in pieces on little screens (Face studio).
            item("it-face", "face", "IT face", (1330, 96, 560, 570), board="#14324a", rig=True, wires=True, tint=True,
                 low=COLD, high=HOT),
            item("it-reservoir", "reservoir", "Reservoir", (1320, 690, 200, 370), label="DOPAMINE", size=30,
                 font="Arial Black", labelColor="#ffffff", low=COLD, high=HOT),
            item("it-heartbeat", "heartbeat", "Heartbeat", (1540, 690, 360, 170), size=34, font="Consolas", low=COLD, high=HOT),
            item("it-arousal", "gauge", "Arousal", (1540, 900, 360, 120), value="arousal", label="AROUSAL",
                 orientation="horizontal", size=36, font="Arial Black", low=COLD, high=HOT),
            # YOU: casino-loud, draining.
            you("you-label", "text", "YOU", (40, 24, 560, 100), text="YOU", size=84, color=gold, font="Arial Black", align="center"),
            you("you-ticker", "stat", "Jackpot ticker", (40, 150, 560, 220), ["idle"], stat="jackpot", label="JACKPOT",
                size=84, color=gold, labelColor=pink, font="Arial Black", align="center", glow=True),
            stat("you-score", "score", "SCORE", (40, 140, 560, 220), 120),
            stat("you-multiplier", "multiplier", "MULTIPLIER", (40, 380, 270, 170), 90, cyan),
            stat("you-streak", "streak", "STREAK", (330, 380, 270, 170), 90),
            you("you-pleasure", "gauge", "Your pleasure", (40, 600, 560, 120), value="pleasure", label="YOUR PLEASURE",
                orientation="horizontal", size=40, font="Arial Black", low="#555555", high=gold),
            you("you-jackpot", "gauge", "Jackpot", (40, 750, 560, 90), PLAYING, value="jackpot", label="JACKPOT",
                orientation="horizontal", size=30, font="Arial Black", low="#555555", high=cyan),
            you("you-callout", "callout", "Callouts", (40, 860, 560, 200), PLAYING, size=72, font="Impact", seconds=1.6),
            # The middle: the source.
            item("game-title", "text", "Title", (640, 20, 640, 90), text="THE REEL LIFE", size=60, color=gold,
                 font="Arial Black", align="center"),
            item("game-feed", "camera", "Camcorder", (640, 120, 640, 480), camera=camera, fit="cover", vhs=True,
                 crop={"top": 0, "right": 0, "bottom": 0, "left": 0}),
            # Over the camcorder, on a dark backdrop while there's text: the attract line and the onboarding steps.
            item("game-banner", "banner", "Banner", (640, 120, 640, 480), ["idle", "excitement"], size=64, lineSize=40,
                 color="#ffffff", accent=gold, font="Arial Black", backdrop="#000000", backdropOpacity=70),
            item("game-meter", "meter", "Its pleasure meter (rhythm)", (640, 620, 640, 80), PLAYING, size=26,
                 font="Arial Black", fast=cyan, sweet=gold, slow=pink, fastLabel="FAST", sweetLabel="RIGHT THERE", slowLabel="SLOW"),
            item("it-voice", "voice", "Machine voice", (560, 720, 800, 320), ["idle", "excitement", "plateau", "resolution"],
                 size=56, font="Georgia", color="#ffd6ef", align="center", seconds=3, speak=False),
            # The dopamine hits, over everything, from the phone to the reservoir.
            item("game-hits", "hits", "Dopamine hits", (0, 0, 1920, 1080), PLAYING, **{"from": "game-feed", "to": "it-reservoir"},
                 color="#ffd6ef"),
            # Resolution: post-climax indifference, and the two columns.
            item("end-veil", "color", "Payout backdrop", (0, 0, 1920, 1080), ["resolution"], color="#000000", opacity=85),
            item("end-payout", "payout", "Payout (YOU / IT)", (120, 120, 1680, 720), ["resolution"], size=36,
                 font="Consolas", youColor="#cccccc", itColor=HOT),
            item("end-banner", "banner", "You can go now", (360, 870, 1200, 160), ["resolution"], size=80,
                 color="#ffffff", accent="#ffffff", font="Arial Black"),
        ],
    }


def mirror_item() -> dict:
    """Behind the YOU column: the visitor's own face, live while they play,
    draining to grey with YOUR PLEASURE while the score sits over it."""
    return {"id": "you-mirror", "type": "mirror", "name": "Your face (mirror)", "visible": True,
            "x": 0, "y": 0, "w": 620, "h": 1080, "states": PLAYING, "fades": True,
            "opacity": 55, "dim": 30, "caption": "LIVE · NOT RECORDED", "captionSize": 22}


def crt_glow() -> dict:
    """Over the CRT's camcorder picture: IT's glow, warming as arousal rises."""
    return {"id": "crt-glow", "type": "flush", "name": "IT glow", "visible": True, "x": 0, "y": 0, "w": 1024, "h": 768,
            "low": COLD, "high": HOT, "breathe": True, "opacity": 35}


def reel_face_screen() -> dict:
    """The visitor's head, rebuilt from what they watch: full screen, on a plain background."""
    return {
        "id": "reelface", "name": "Reel face", "width": 1920, "height": 1080, "background": "#b4b1ab", "monitor": "",
        "sound": True, "climax": False,
        "items": [{"id": "reel-face", "type": "reelface", "name": "Reel face", "visible": True,
                   "x": 0, "y": 0, "w": 1920, "h": 1080, "background": "#b4b1ab", "shade": 60, "turn": 35,
                   "size": 56, "font": "Arial Black", "color": "#141414"}],
    }


def operator_screen() -> dict:
    """A screen for whoever runs the exhibit: what the detector sees."""
    return {
        "id": "operator", "name": "Operator", "width": 1280, "height": 720, "background": "#000000", "monitor": "", "sound": False,
        "items": [{"id": "operator-detection", "type": "detection", "name": "Detection view", "visible": True,
                   "x": 0, "y": 0, "w": 1280, "h": 720}],
    }


def default_setup(devices: list[str], preferred: str) -> dict:
    """A first layout: the CRT shows the camcorder full screen with IT's glow
    over it, the game screen is YOU | camcorder | IT, and an operator screen
    shows the detection view."""
    camera = next((name for name in devices if preferred in name), devices[0] if devices else "")
    return {
        "detection_camera": camera,
        "detection_zone": None,
        "mirror_camera": "",  # the YOU mirror's camera, at face height; none until chosen
        "cameras": {camera: dict(DETECTION_MODE)} if camera else {},
        "screens": [
            {
                "id": "crt",
                "name": "CRT",
                "width": 1024,
                "height": 768,
                "background": "#000000",
                "monitor": "",
                "items": [
                    {"id": "crt-feed", "type": "camera", "name": "Camcorder", "visible": True,
                     "x": 0, "y": 0, "w": 1024, "h": 768,
                     "camera": camera, "fit": "cover", "vhs": True,
                     "crop": {"top": 0, "right": 0, "bottom": 0, "left": 0}},
                    crt_glow(),
                ],
            },
            concept_game_screen(camera),
            reel_face_screen(),
            operator_screen(),
        ],
    }
